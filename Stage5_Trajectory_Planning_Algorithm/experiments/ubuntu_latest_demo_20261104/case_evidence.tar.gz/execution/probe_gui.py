from pathlib import Path
import json,subprocess,os,time,signal,sys
w=Path('/workspace');root=w/'outputs/HS-FYP-/毕设仿真';run=w/'outputs/八字交叉覆盖复测_20261103/batch_001/cases/M07/attempt_001/session_001/cycle_001'
raw=subprocess.check_output(['bash','-c','source ./scripts/env.sh; env -0'],cwd=run)
env=dict(x.decode().split('=',1) for x in raw.split(b'\0') if b'=' in x);env.update(DISPLAY=':99',GZ_PARTITION='hs_latest_gui_probe_20261104',QT_AUTO_SCREEN_SCALE_FACTOR='0',QT_ENABLE_HIGHDPI_SCALING='0',QT_SCALE_FACTOR='1',GDK_SCALE='1',LP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
children=[]
try:
 for n,args in [('server',['gz','sim','-s','-r','-v','2','worlds/uav_vehicle_stage1.sdf']),('gui',['gz','sim','-g','-v','2','--gui-config',str(root/'simulation/environment_reference/demo_gui.config')])]:
  f=(w/f'work/latest_demo_20261104/probe_{n}.log').open('w');children.append(subprocess.Popen(args,cwd=run,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True))
 time.sleep(12)
 print(subprocess.check_output(['gz','service','-l'],env=env,text=True),flush=True)
 sys.path.insert(0,str(root/'tools'));os.environ['DISPLAY']=':99';from run_functional_demo import gazebo_window
 wid=gazebo_window();print('window',wid,flush=True)
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','x11grab','-window_id',str(wid),'-i',':99','-frames:v','1','-y',str(w/'work/latest_demo_20261104/probe_frame.png')],env=env,check=True)
finally:
 for p in reversed(children):os.killpg(p.pid,signal.SIGTERM)
 for p in children:
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)

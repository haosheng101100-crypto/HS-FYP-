from pathlib import Path
import sys,json,datetime
w=Path('/workspace');r=w/'outputs/HS-FYP-/毕设仿真';out=w/'outputs/新版功能实录_20261104/batch_002'
sys.path.insert(0,str(r/'tools'));import run_multicondition as m
m.prepare(r,out,json.loads((r/'config/experiments/multicondition_matrix_v1.json').read_text()),profile=r/'config/experiments/planar_terminal_recovery_v2.json')
receipt=json.loads((w/'outputs/八字交叉覆盖复测_20261103/batch_002/code_receipt.json').read_text())
receipt.update(authorised_case_ids=['M07','M18'],scope='Two actual GUI recordings of unchanged M07 landing and M18 safe-exit conditions; no control/gate/world changes',documentation_snapshot_commit='ee9a06479e0e312dcafc5a92a82bb05e301edbd3',declared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
m.save(out/'code_receipt.json',receipt)
_,manifest,env=m.verify_receipt(r,out,w/'work/reacquisition_20261102/deployment',r/'simulation/operator_package')
m.save(out/'environment_receipt.json',dict(source_files=len(receipt['source_sha256']),package_files=len(manifest),environment=env))
print('VERIFIED',len(receipt['source_sha256']),len(manifest),env,flush=True)

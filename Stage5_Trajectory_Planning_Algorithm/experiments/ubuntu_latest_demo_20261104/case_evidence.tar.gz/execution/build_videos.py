from pathlib import Path
import json,subprocess,hashlib
w=Path('/workspace');out=w/'outputs/新版功能实录_20261104/batch_002';dest=out/'watchable';dest.mkdir(exist_ok=True);meta=[]
def assclock(t):
 cs=max(0,round(t*100));return f'{cs//360000:01d}:{cs//6000%60:02d}:{cs//100%60:02d}.{cs%100:02d}'
for cid in ('M07','M18'):
 rec=json.loads((out/f'videos/{cid}_recording.json').read_text());result=json.loads((out/f'cases/{cid}/attempt_001/result.json').read_text())
 expected='complete_function_success' if cid=='M07' else 'correct_safe_exit'
 assert result['category']==expected,(cid,result['category'])
 assert rec['recorder_exit_code'] in (0,255) and result['supervisor_exit_code']==0
 rows=[json.loads(l) for l in (out/f'videos/{cid}_timeline.jsonl').read_text().splitlines()]
 start=rec['started_wall_unix_s'];cut=next(row['wall_unix_s']-start for row in rows if row['ui'].get('armed') is True);changes=[]
 labels={'INITIALIZING':'初始化','READY':'飞控就绪','TAKING_OFF':'无人机起飞','HOVER':'悬停准备','PREPARING':'稳定悬停，准备跟随','ALIGNING':'跟随八字运动平台，等待下降条件','LANDING':'跟随收敛，规划并执行下降','RECOVERING':'触发安全退出：制止下降、升高并返回','RECOVERY_LAND':'退出落台任务，返回起飞点并原生落地','COMPLETE':'落台与正常停转检查完成','ERROR':'安全退出流程结束，正常停转；没有落台'}
 for row in rows:
  ui=row['ui'];stage=ui.get('stage');t=row['wall_unix_s']-start
  if stage is None:continue
  label=labels.get(stage,stage)
  if cid=='M18' and stage=='ALIGNING':label='在安全高度跟随平台，等待下降条件'
  if ui.get('planner_phase')=='CONTACT_HANDOVER':label='实际接触与原生停转交接'
  if not changes or changes[-1][1]!=label:changes.append((t,label))
 end=rec['finished_wall_unix_s']-start
 dialogues=[]
 for i,(t,label) in enumerate(changes):
  until=changes[i+1][0] if i+1<len(changes) else end
  if until<=cut:continue
  dialogues.append(f'Dialogue: 0,{assclock(max(cut,t)-cut)},{assclock(until-cut)},Default,,0,0,0,,{label}')
 ass=dest/f'{cid}.ass'
 ass.write_text('[Script Info]\nScriptType: v4.00+\nPlayResX: 1280\nPlayResY: 792\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Noto Sans CJK SC,25,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1.5,0,2,20,20,10,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'+'\n'.join(dialogues)+'\n')
 header=dest/f'{cid}_header.txt';header.write_text(('M07｜八字运动平台：正常落台' if cid=='M07' else 'M18｜近地风险：安全退出（未落台）')+'\n实际 Gazebo 录屏 · 控制6e9b2c7 / v2 · 1倍墙钟速度')
 video=dest/('M07_八字平台落台.mp4' if cid=='M07' else 'M18_近地安全退出.mp4')
 filt=f'crop=1280:672:0:48,pad=1280:792:0:0:color=0x101820,drawtext=fontfile=/usr/local/share/fonts/hs-chinese/NotoSansCJK-Regular.ttc:textfile={header}:fontcolor=white:fontsize=23:x=20:y=690,ass={ass}'
 with (dest/f'{cid}_encode.log').open('x') as log:
  subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','warning','-n','-ss',str(cut),'-i',rec['video'],'-vf',filt,'-an','-r','10','-c:v','libx264','-preset','veryfast','-crf','21','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(video)],stdout=log,stderr=subprocess.STDOUT,check=True)
 checked=[]
 for f in (Path(rec['video']),video):
  with (dest/f'{cid}_{"raw" if f!=video else "delivered"}_decode.log').open('x') as log:
   subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-i',str(f),'-f','null','-'],stdout=log,stderr=subprocess.STDOUT,check=True)
  probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height:format=duration','-of','json',str(f)]))
  checked.append({'file':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'probe':probe,'full_decode_passed':True})
 meta.append(dict(case_id=cid,classification=expected,source_wall_trim_s=cut,wall_playback_speed=1,caption_source='Native UI observed every 0.25 wall seconds; exact control/contact timing belongs to raw audits',raw_and_delivered=checked))
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-ss',str((end-cut)*.6),'-i',str(video),'-frames:v','1','-y',str(dest/f'{cid}_preview.png')],check=True)
 print('ENCODED_AND_DECODE_VERIFIED',cid,flush=True)
(dest/'video_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))

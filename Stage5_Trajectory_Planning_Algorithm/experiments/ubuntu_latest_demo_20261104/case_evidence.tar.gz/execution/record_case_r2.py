"""Observe native GUI only; recording cannot stop or command the aircraft."""
from pathlib import Path
import sys,subprocess,os,time,json,signal,hashlib
w=Path('/workspace');root=w/'outputs/HS-FYP-/毕设仿真';out=w/'outputs/新版功能实录_20261104/batch_002';cid=sys.argv[1]
assert cid in ('M07','M18')
session=out/'cases'/cid/'attempt_001/session_001';video_dir=out/'videos';video_dir.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'tools'));import run_multicondition as m
m.verify_receipt(root,out,w/'work/reacquisition_20261102/deployment',root/'simulation/operator_package')
command=[sys.executable,str(root/'tools/run_multicondition.py'),'run','--resume','--case-id',cid,'--case-limit','1','--output',str(out),'--base',str(w/'work/reacquisition_20261102/deployment'),'--package',str(root/'simulation/operator_package'),'--source',str(w/'work/reacquisition_20261102/deployment/reference'),'--frozen',str(w/'work/reacquisition_20261102/deployment/baseline')]
env=dict(os.environ,HS_NO_GUI='0',QT_AUTO_SCREEN_SCALE_FACTOR='0',QT_ENABLE_HIGHDPI_SCALING='0',QT_SCALE_FACTOR='1',GDK_SCALE='1')
log=(out/f'{cid}_driver.log').open('x');child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
rec=None;rec_log=None;video=video_dir/f'{cid}_raw.mp4';record={};timeline=(video_dir/f'{cid}_timeline.jsonl').open('x');recording_error=None
try:
 while child.poll() is None:
  try:ui=json.loads((session/'status.json').read_text())
  except (OSError,ValueError):ui={}
  timeline.write(json.dumps(dict(wall_unix_s=time.time(),ui=ui),ensure_ascii=False)+'\n');timeline.flush()
  if rec is None and not record:
   for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
     cmd=(proc/'cmdline').read_bytes()
     argv=cmd.split(b'\0')
     if b'python' not in argv[0] or len(argv)<2 or not argv[1].endswith(b'operator_multicondition_supervisor.py'):continue
     pe=dict(v.decode().split('=',1) for v in (proc/'environ').read_bytes().split(b'\0') if b'=' in v)
     if pe.get('HS_OPERATOR_SESSION')!=str(session):continue
     for key in ('DISPLAY','XAUTHORITY'):os.environ[key]=pe[key]
     from run_functional_demo import gazebo_window
     wid=gazebo_window()
     if not wid:break
     rec_log=(video_dir/f'{cid}_ffmpeg.log').open('x')
     rec=subprocess.Popen(['ffmpeg','-nostdin','-hide_banner','-loglevel','warning','-n','-thread_queue_size','128','-f','x11grab','-draw_mouse','0','-framerate','10','-window_id',str(wid),'-i',pe['DISPLAY'],'-an','-c:v','libx264','-preset','ultrafast','-crf','23','-threads','1','-pix_fmt','yuv420p','-movflags','+frag_keyframe+empty_moov+default_base_moof','-g','30',str(video)],env=dict(os.environ),stdout=rec_log,stderr=subprocess.STDOUT)
     record=dict(case_id=cid,video=str(video),started_wall_unix_s=time.time(),display=pe['DISPLAY'],window_id=wid,control_commit='6e9b2c7fab50c045d58d0f1f8d0b078ea81ccd12',profile='planar_terminal_recovery_v2',wall_speed=1.0)
     print('RECORDING',cid,wid,flush=True)
     break
    except (OSError,ValueError,KeyError):continue
  if rec is not None and ui.get('stage') in ('COMPLETE','ERROR') and ui.get('armed') is False:
   if rec.poll() is None:rec.send_signal(signal.SIGINT)
   rec.wait(timeout=15);record.update(finished_wall_unix_s=time.time(),recorder_exit_code=rec.returncode,final_ui=ui)
   (video_dir/f'{cid}_recording.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));rec=None
  time.sleep(.25)
except Exception as exc:
 recording_error=repr(exc);(video_dir/f'{cid}_recording_error.json').write_text(json.dumps({'error':recording_error}))
 # Do not terminate physics if observer fails.
 child.wait()
finally:
 if rec is not None:
  if rec.poll() is None:rec.send_signal(signal.SIGINT)
  rec.wait(timeout=15);record.update(finished_wall_unix_s=time.time(),recorder_exit_code=rec.returncode)
  (video_dir/f'{cid}_recording.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
 if rec_log:rec_log.close()
 timeline.close();log.close()
(out/f'{cid}_runner_exit.json').write_text(json.dumps({'runner_exit_code':child.returncode,'recording_error':recording_error,'observer_has_no_flight_control':True}))
print('NATIVE_RUNNER_ENDED',cid,child.returncode,flush=True)
sys.exit(child.returncode if child.returncode else (4 if recording_error or not record else 0))

from pathlib import Path
import json,hashlib,tarfile,shutil,datetime
base=Path('/home/sheng-hao/Documents/Codex/2026-10-28/new-chat');work=base/'work/latest_demo_20261104';out=base/'outputs/新版功能实录_20261104';root=base/'outputs/HS-FYP-/毕设仿真';batch=out/'batch_002'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
# Current runtime and original receipt must still match after both flights.
receipt=json.loads((batch/'code_receipt.json').read_text())
for n,h in receipt['source_sha256'].items():
 assert sha(root/n)==h,n
 d=out/'fixed_source_6e9b2c7'/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/n,d)
for f in work.iterdir():
 if f.is_file() and f.suffix in ('.py','.log','.md','.png'):
  d=out/'execution_receipts'/f.name;d.parent.mkdir(exist_ok=True);shutil.copy2(f,d)
summary=[]
for b,c in [('batch_001','M07'),('batch_002','M07'),('batch_002','M18')]:
 result=json.loads((out/b/f'cases/{c}/attempt_001/result.json').read_text());assert result['supervisor_exit_code']==0 and result['source_configuration_integrity'] and result['request_history_ok'] and result['native_cycle_closed']['all_owned_cycle_processes_stopped']
 summary.append(dict(batch=b,case_id=c,category=result['category'],recording_available=(b=='batch_002'),supervisor_exit_code=0,safety=result['multicondition_audit']['safety']['passed'],physics=result['multicondition_audit']['physics']['passed'],coverage=result['multicondition_audit']['coverage']['passed']))
report=dict(control_commit=receipt['control_commit'],profile='planar_terminal_recovery_v2',physical_attempts=3,usable_recordings=2,attempts=summary,control_or_world_changes=False,safety_gates_relaxed=False,first_attempt='M07 physical success but recorder selected wrapper DISPLAY; no video, retained. batch002 had preparation-only receipt path error before any flight, retained logs.',historical_tests='274 tests are historical validation of the same runtime; not rerun in this recording task',new_boot_id='bad1645c-2bc2-49db-8ca2-2f84a6dbcacc',reboot_cause='unknown',raw_upload='Not full uploaded; same-disk archive only',scope='Actual two-case GUI demonstrations, not full twenty-case validation; M17 remains coverage_failure')
save(out/'新版实录结果.json',report)
archive_dir=base/'outputs/新版功能实录归档_20261104';archive_dir.mkdir(exist_ok=True);archive=archive_dir/'ubuntu_latest_demo_full_20261104.tar.gz';assert not archive.exists()
files=sorted(p for p in out.rglob('*') if p.is_file() and not p.is_symlink());links=sorted(p for p in out.rglob('*') if p.is_symlink())
manifest={str(p.relative_to(base)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
with tarfile.open(archive,'x:gz',compresslevel=6,dereference=False) as tar:
 for p in files+links:tar.add(p,arcname=str(p.relative_to(base)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 count=0
 for member in tar:
  if member.isfile():
   stream=tar.extractfile(member);h=hashlib.sha256()
   for block in iter(lambda:stream.read(1048576),b''):h.update(block)
   assert h.hexdigest()==manifest[member.name]['sha256'];count+=1
 assert count==len(files)
archive_receipt=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),regular_files=len(files),symbolic_links_not_expanded=len(links),all_regular_files_readback_verified=True,same_disk=True,offsite=False,full_raw_uploaded=False)
save(archive_dir/'archive_manifest.json',dict(files=manifest,symlinks={str(p.relative_to(base)):str(p.readlink()) for p in links}));save(archive_dir/'archive_receipt.json',archive_receipt)
# Standalone slim upload tree; preserve the canonical snapshot until GitHub verification.
dest=work/'upload/毕设仿真/experiments/ubuntu_latest_demo_20261104';dest.mkdir(parents=True,exist_ok=False)
def cp(src,rel):
 d=dest/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,d)
for f in (batch/'watchable').iterdir():
 if f.suffix in ('.mp4','.png','.ass','.txt','.json','.log'):cp(f,'videos/'+f.name)
for f in (batch/'plots').iterdir():cp(f,'plots/'+f.name)
for n in ['新版实录结果.json']:cp(out/n,n)
for n in ['严格交叉核验.json','code_receipt.json','environment_receipt.json','freeze_sha256.json','matrix.json']:cp(batch/n,n)
cp(archive_dir/'archive_receipt.json','RAW_ARCHIVE.json')
evidence=work/'compact_evidence';evidence.mkdir(exist_ok=False)
for b,c in [('batch_001','M07'),('batch_002','M07'),('batch_002','M18')]:
 attempt=out/b/f'cases/{c}/attempt_001';run=attempt/'session_001/cycle_001';key=f'{b}/{c}'
 selected=[attempt/'result.json',attempt/'declared_protocol.json',attempt/'supervisor.log',run/'results/execution_status.json',run/'results/cycle_closed.json',run/'results/multicondition_audit.json',run/'results/receding_session.json']
 selected += list((run/'results').glob('*audit*.json'))+list((run/'results').glob('*history*.json'))
 selected += [run/'config/experiments/receding_live_v1.json',run/'models/landing_vehicle/model.sdf',run/'worlds/uav_vehicle_stage1.sdf']
 # Include all actually retained planning JSON/JSONL/gzip history, not full controller/pose streams.
 selected += [p for p in (run/'runtime/receding_planner').rglob('*') if p.is_file() and (p.suffix in ('.json','.jsonl','.gz'))]
 for p in set(selected):
  if not p.exists():continue
  rel=p.relative_to(attempt);d=evidence/key/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
for f in work.iterdir():
 if f.is_file() and f.suffix in ('.py','.log','.md'):
  d=evidence/'execution'/f.name;d.parent.mkdir(exist_ok=True);shutil.copy2(f,d)
with tarfile.open(dest/'case_evidence.tar.gz','x:gz') as tar:
 for p in sorted(evidence.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(evidence)),recursive=False)
readme='''# 最新算法实际仿真录屏（2026-11-04）

控制固定6e9b2c7fab50c045d58d0f1f8d0b078ea81ccd12，显式planar_terminal_recovery_v2。本次没有修改控制、门限、平台世界轨迹或模型；只启用原有查看器，用外部观察器录制实际Gazebo窗口。

- [M07八字平台正常落台（原速）](videos/M07_八字平台落台.mp4)
- [M18近地风险安全退出（原速，未落台）](videos/M18_近地安全退出.mp4)

M07严格落台、正常停转及原审计通过；原始平台采样折线第二次通过自交点59.353200s，接触59.668s，间隔约0.314800s。交叉使用接触前原始轨迹线段，最大采样间隔0.034s；线性插值不是连续保证，也不代表完整24s周期。

M18正确安全退出、无平台接触，随后返回起飞点并原生落地停转；UI最终ERROR表示本次落台任务未完成，与独立审计correct_safe_exit分别保留，不把退出当作落台。两场原安全/物理/覆盖、请求历史与源码完整性均通过，监督器均0退出。

本轮总计3次实际飞行：首场M07物理完整通过，但外部录屏误连包装进程的显示、没有视频；第二批补录M07与M18各一次成功。首场原始数据和录屏错误保留。另有图形探针固定DISPLAY错误及补录准备回执路径错误，均未起飞，不计新增飞行。没有删失败凑2/2，也没有恢复大矩阵。

视频只裁掉起飞前等待和GUI顶栏，1倍墙钟速度；字幕依据0.25s墙钟采样的原生UI。两份原录屏和两份交付视频均完整解码通过；精确时刻看审计。原始录屏没有全量上传；video_manifest给出原始及交付文件SHA、时长。447运行源码、27部署、固定固件/插件及222环境资源核验；274项测试是此前同代码验证，本轮未重跑。运行前boot变化原因未知，未作硬件根因判断。

case_evidence.tar.gz含三次尝试原报告、实际配置/模型、原生关闭、执行凭据及实际保留的规划JSON历史；plots为明确抽样绘图数据。全频率原始位姿、控制反馈、DataFlash及原录屏留Linux，同盘全量归档位置和SHA见RAW_ARCHIVE.json，逐文件回读通过；未异地备份、未全量上传。

新版本轮只验证这两类功能，不称新版20工况全部通过。M17完整反向覆盖不足仍保留；旧X/Y/XY视频仍属748b27e历史版本。
'''
(dest/'README.md').write_text(readme)
print(json.dumps(dict(archive=archive_receipt,upload_files=len([p for p in dest.rglob('*') if p.is_file()]),dest=str(dest)),ensure_ascii=False),flush=True)

"""Read-only raw platform polyline self-intersection witness before contact."""
from pathlib import Path
import json,gzip,math,hashlib
w=Path('/workspace');base=w/'outputs/八字交叉覆盖复测_20261103/batch_001'
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return(a[0]-b[0],a[1]-b[1])
def intersections(times,points):
 out=[]
 for i in range(len(times)-1):
  p=points[i];r=sub(points[i+1],p);nr=math.hypot(*r)
  if nr/(times[i+1]-times[i])<=.04:continue
  for j in range(i+2,len(times)-1):
   if times[j]-times[i+1]<2.:continue
   q=points[j];s=sub(points[j+1],q);ns=math.hypot(*s);den=cross(r,s)
   if ns/(times[j+1]-times[j])<=.04 or abs(den)<1e-12:continue
   cosine=(r[0]*s[0]+r[1]*s[1])/(nr*ns)
   if abs(cosine)>=.9:continue
   u=cross(sub(q,p),s)/den;v=cross(sub(q,p),r)/den
   if 0<=u<=1 and 0<=v<=1:
    out.append({'first_segment_sim_s':times[i:i+2],'second_segment_sim_s':times[j:j+2],'first_pass_interpolated_sim_s':times[i]+u*(times[i+1]-times[i]),'second_pass_interpolated_sim_s':times[j]+v*(times[j+1]-times[j]),'intersection_world_xy_m':[p[0]+u*r[0],p[1]+u*r[1]],'distinct_tangent_cosine':cosine,'raw_segment_indices':[i,j]})
 return out
# Check strict segment crossing against a known figure and a noncrossing path.
assert intersections([0,1,3,4,5],[(0,0),(1,1),(1,0),(0,1),(0,2)])
assert not intersections([0,1,2,3,4],[(0,0),(1,0),(2,0),(3,0),(4,0)])
def inspect(run):
 res=run/'results';status=json.loads((res/'execution_status.json').read_text());events=json.loads((res/'receding_session.json').read_text())['events'];start=next(e['time'] for e in events if e['event']=='PLANAR_INITIAL_FOLLOW');end=(status.get('first_contact') or {}).get('contact_sim_t_s')
 if end is None:end=next((json.loads(l)['sim_t_s'] for l in (res/'receding_control.jsonl').read_text().splitlines() if (json.loads(l).get('planar_supervision') or {}).get('action')=='EXIT'),None)
 assert end is not None
 raw=res/'model_states.jsonl';stream=raw.open('rb') if raw.exists() else gzip.open(raw.with_suffix('.jsonl.gz'),'rb');samples={};digest=hashlib.sha256()
 with stream:
  for l in stream:
   digest.update(l);d=json.loads(l)
   if d['kind']!='car_pose':continue
   for p in d['message'].get('pose',[]):
    if p['name']!='landing_vehicle':continue
    stamp=p['header']['stamp'];t=float(stamp.get('sec',0))+float(stamp.get('nsec',0))*1e-9
    if start<=t<=end:samples[t]=(float(p.get('position',{}).get('x',0.)),float(p.get('position',{}).get('y',0.)))
 times=sorted(samples);points=[samples[t] for t in times];hits=intersections(times,points)
 return {'passed':bool(hits),'scope':'Actual raw platform XY polyline before physical contact/policy exit. Segment witnesses use linear interpolation between raw samples, not a continuous-time guarantee or a future reference. No .12m near-pass tolerance used.','world_start_sim_t_s':start,'contact_or_exit_sim_t_s':end,'elapsed_to_contact_or_exit_s':end-start,'raw_platform_samples':len(times),'raw_max_gap_s':max(b-a for a,b in zip(times,times[1:])),'raw_uncompressed_sha256':digest.hexdigest(),'witnesses':hits}
old=w/'outputs/二维多工况_20261103/batch_002/cases/M07/attempt_001/session_001/cycle_001';new=base/'cases/M07/attempt_001/session_001/cycle_001';report={'original':inspect(old),'slow_terminal':inspect(new)};(base/'接触前实际交叉独立核验.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))

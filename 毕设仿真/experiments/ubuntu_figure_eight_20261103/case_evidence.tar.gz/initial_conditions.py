from pathlib import Path
import json,gzip
out=Path('/workspace/outputs/八字交叉覆盖复测_20261103/batch_001');res=out/'cases/M07/attempt_001/session_001/cycle_001/results';first={}
with gzip.open(res/'model_states.jsonl.gz','rt') as f:
 for line in f:
  d=json.loads(line)
  if d['kind'] not in ('car_pose','uav_pose'):continue
  for p in d['message'].get('pose',[]):
   if p['name'] not in ('uav','landing_vehicle') or p['name'] in first:continue
   s=p['header']['stamp'];first[p['name']]={'sim_t_s':float(s.get('sec',0))+float(s.get('nsec',0))*1e-9,'model_origin_position_world_m':[float(p.get('position',{}).get(k,0.)) for k in 'xyz']}
  if len(first)==2:break
rows=[json.loads(l) for l in (res/'receding_control.jsonl').read_text().splitlines()]
def report(row):return {'sim_t_s':row['sim_t_s'],'body_origin_world_m':row['observation']['motion']['pose']['position_world_m'],'deck_surface_world_m':row['measured_deck']['motion']['pose']['position_world_m'],'minimum_foot_clearance_m':min(f['clearance_m'] for f in row['feet'])}
permitted=next(r for r in rows if (r.get('planar_supervision') or {}).get('action')=='DESCEND');tracking=next(r for r in rows if r.get('planner_phase')=='TRACKING')
d={'first_actual_raw_model_poses':first,'first_control_sample':report(rows[0]),'first_policy_descent_permission':report(permitted),'first_tracking_sample':report(tracking),'scope':'Actual initial model origins are distinct from measured deck surface and the4m follow target. Descent permission and first tracking are separately measured; no initial-height performance comparison.'};(out/'初始化与首次下降实测.json').write_text(json.dumps(d,ensure_ascii=False,indent=2));print(json.dumps(d,ensure_ascii=False))

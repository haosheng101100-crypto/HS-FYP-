"""Scientific figures and plain-language progress report from saved evidence."""
import argparse,json,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main(root):
    s=json.loads((root/'summary.json').read_text());cal=json.loads((root/'calibration_evaluation.json').read_text())
    model=json.loads((root/'calibration_model.json').read_text());stress=json.loads((root/'monitor_stress_summary.json').read_text())
    with (root/'时间记录/仿真时间记录.csv').open(encoding='utf-8-sig') as f:times=list(csv.DictReader(f))
    stats={}
    for category in ('ablation','boundary'):
        rs=[r for r in s if r['spec']['category']==category];weights=[r['common'] for r in rs]
        stats[category]={m:{k:float(np.average([r['methods'][m][k] for r in rs],weights=weights)) for k in ('common_ade_m','common_fde_m')} for m in ('IMM','CT','CV','CA')}
    cstats={}
    for category in ('same_grid_test','boundary_shift'):
        rs=[r for r in cal if r['category']==category]
        cstats[category]={when:{k:float(np.mean([r['diagnostic'][when][k] for r in rs])) for k in rs[0]['diagnostic'][when]} for when in ('before','after')}
    plt.rcParams.update({'font.family':'Noto Sans CJK SC','axes.unicode_minus':False,'font.size':10})
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    x=np.arange(2)
    for j,(m,label,col) in enumerate((('IMM','多模型','#13796d'),('CT','单 CT 模型','#3672ad'))):
        axes[0,0].bar(x+(j-.5)*.32,[stats[c][m]['common_ade_m'] for c in ('ablation','boundary')],width=.32,label=label,color=col)
    axes[0,0].set(xticks=x,xticklabels=['原参数网格测试','补充边界测试'],ylabel='平均位置误差 / 米',title='相同输入、相同总采样数的对比');axes[0,0].legend()
    for j,(when,label,col) in enumerate((('before','校准前','#9dadd1'),('after','校准后','#13796d'))):
        axes[0,1].bar(x+(j-.5)*.32,[cstats[c][when]['trajectory_joint_coverage']*100 for c in ('same_grid_test','boundary_shift')],width=.32,label=label,color=col)
        axes[1,0].bar(x+(j-.5)*.32,[cstats[c][when]['mean_sum_box_area_m2'] for c in ('same_grid_test','boundary_shift')],width=.32,label=label,color=col)
    axes[0,1].set(xticks=x,xticklabels=['原参数网格测试','补充边界测试'],ylabel='百分比',ylim=(0,105),title='整段位置 / 速度 / 航向包含率');axes[0,1].legend()
    axes[1,0].set(xticks=x,xticklabels=['原参数网格测试','补充边界测试'],ylabel='各模式面积之和 / 平方米',title='包含率提升，同时范围明显增大');axes[1,0].legend()
    state_map={'warming_up':0,'ready_uncalibrated':1,'warning':2,'stale':3,'degraded':4,'unreliable_innovation':5,'unreliable_error':6}
    for r,label in zip(stress,['观测中断','观测偏移']):
        axes[1,1].step([p['now'] for p in r['issue_states']],[state_map[p['monitor']['state']] for p in r['issue_states']],where='post',label=label)
    axes[1,1].axvspan(4.,5.5,color='#b96b37',alpha=.1)
    axes[1,1].set(xlabel='场景时间 / 秒',yticks=list(state_map.values()),yticklabels=['预热','就绪','提醒','过期','退化','观测异常','误差异常'],title='失效监测：阴影内注入故障');axes[1,1].legend()
    for ax in axes.flat:ax.grid(axis='y',alpha=.15)
    fig.suptitle('边界验证、单模型对照、延迟核对和初版校准',fontsize=16)
    fig.savefig(root/'推进结果对比.png',dpi=170);plt.close(fig)
    bias=stress[1]['first_innovation_alarm_received_at']-4.
    rows='\n'.join(f"| {m} | {stats['ablation'][m]['common_ade_m']:.3f} | {stats['ablation'][m]['common_fde_m']:.3f} | {stats['boundary'][m]['common_ade_m']:.3f} | {stats['boundary'][m]['common_fde_m']:.3f} |" for m in ('IMM','CT','CV','CA'))
    sim=[r for r in times if r['operation']=='simulation'];offline=[r for r in times if r['operation']=='offline_evaluation']
    report=f'''# 第六阶段推进记录：边界验证与误差管理初版

已补做第 5 步的边界验证和单模型对照，并实现第 6 步的延迟误差队列、独立校准和初版失效监测。原始 v0.1 预测核心未修改。第 7 步甲板接口验收和第 8 步降落闭环尚待继续。

## 每次仿真的时间记录

本轮新增 {len(sim)} 次仿真、{len(offline)} 次离线评分，全部逐次记录开始、结束、真实耗时、场景时长、协议哈希、种子和结果路径。时间为北京时间，开始于 {times[0]['started_at']}，本轮最后一次结束于 {times[-1]['ended_at']}。单个场景均为 12 秒；这与实际计算耗时不同。

- [按时间回看每个批次](时间记录/仿真时间记录.md)
- [下载 CSV 时间表](时间记录/仿真时间记录.csv)
- events.jsonl 是原始开始/结束事件，CSV 与表格由它生成；异常退出的开始事件会保留。恢复末尾不完整写入时另存原始片段，不补造时间。

上一轮的 26 个批次未逐次记录墙上时钟起止时间，本轮不追补猜测值。单元测试中的短小合成样例列在测试报告，不计作完整仿真。

## 第 5 步补充结果

12 个原测试参数批次重新做单 CT 模型对照，另有 8 类边界 × 2 个随机种子，共 16 个边界批次：停车、低速、倒车，以及速度、曲率、侧向加速度、加速度/急动度、曲率变化率接近通用限制的情况。每项物理限制至少在一个场景中达到设定上限的 98%，真值网格未超限。这仍不是多维边界组合的穷尽覆盖，也不是实车参数辨识。

IMM 每模式请求 12 条、四模式共 48 条；单 CT 请求 48 条，最大候选池各为 960 条。观测、时间、安装偏移相同，状态模型和有效记忆不同，运行耗时逐次保留。误差只比较四个方法都有点预测的相同时刻；缺失预测另计可用性。

| 方法 | 原网格 ADE/m | 原网格两秒 FDE/m | 边界 ADE/m | 边界两秒 FDE/m |
|---|---:|---:|---:|---:|
{rows}

多模型在原网格整体较好，但在补充边界上单模型平均更好。特别是高加速度/高急动度场景，IMM ADE 约 0.87–0.95 m，CT 约 0.56–0.57 m。停车、低速等情况也并非多模型更好。没有根据这些结果调模型参数或删除场景。

## 第 6 步初版

延迟队列先保存发出的预测，直到各目标时刻的核对数据真实收到后才评分。按目标时间精确匹配，缺失不插值，超过最后目标时间加 0.3 秒仍缺失就单独结算。28 个主验证批次均把 19 次正式预测的延迟评分与离线评分核对一致（坐标浮点容差 1e-10）。

校准使用之前预留的 12 个独立批次；每批先取可用预测整段误差分数的最大值，再取整批分数的顺序统计量。目标设置为 90%，由于样本少，本轮取到 12 个分数中的最大值，{model['padding_units']:.4f} 个归一化单位，对应每侧位置扩大约 {model['padding_units']*.1:.3f} m、每个速度分量扩大约 {model['padding_units']*.2:.3f} m/s、航向半径增加约 {model['padding_units']*.1:.3f} rad。校准文件写入后才读取测试批次评估。

原参数网格测试的整段联合包含率从 {cstats['same_grid_test']['before']['trajectory_joint_coverage']:.2%} 提高到 {cstats['same_grid_test']['after']['trajectory_joint_coverage']:.2%}，但各模式位置包络框面积之和从 {cstats['same_grid_test']['before']['mean_sum_box_area_m2']:.3f} 增至 {cstats['same_grid_test']['after']['mean_sum_box_area_m2']:.3f} m²，约 {cstats['same_grid_test']['after']['mean_sum_box_area_m2']/cstats['same_grid_test']['before']['mean_sum_box_area_m2']:.1f} 倍。不可用的范围依然不可用；没有用扩张生成空分支。边界偏移测试整段联合包含率从 {cstats['boundary_shift']['before']['trajectory_joint_coverage']:.2%} 提高到 {cstats['boundary_shift']['after']['trajectory_joint_coverage']:.2%}。

这些是有限测试下的经验结果。固定异质参数网格没有建立交换性，不能宣称已获得部署时 90% 概率保证；样本包络扩张内部也不保证满足车辆动力学。采样轨迹本身保持不变。这版校准偏保守，不能把较高包含率直接等同于更适合降落。

初版监测对实际观测更新的创新量和已经成熟的误差计数。连续 3 次异常触发，连续 5 次对应正常数据恢复；没有新数据时不会靠重复调用预测清除报警。阈值固定为创新 NIS 16.27、两秒末误差 0.5 m，是待验证的仿真设定。

两项故障注入结果：观测中断时，4.5/5.0/5.5 秒报告过期，6.0 秒重新预热，6.5 秒恢复就绪；故意缺失 5.2 秒的核对标签导致 4 条重叠预测记录 missing_labels，未被悄悄删除。另一批注入 1 m 平面观测偏移，在故障开始约 {bias:.2f} 个场景秒后触发创新异常，之后的误差异常也保留。

**当前延迟误差和校准验证使用独立仿真真值作为核对源。实车没有自动获得这个真值传感器；后续需接入可追溯测量或明确有噪声的误差估计。** 监测结果只作诊断，不发出降落许可。

![推进结果对比](推进结果对比.png)

## 当前进度与接续

第 5 步已增加边界和单模型证据，仍有高动态预测不足。第 6 步初版功能与因果链路已经跑通，仍需改进范围紧致程度、验证阈值和实车核对源。第 7 步下一步会统一车辆到甲板的位置、速度、朝向、边界和时间接口，并保留上述可用性信息；第 8 步再与第五阶段降落仿真闭环联调。

完整数据在 results/、calibration_runs/、monitor_stress/；每个批次有真值、观测、压缩预测及评分。没有开展飞控接入、闭环降落或成功率验证。本轮文件本地保存，未更新 GitHub。
'''
    (root/'进度与结果说明.md').write_text(report,encoding='utf-8')
    print('Created report and comparison figure.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);main(p.parse_args().output)

"""Logged independent boundary runs and equal-sample-count single-CT ablation."""
import argparse,gzip,json,hashlib
from collections import Counter
from pathlib import Path
from dataclasses import asdict
import numpy as np
from simulation.world import World,generate
from simulation.benchmark import HORIZONS,point_errors,score_packet
from simulation.results import lookup
from extensions.boundary import BoundaryWorld,CASES
from extensions.pipeline import paired_online
from extensions.journal import RunJournal


def write_json(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def save_data(folder,data):
    np.savez_compressed(folder/'truth.npz',**data['truth']);write_json(folder/'truth_audit.json',data['audit'])
    with (folder/'observations.jsonl').open('w') as f:
        for o in data['observations']:
            d=asdict(o);d['covariance']=o.covariance.tolist();f.write(json.dumps(d,allow_nan=False)+'\n')


def score_rows(rows):
    methods=('IMM','CT','CV','CA');common=[r for r in rows if all(r['metrics'][m] is not None for m in methods)]
    result={}
    for method in methods:
        available=[r['metrics'][method] for r in rows if r['metrics'][method] is not None]
        c=[r['metrics'][method] for r in common]
        result[method]=dict(available=len(available),common_ade_m=float(np.mean([x['ade_m'] for x in c])) if c else None,
                            common_fde_m=float(np.mean([x['fde_m'] for x in c])) if c else None)
    return dict(scheduled=len(rows),common=len(common),methods=result)


def main(output):
    output.mkdir(parents=True,exist_ok=True);results=output/'results';results.mkdir(exist_ok=False)
    journal=RunJournal(output/'时间记录')
    original=json.loads((Path(__file__).parent/'simulation/manifest.json').read_text())
    specs=[dict(id='ablation_'+r['id'],category='ablation',world=r['world'],seed=r['seed']) for r in original['runs'] if r['split']=='test']
    specs += [dict(id=c['id']+'_'+str(seed),category='boundary',world=c['world'],seed=seed) for c in CASES for seed in (501,502)]
    protocol=dict(version=2,duration_s=12.,clocks_s='0:0.5:12.5; issue only through 10',scored_s=[1.,10.],
                  IMM_particles_per_mode=12,CT_particles=48,sample_budget='48 total requested paths each; 960 evaluated candidates each when all modes propagate',
                  labels='Independent simulator ground truth, receipt=stamp+0.05, 0.1 s grid. Evaluation only, never predictor input.',
                  cases=specs,code_sha256={str(p.relative_to(Path(__file__).parent)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ('extensions','simulation','stage6') for p in (Path(__file__).parent/d).glob('*.py')})
    write_json(output/'protocol.json',protocol);summaries=[]
    for spec in specs:
        folder=results/spec['id'];folder.mkdir()
        with journal.run(spec['id'],dict(spec=spec,protocol_sha256=hashlib.sha256((output/'protocol.json').read_bytes()).hexdigest()),12.,folder):
            world=BoundaryWorld(**spec['world']) if spec['category']=='boundary' else World(**spec['world'])
            data=generate(world,spec['seed']);save_data(folder,data)
            if data['audit']['violations']:raise RuntimeError('Invalid truth bounds')
            truth=data['truth'];labels=[]
            for t in np.arange(121)*.1:
                xy,v,yaw=lookup(truth,[t]);labels.append(dict(stamp=float(t),received_at=float(t+.05),position_xy=xy[0].tolist(),velocity_xy=v[0].tolist(),yaw=float(yaw[0])))
            rows=[];matured=[];states=Counter();status={m:Counter() for m in ('IMM','CT')}
            with gzip.open(folder/'forecasts.jsonl.gz','wt',encoding='utf-8') as f:
                for issued in paired_online(data['observations'],np.arange(26)*.5,labels):
                    f.write(json.dumps(issued,allow_nan=False,separators=(',',':'))+'\n');matured.extend(issued['matured'])
                    if issued['packet'] is None:continue
                    states[issued['monitor']['state']]+=1
                    for m,k in (('IMM','packet'),('CT','CT_packet')):status[m][issued[k]['status']]+=1
                    if issued['now']<1.:continue
                    xy,v,yaw=lookup(truth,issued['now']+HORIZONS)
                    candidates=dict(IMM=issued['point'],CT=issued['CT_point'],**issued['baselines'])
                    metrics={k:None if p['xy'] is None else point_errors(p['xy'],xy) for k,p in candidates.items()}
                    rows.append(dict(now=issued['now'],metrics=metrics,runtime=issued['runtime'],monitor=issued['monitor'],
                                     coverage={k:score_packet(issued[key],xy,v,yaw) for k,key in (('IMM','packet'),('CT','CT_packet'))}))
            delayed=[e for e in matured if e['issued_at']>=1.]
            assert len(delayed)==19
            for row,event in zip(rows,delayed):
                assert row['now']==event['issued_at']
                if event['status']=='complete':
                    if event['metrics'] is None:assert row['metrics']['IMM'] is None
                    else:
                        for key in ('ade_m','fde_m','errors_m'):
                            np.testing.assert_allclose(event['metrics'][key],row['metrics']['IMM'][key],rtol=1e-10,atol=1e-10)
                    assert event['coverage']==row['coverage']['IMM']
            write_json(folder/'scores.json',rows);write_json(folder/'delayed_scores.json',matured)
            summary=dict(spec=spec,**score_rows(rows),statuses={k:dict(v) for k,v in status.items()},monitor_states=dict(states),
                         delayed_completed=sum(e['status']=='complete' for e in delayed),
                         coverage={m:{k:float(np.mean([r['coverage'][m][k] for r in rows])) for k in rows[0]['coverage'][m]} for m in ('IMM','CT')})
            write_json(folder/'summary.json',summary);summaries.append(summary)
        print(spec['id'],summary['methods']['IMM']['common_ade_m'],summary['methods']['CT']['common_ade_m'],flush=True)
    write_json(output/'summary.json',summaries)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);main(p.parse_args().output)

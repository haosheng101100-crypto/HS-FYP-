"""Reserve-only run calibration; evaluate frozen padding on separate test runs."""
import argparse,gzip,json,hashlib
from pathlib import Path
import numpy as np
from extensions.pipeline import paired_online
from extensions.calibration import fit_run_scores,expand_packet,trajectory_score
from extensions.journal import RunJournal
from simulation.world import World,generate
from simulation.results import lookup
from simulation.benchmark import HORIZONS,score_packet
from run_validation import write_json,save_data


def main(output):
    folder=output/'calibration_runs';folder.mkdir(exist_ok=False)
    journal=RunJournal(output/'时间记录')
    manifest=json.loads((Path(__file__).parent/'simulation/manifest.json').read_text())
    specs=[r for r in manifest['runs'] if r['split']=='calibration_reserved']
    protocol=dict(target=.9,scales=dict(position_m=.1,velocity_mps=.2,yaw_rad=.1),
                  aggregation='Max over available scored issue trajectories within each entire run; min over modes after max across horizon/components.',
                  availability='Missing boxes remain unavailable. No calibration can create them.',
                  cases=specs,code_sha256={str(p.relative_to(Path(__file__).parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__).parent/'extensions').glob('*.py')})
    write_json(output/'calibration_protocol.json',protocol)
    scores=[]
    for spec in specs:
        result=folder/spec['id'];result.mkdir()
        with journal.run('cal_'+spec['id'],dict(spec=spec,protocol_sha256=hashlib.sha256((output/'calibration_protocol.json').read_bytes()).hexdigest()),12.,result):
            data=generate(World(**spec['world']),spec['seed']);save_data(result,data)
            labels=[]
            for t in np.arange(121)*.1:
                xy,v,yaw=lookup(data['truth'],[t]);labels.append(dict(stamp=float(t),received_at=float(t+.05),position_xy=xy[0].tolist(),velocity_xy=v[0].tolist(),yaw=float(yaw[0])))
            matured=[]
            with gzip.open(result/'forecasts.jsonl.gz','wt',encoding='utf-8') as f:
                for record in paired_online(data['observations'],np.arange(26)*.5,labels):
                    f.write(json.dumps(record,separators=(',',':'),allow_nan=False)+'\n');matured.extend(record['matured'])
            scored=[x for x in matured if x['issued_at']>=1.];available=[x['calibration_score'] for x in scored if x['calibration_score'] is not None]
            if not available:raise RuntimeError('No usable calibration issues: '+spec['id'])
            score=dict(run_id=spec['id'],split='calibration',score=max(available),available=len(available),scheduled=len(scored))
            scores.append(score);write_json(result/'delayed_scores.json',matured);write_json(result/'run_score.json',score)
        print(spec['id'],score['score'],flush=True)
    # Freeze fit BEFORE opening any test predictions below.
    model=fit_run_scores(scores,.9);write_json(output/'calibration_model.json',model);write_json(output/'calibration_run_scores.json',scores)
    evaluations=[]
    for result in sorted((output/'results').iterdir()):
        if not (result/'truth.npz').exists():continue
        category='same_grid_test' if result.name.startswith('ablation_') else 'boundary_shift'
        with journal.run('cal_eval_'+result.name,dict(operation='offline_evaluation',category=category,source=str(result),model_sha256=hashlib.sha256((output/'calibration_model.json').read_bytes()).hexdigest()),12.,result/'calibrated_diagnostics.json'):
            truth=dict(np.load(result/'truth.npz'));rows=[]
            with gzip.open(result/'forecasts.jsonl.gz','rt') as f:
                for line in f:
                    r=json.loads(line)
                    if r['packet'] is None or r['now']<1.:continue
                    xy,v,yaw=lookup(truth,r['now']+HORIZONS)
                    score=trajectory_score(r['packet'],xy,v,yaw)
                    rows.append(dict(now=r['now'],before=score_packet(r['packet'],xy,v,yaw),
                                     after=score_packet(expand_packet(r['packet'],model['padding_units']),xy,v,yaw),score=score))
            available=[r['score'] for r in rows if r['score'] is not None]
            summary=dict(run_id=result.name,category=category,scheduled=len(rows),available=len(available),
                         all_available_issues_joint_covered=bool(available and max(available)<=model['padding_units']),
                         diagnostic={when:{k:float(np.mean([r[when][k] for r in rows])) for k in rows[0][when]} for when in ('before','after')})
            write_json(result/'calibrated_diagnostics.json',dict(summary=summary,rows=rows));evaluations.append(summary)
    write_json(output/'calibration_evaluation.json',evaluations)
    print('Frozen padding:',model['padding_units'],flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);main(p.parse_args().output)

"""Receipt-gated delayed labels. Labels never enter a state predictor."""
from copy import deepcopy
import math
import numpy as np
from simulation.benchmark import point_errors


def tick(t):return round(t*1_000_000_000)


class DelayedQueue:
    def __init__(self,grace_s=.3):
        if not math.isfinite(grace_s) or grace_s<0:raise ValueError('Invalid grace')
        self.grace=grace_s;self.now=0.;self.pending={};self.labels={};self.seen=set()

    def issue(self,key,issued_at,packet,point_xy):
        if not math.isclose(issued_at,self.now,abs_tol=1e-9):raise ValueError('Issue clock mismatch')
        if key in self.seen:raise ValueError('Duplicate forecast ID')
        h=np.asarray(packet['horizons_s'],dtype=float)
        if h.ndim!=1 or not len(h) or not np.all(np.isfinite(h)) or h[0]<=0 or np.any(np.diff(h)<=0):
            raise ValueError('Invalid targets')
        if point_xy is not None and (np.shape(point_xy)!=(len(h),2) or not np.all(np.isfinite(point_xy))):
            raise ValueError('Invalid point forecast')
        self.pending[key]=dict(issued_at=issued_at,targets=(issued_at+h).tolist(),packet=deepcopy(packet),point_xy=deepcopy(point_xy))
        self.seen.add(key)

    def advance(self,now,labels=()):
        if not math.isfinite(now) or now<self.now:raise ValueError('Clock must be monotone')
        staged={}
        for label in labels:
            t=label['stamp'];received=label['received_at']
            if not np.all(np.isfinite([t,received,label['yaw'],*label['position_xy'],*label['velocity_xy']])) or t>received+1e-9 or received>now+1e-9:
                raise ValueError('Label not yet received or invalid')
            key=tick(t)
            if key in self.labels or key in staged:raise ValueError('Duplicate label timestamp')
            staged[key]=deepcopy(label)
        self.now=float(now);self.labels.update(staged);done=[]
        for key,p in list(self.pending.items()):
            deadline=p['targets'][-1]+self.grace
            missing=[t for t in p['targets'] if tick(t) not in self.labels or self.labels[tick(t)]['received_at']>deadline+1e-9]
            if missing and now<deadline-1e-9:continue
            result=dict(key=key,issued_at=p['issued_at'],completed_at=float(now),deadline=deadline,
                        status='missing_labels' if missing else 'complete',missing_targets=missing,packet=p['packet'],metrics=None,labels=None)
            if not missing:
                values=[self.labels[tick(t)] for t in p['targets']]
                result['labels']=values
                if p['point_xy'] is not None:
                    result['metrics']=point_errors(p['point_xy'],[x['position_xy'] for x in values])
            done.append(result);del self.pending[key]
        # Past labels cannot help a later issue, whose targets must be future.
        earliest=min((tick(t) for p in self.pending.values() for t in p['targets']),default=tick(now)+1)
        self.labels={k:v for k,v in self.labels.items() if k>=earliest}
        return done

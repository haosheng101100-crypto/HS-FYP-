"""Causal predictor/evaluator wiring; labels are simulator evaluation signals only."""
from time import perf_counter
import numpy as np
from stage6.predictor import VehiclePredictor
from simulation.world import OFFSET
from simulation.benchmark import HORIZONS,mean_forecast,polynomial_forecast,score_packet
from .single_model import SingleCT
from .delayed import DelayedQueue
from .monitor import TrustMonitor
from .calibration import trajectory_score


def paired_online(observations,clocks,labels=(),imm_particles=12,ct_particles=48):
    imm=VehiclePredictor(OFFSET);ct=SingleCT(OFFSET);queue=DelayedQueue();monitor=TrustMonitor()
    observations=list(observations);labels=list(labels);history=[];oi=li=0;emission=0
    clock=np.asarray(clocks,dtype=float)
    if clock.ndim!=1 or not np.all(np.isfinite(clock)) or clock[0]<0 or np.any(np.diff(clock)<=0):raise ValueError('Invalid clock')
    if any(a.received_at>b.received_at for a,b in zip(observations,observations[1:])):raise ValueError('Unsorted observations')
    if any(a['received_at']>b['received_at'] for a,b in zip(labels,labels[1:])):raise ValueError('Unsorted labels')
    for now in clock:
        update_ms={'IMM':[],'CT':[]};innovation_events=[]
        while oi<len(observations) and observations[oi].received_at<=now+1e-9:
            o=observations[oi]
            for name,p in (('IMM',imm),('CT',ct)):
                start=perf_counter();p.update(o);update_ms[name].append((perf_counter()-start)*1000)
            nis=[f.last_nis for f in imm.filters];monitor.observe_innovation(nis)
            innovation_events.append(dict(stamp=o.stamp,received_at=o.received_at,nis=nis,
                                          latched=dict(monitor.latched),consecutive_high=dict(monitor.high)))
            history.append(o);oi+=1
        available=[]
        while li<len(labels) and labels[li]['received_at']<=now+1e-9:
            available.append(labels[li]);li+=1
        matured=queue.advance(float(now),available)
        for e in matured:
            monitor.observe_error(e,float(now))
            if e['status']=='complete':
                xy=np.array([l['position_xy'] for l in e['labels']]);vel=np.array([l['velocity_xy'] for l in e['labels']]);yaw=np.array([l['yaw'] for l in e['labels']])
                e['coverage']=score_packet(e['packet'],xy,vel,yaw)
                e['calibration_score']=trajectory_score(e['packet'],xy,vel,yaw)
            else:e.update(coverage=None,calibration_score=None)
            e.pop('packet');e.pop('labels')
        out=dict(now=float(now),packet=None,CT_packet=None,point=None,CT_point=None,baselines={},matured=matured,
                 runtime=dict(update_ms=update_ms),monitor=None,innovation_events=innovation_events)
        if now<=10.+1e-9:
            for name,p,n,packet_key,point_key in (('IMM',imm,imm_particles,'packet','point'),('CT',ct,ct_particles,'CT_packet','CT_point')):
                start=perf_counter();out[packet_key]=p.forecast(float(now),particles_per_mode=n,seed=1000+emission)
                out[point_key]=mean_forecast(out[packet_key]);out['runtime'][name+'_forecast_ms']=(perf_counter()-start)*1000
            for degree,name in ((1,'CV'),(2,'CA')):
                start=perf_counter();out['baselines'][name]=polynomial_forecast(history,now,HORIZONS,degree,OFFSET)
                out['runtime'][name+'_forecast_ms']=(perf_counter()-start)*1000
            out['monitor']=monitor.inspect(out['packet'])
            queue.issue(str(emission),float(now),out['packet'],out['point']['xy']);emission+=1
        yield out

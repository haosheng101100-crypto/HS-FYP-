"""Fixed single CT UKF ablation; no IMM interaction or switching."""
from dataclasses import asdict
import numpy as np
from stage6.filter import initialize
from stage6.model import MODES
from stage6.predictor import VehiclePredictor


class SingleCT(VehiclePredictor):
    def __init__(self,offset=(0.,0.)):
        super().__init__(offset);self.weights=np.ones(1)

    def update(self,o):
        if self.latest is not None and (o.stamp<=self.latest.stamp or o.received_at<self.latest.received_at):
            raise ValueError('Out-of-order observations')
        restart=self.latest is None or o.stamp-self.latest.stamp>1.
        if restart:
            f=initialize(o,MODES[2],self.offset)
            if self.latest is not None:self.reset_count+=1
            self.first_stamp=o.stamp;self.sample_count=1
        else:
            f=self.filters[0].clone();f.predict(o.stamp-self.latest.stamp);f.update(o)
            self.sample_count+=1
        self.filters=[f];self.latest=o

    def forecast(self,*args,**kwargs):
        packet=super().forecast(*args,**kwargs)
        packet['configuration']['modes']=[asdict(MODES[2])]
        packet['configuration']['mode_transition_offdiagonal_rate_per_s']=None
        packet['configuration']['estimator']='single_CT_UKF_without_IMM'
        return packet

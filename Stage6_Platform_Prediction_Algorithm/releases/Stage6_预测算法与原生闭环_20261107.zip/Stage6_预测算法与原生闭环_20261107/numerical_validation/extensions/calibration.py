"""Whole-run score calibration of finite sample boxes, conditional on availability.

No physical-reachability claim. Exchangeability is not assumed for the fixed
heterogeneous parameter grid; order-statistic targets are diagnostic only.
"""
from copy import deepcopy
import math
import numpy as np

SCALES=dict(position_m=.1,velocity_mps=.2,yaw_rad=.1)


def trajectory_score(packet,xy,velocity,yaw):
    scores=[]
    for model in packet['models']:
        e=model.get('sample_envelope')
        if e is None:continue
        pos=np.maximum(np.asarray(e['position_min'])-xy,np.asarray(xy)-e['position_max'])/.1
        vel=np.maximum(np.asarray(e['velocity_min'])-velocity,np.asarray(velocity)-e['velocity_max'])/.2
        angle=np.abs((np.asarray(yaw)-e['yaw_center']+np.pi)%(2*np.pi)-np.pi)
        angle=(angle-np.asarray(e['yaw_radius']))/.1
        scores.append(float(max(0.,pos.max(),vel.max(),angle.max())))
    return min(scores) if scores else None


def fit_run_scores(records,target=.9):
    if not 0<target<1 or not records:raise ValueError('Invalid calibration target/data')
    if any(r['split']!='calibration' for r in records):raise ValueError('Calibration split only')
    if len({r['run_id'] for r in records})!=len(records):raise ValueError('Duplicate calibration run')
    values=np.asarray([r['score'] for r in records],dtype=float)
    if not np.all(np.isfinite(values)) or np.any(values<0):raise ValueError('Nonfinite calibration score')
    rank=math.ceil((len(values)+1)*target)
    if rank>len(values):raise ValueError('Too few runs for requested finite order statistic')
    return dict(padding_units=float(np.sort(values)[rank-1]),target=target,order_statistic=rank,
                calibration_runs=len(values),scales=SCALES,run_ids=[r['run_id'] for r in records],
                scope='Whole-run maxima over available issues only. Diagnostic target; fixed parameter grid does not establish exchangeability or guarantee deployment coverage.')


def expand_packet(packet,padding_units):
    if not math.isfinite(padding_units) or padding_units<0:raise ValueError('Invalid padding')
    out=deepcopy(packet)
    for m in out['models']:
        e=m.get('sample_envelope')
        if e is None:continue
        for stem,scale in (('position',.1),('velocity',.2)):
            e[stem+'_min']=(np.asarray(e[stem+'_min'])-padding_units*scale).tolist()
            e[stem+'_max']=(np.asarray(e[stem+'_max'])+padding_units*scale).tolist()
        e['yaw_radius']=np.minimum(np.pi,np.asarray(e['yaw_radius'])+padding_units*.1).tolist()
    out['box_calibration']=dict(padding_units=padding_units,scales=SCALES,
        scope='Expanded diagnostic boxes; trajectories unchanged; box interiors not guaranteed physically feasible.')
    return out

"""Durable start/end events plus a human-readable simulation time index."""
from contextlib import contextmanager
from datetime import datetime
from zoneinfo import ZoneInfo
from time import monotonic
from uuid import uuid4
from pathlib import Path
import csv,hashlib,json,os


class RunJournal:
    def __init__(self,folder):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
        path=self.folder/'events.jsonl'
        if path.exists():
            raw=path.read_bytes()
            if raw and not raw.endswith(b'\n'):
                split=raw.rfind(b'\n')+1;tail=raw[split:]
                try:json.loads(tail)
                except (ValueError,UnicodeError):
                    (self.folder/('recovered-fragment-'+str(uuid4())+'.txt')).write_bytes(tail)
                    with path.open('r+b') as f:f.truncate(split);f.flush();os.fsync(f.fileno())
                else:
                    with path.open('ab') as f:f.write(b'\n');f.flush();os.fsync(f.fileno())

    def _event(self,event):
        with (self.folder/'events.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(event,ensure_ascii=False,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
        self._render()

    def _render(self):
        rows={}
        for line in (self.folder/'events.jsonl').read_text().splitlines():
            e=json.loads(line);key=e['execution_id']
            if e['event']=='started':
                rows[key]={k:e[k] for k in ('execution_id','run_id','started_at','simulated_duration_s','protocol_sha256','artifacts','metadata')}
                rows[key].update(ended_at='',wall_elapsed_s='',status='running_or_interrupted',error='')
            else:
                rows[key].update({k:e[k] for k in ('ended_at','wall_elapsed_s','status','error')})
        for r in rows.values():r['operation']=r['metadata'].get('operation','simulation')
        keys=['execution_id','run_id','operation','started_at','ended_at','wall_elapsed_s','simulated_duration_s','status','protocol_sha256','artifacts','metadata','error']
        target=self.folder/'仿真时间记录.csv';temp=target.with_suffix('.tmp')
        with temp.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
            for row in rows.values():w.writerow(dict(row,metadata=json.dumps(row['metadata'],ensure_ascii=False)))
        os.replace(temp,target)
        lines=['# 仿真时间记录','',
               '全部时间为北京时间（UTC+08:00）。实际耗时是本机单调时钟测量；仿真时长是场景内时间，两者不同。',
               'running_or_interrupted 表示已记录开始，尚无结束事件，可能仍在执行或意外中断。',
               '前一轮 26 个批次未逐次记录实际起止时间，本表不补造；从本轮开始逐次记录。','',
               'operation 为 simulation 表示新仿真，offline_evaluation 表示对已保存数据的离线评分。','',
               '| 批次 | 操作 | 开始时间 | 结束时间 | 实际耗时/秒 | 场景时长/秒 | 状态 | 结果 |',
               '|---|---|---|---|---:|---:|---|---|']
        for r in rows.values():
            artifact=str(r['artifacts']).replace('|','%7C')
            lines.append(f"| {r['run_id']} | {r['operation']} | {r['started_at']} | {r['ended_at']} | {r['wall_elapsed_s']} | {r['simulated_duration_s']} | {r['status']} | [查看]({artifact}) |")
        temp=self.folder/'仿真时间记录.tmp';temp.write_text('\n'.join(lines)+'\n',encoding='utf-8')
        os.replace(temp,self.folder/'仿真时间记录.md')

    @contextmanager
    def run(self,run_id,metadata,simulated_duration_s,artifacts):
        encoded=json.dumps(metadata,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()
        start=dict(event='started',execution_id=str(uuid4()),run_id=run_id,
                   started_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='milliseconds'),
                   simulated_duration_s=float(simulated_duration_s),protocol_sha256=hashlib.sha256(encoded).hexdigest(),
                   artifacts=str(artifacts),metadata=metadata)
        began=monotonic();self._event(start);status='completed';error=''
        try:yield start['execution_id']
        except BaseException as exc:
            status='failed';error=f'{type(exc).__name__}: {exc}';raise
        finally:
            self._event(dict(event='finished',execution_id=start['execution_id'],ended_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='milliseconds'),
                             wall_elapsed_s=round(monotonic()-began,6),status=status,error=error))

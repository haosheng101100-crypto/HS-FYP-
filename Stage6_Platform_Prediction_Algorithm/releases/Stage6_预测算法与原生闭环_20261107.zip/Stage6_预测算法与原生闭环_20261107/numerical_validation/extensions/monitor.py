"""Initial diagnostic monitor. Thresholds are fixed test settings, not certification."""
import math


class TrustMonitor:
    def __init__(self,nis_threshold=16.27,error_threshold_m=.5,trigger_count=3,recover_count=5):
        self.nis_threshold=nis_threshold;self.error_threshold=error_threshold_m
        self.trigger=trigger_count;self.recover=recover_count
        self.high={'innovation':0,'error':0};self.low={'innovation':0,'error':0}
        self.latched={'innovation':False,'error':False}

    def _observe(self,kind,bad):
        self.high[kind]=self.high[kind]+1 if bad else 0
        self.low[kind]=0 if bad else self.low[kind]+1
        if self.high[kind]>=self.trigger:self.latched[kind]=True
        if self.low[kind]>=self.recover:self.latched[kind]=False

    def observe_innovation(self,values):
        finite=[float(v) for v in values if v is not None and math.isfinite(v)]
        if finite:self._observe('innovation',min(finite)>self.nis_threshold)

    def observe_error(self,completed,now):
        if completed['completed_at']>now+1e-9:raise ValueError('Future error supplied')
        if completed.get('metrics') is not None:
            value=completed['metrics']['fde_m']
            if not math.isfinite(value):raise ValueError('Invalid matured error')
            self._observe('error',value>self.error_threshold)

    def inspect(self,packet):
        if packet['status']!='ready':state=packet['status']
        elif self.latched['innovation']:state='unreliable_innovation'
        elif self.latched['error']:state='unreliable_error'
        elif any(self.high.values()):state='warning'
        else:state='ready_uncalibrated'
        return dict(state=state,latched=dict(self.latched),consecutive_high=dict(self.high),
                    scope='Diagnostic only. No landing authorization; thresholds not validated on hardware.')

"""Predeclared mechanism-based boundary tests. Generic bounds, not hardware."""
import numpy as np
from simulation.world import World


class BoundaryWorld(World):
    def __init__(self,v=1.,k=0.,v_amp=0.,v_freq=0.,k_amp=0.,k_freq=0.):
        super().__init__(v,float(np.arctan(.65*k)),'constant')
        self_parameters=(v_amp,v_freq,k_amp,k_freq)
        if not np.all(np.isfinite(self_parameters)):raise ValueError('Invalid boundary controls')
        object.__setattr__(self,'parameters',self_parameters)

    def controls(self,t):
        t=np.asarray(t);va,vf,ka,kf=self.parameters
        v=self.speed+va*np.sin(vf*t);a=va*vf*np.cos(vf*t);j=-va*vf**2*np.sin(vf*t)
        k=np.tan(self.steer)/self.wheelbase+ka*np.sin(kf*t);rate=ka*kf*np.cos(kf*t)
        delta=np.arctan(self.wheelbase*k);delta_rate=self.wheelbase*rate/(1+(self.wheelbase*k)**2)
        return v,a,j,delta,delta_rate


CASES=[
    dict(id='stopped',world=dict(v=0.,k=.5)),
    dict(id='crawl',world=dict(v=.05,k=.5)),
    dict(id='reverse',world=dict(v=-1.,k=.5)),
    dict(id='speed_limit',world=dict(v=2.97)),
    dict(id='curvature_limit',world=dict(v=1.,k=.99)),
    dict(id='lateral_limit',world=dict(v=2.,k=.61875)),
    dict(id='acceleration_jerk_limits',world=dict(v=1.5,v_amp=.495,v_freq=2.)),
    dict(id='curvature_rate_limit',world=dict(v=.8,k_amp=.99,k_freq=1.)),
]

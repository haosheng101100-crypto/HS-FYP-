"""Recheck saved scores, sample constraints, causality and one full replay."""
import argparse,csv,gzip,hashlib,json
from datetime import datetime
from pathlib import Path
import numpy as np
from stage6.observation import Observation
from stage6.model import MODES,Limits
from stage6.forecast import admissible_batch
from simulation.results import lookup
from simulation.benchmark import HORIZONS,point_errors,score_packet
from extensions.calibration import fit_run_scores
from extensions.pipeline import paired_online
from extensions.journal import RunJournal


def main(root):
    journal=RunJournal(root/'时间记录');count=paths=missing=0
    with journal.run('verification_saved_evidence',dict(operation='offline_evaluation',purpose='Recompute all main-run metrics and audit every saved sample output grid'),0.,root/'verification/evidence-check.txt'):
        with (root/'时间记录/仿真时间记录.csv').open(encoding='utf-8-sig') as f:timings=list(csv.DictReader(f))
        for row in timings:
            if row['run_id']=='verification_saved_evidence':continue
            assert row['status']=='completed',row['run_id']
            assert datetime.fromisoformat(row['ended_at'])>=datetime.fromisoformat(row['started_at'])
            assert float(row['wall_elapsed_s'])>=0 and row['started_at'].endswith('+08:00')
            assert Path(row['artifacts']).exists(),row['artifacts']
        scores=json.loads((root/'calibration_run_scores.json').read_text())
        assert fit_run_scores(scores,.9)==json.loads((root/'calibration_model.json').read_text())
        assert len(scores)==12 and all(r['split']=='calibration' for r in scores)
        for folder in [*sorted((root/'results').iterdir()),*sorted((root/'calibration_runs').iterdir()),*sorted((root/'monitor_stress').iterdir())]:
            truth=dict(np.load(folder/'truth.npz'));main_rows={r['now']:r for r in json.loads((folder/'scores.json').read_text())} if (folder/'scores.json').exists() else {}
            with gzip.open(folder/'forecasts.jsonl.gz','rt') as f:
                for line in f:
                    r=json.loads(line)
                    for e in r['matured']:
                        assert e['completed_at']<=r['now']+1e-9
                        if e['status']=='complete':assert e['issued_at']+2.<=e['completed_at']+1e-9
                        else:missing+=1
                    if r['packet'] is None:continue
                    count+=1
                    for name,key in (('IMM','packet'),('CT','CT_packet')):
                        packet=r[key]
                        assert packet['issued_at']==r['now'] and packet['trust']=='uncalibrated'
                        if 'latest_observation_stamp' in packet:assert packet['latest_observation_stamp']<=r['now']+1e-9
                        assert sum(m['requested'] for m in packet['models']) in (0,48)
                        for m in packet['models']:
                            mode=next(x for x in MODES if x.name==m['name'])
                            for tr in m['trajectories']:
                                assert np.all(admissible_batch(np.vstack([tr['initial_state'],tr['states']]),mode,Limits()))
                                paths+=1
                    if r['now'] in main_rows:
                        row=main_rows[r['now']];xy,v,yaw=lookup(truth,r['now']+HORIZONS)
                        for name,p in dict(IMM=r['point'],CT=r['CT_point'],**r['baselines']).items():
                            assert (None if p['xy'] is None else point_errors(p['xy'],xy))==row['metrics'][name]
                        for name,key in (('IMM','packet'),('CT','CT_packet')):assert score_packet(r[key],xy,v,yaw)==row['coverage'][name]
        assert count==42*21
    with journal.run('verification_replay_ablation_test_00',dict(operation='offline_evaluation',purpose='Recompute all forecast values from stored observations'),12.,root/'results/ablation_test_00'):
        folder=root/'results/ablation_test_00';obs=[]
        for line in (folder/'observations.jsonl').read_text().splitlines():
            o=json.loads(line);o['covariance']=np.array(o['covariance']);obs.append(Observation(**o))
        with gzip.open(folder/'forecasts.jsonl.gz','rt') as f:expected=[json.loads(line) for line in f][:21]
        for r,e in zip(paired_online(obs,np.arange(21)*.5),expected,strict=True):
            for key in ('packet','CT_packet','point','CT_point','baselines'):assert r[key]==e[key]
    print(f'PASS: 42 simulation runs; {count} IMM+CT forecast pairs; {paths} sampled paths satisfy output-grid bounds.')
    print(f'PASS: main metrics/coverage recomputed; delayed maturity causal; {missing} missing-label completions retained.')
    print('PASS: calibration split/fit verified; saved times and artifact paths verified.')
    print('PASS: complete ablation_test_00 forecast values exactly reproduced; diagnostic logging/runtime excluded.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);main(p.parse_args().output)

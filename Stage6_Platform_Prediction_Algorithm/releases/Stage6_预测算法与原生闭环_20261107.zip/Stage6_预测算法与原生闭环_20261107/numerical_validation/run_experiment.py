"""Run the predeclared manifest; refuse to overwrite experiment evidence."""
import argparse
import gzip
import json
from collections import Counter
from pathlib import Path
from dataclasses import asdict
import numpy as np
from simulation.world import World,generate,OFFSET
from simulation.benchmark import online_forecasts,HORIZONS,score_packet,point_errors
from simulation.results import lookup,aggregate
from stage6.model import MODES,Limits
from stage6.forecast import admissible_batch


def write_json(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def validate_manifest(manifest):
    # This v1 harness supports this fixed protocol only. Reject edits that would
    # falsely claim different parameters while running hardcoded defaults.
    expected=dict(version=1,core='v0.1 frozen',offset_xy=list(OFFSET),duration_s=12.,
                  measurement_interval_s=.1,noise_std=[.02,.02,.01],drop_probability=.05,
                  delay_range_s=[.04,.07],issue_interval_s=.5,scored_issue_range_s=[1.,10.],
                  horizon_s=2.,step_s=.1,particles_per_mode=12,window_s=.65)
    for key,value in expected.items():
        if manifest.get(key)!=value:raise ValueError('Unsupported manifest setting: '+key)
    ids=[r['id'] for r in manifest['runs']]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate run IDs')
    for r in manifest['runs']:
        if r['split'] not in ('development','test','stress','calibration_reserved'):
            raise ValueError('Unknown run split')
        if Path(r['id']).name!=r['id'] or r['id'] in ('','.','..'):
            raise ValueError('Unsafe run ID')


def run(output):
    manifest_path=Path(__file__).parent/'simulation/manifest.json'
    manifest=json.loads(manifest_path.read_text())
    validate_manifest(manifest)
    output.mkdir(parents=True,exist_ok=False)
    (output/'manifest.json').write_bytes(manifest_path.read_bytes())
    all_rows=[];run_summaries=[]
    for spec in manifest['runs']:
        if spec['split']=='calibration_reserved':continue
        name=spec['id'];folder=output/name;folder.mkdir()
        world=World(**spec['world']);data=generate(world,spec['seed'],outage=spec.get('outage'))
        write_json(folder/'truth_audit.json',data['audit'])
        if data['audit']['violations']:raise RuntimeError('Truth outside bounds: '+name)
        np.savez_compressed(folder/'truth.npz',**data['truth'])
        with (folder/'observations.jsonl').open('w') as f:
            for o in data['observations']:
                d=asdict(o);d['covariance']=o.covariance.tolist();f.write(json.dumps(d,allow_nan=False)+'\n')
        rows=[];status=Counter();times=[];update_times=[];accepted=requested=sample_bad=mean_bad=0
        # Only this generator receives observations. Labels are looked up BELOW
        # after the immutable online forecast has been emitted.
        with gzip.open(folder/'forecasts.jsonl.gz','wt',encoding='utf-8') as f:
            for forecast in online_forecasts(data['observations'],np.arange(21)*.5):
                f.write(json.dumps(forecast,allow_nan=False,separators=(',',':'))+'\n')
                now=forecast['now'];p=forecast['packet'];status[p['status']]+=1
                update_times.extend(forecast['runtime']['update_ms'])
                if now<1.:continue  # Fixed scored window 1..10 s inclusive.
                xy,vel,yaw=lookup(data['truth'],now+HORIZONS)
                candidates=dict(IMM=forecast['point'],**forecast['baselines'])
                metrics={k:None if v['xy'] is None else point_errors(v['xy'],xy) for k,v in candidates.items()}
                row=dict(run_id=name,split=spec['split'],now=now,status=p['status'],metrics=metrics,
                         coverage=score_packet(p,xy,vel,yaw),runtime=forecast['runtime'])
                rows.append(row);all_rows.append(row);times.append(forecast['runtime'])
                mean_bad+=int(forecast['point'].get('mean_path_constraint_violation',False))
                for m in p['models']:
                    requested+=m['requested'];accepted+=len(m['trajectories'])
                    mode=next(x for x in MODES if x.name==m['name'])
                    for tr in m['trajectories']:
                        states=np.vstack([tr['initial_state'],tr['states']])
                        sample_bad+=int(not np.all(admissible_batch(states,mode,Limits())))
        write_json(folder/'scores.json',rows)
        summary=dict(run_id=name,split=spec['split'],world=spec['world'],**aggregate(rows),
                     statuses_all_21_issues=dict(status),accepted_sample_paths=accepted,requested_sample_paths=requested,
                     sampled_paths_with_output_grid_violation=sample_bad,mean_paths_with_output_grid_violation=mean_bad,
                     runtime_ms={k:dict(median=float(np.median([r[k] for r in times])),p95=float(np.percentile([r[k] for r in times],95)))
                                 for k in ('IMM_forecast_ms','CV_forecast_ms','CA_forecast_ms')},
                     update_runtime_ms=dict(median=float(np.median(update_times)),p95=float(np.percentile(update_times,95))))
        write_json(folder/'summary.json',summary);run_summaries.append(summary)
        print(name,summary['methods']['IMM']['common_ade_m'],dict(status),flush=True)
    write_json(output/'all_scores.json',all_rows)
    write_json(output/'summary.json',dict(by_split={s:aggregate([r for r in all_rows if r['split']==s])
                                                   for s in ('development','test','stress')},runs=run_summaries))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    run(parser.parse_args().output)

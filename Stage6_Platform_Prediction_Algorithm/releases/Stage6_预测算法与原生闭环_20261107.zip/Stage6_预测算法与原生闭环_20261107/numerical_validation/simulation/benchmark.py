"""Causal online runner. Truth is deliberately absent from this module's replay."""
from time import perf_counter
import numpy as np
from stage6.predictor import VehiclePredictor
from stage6.model import MODES, Limits, step, violations
from .world import OFFSET

HORIZONS=np.arange(1,21)*.1


def polynomial_forecast(observations,now,times,degree,offset):
    if any(o.received_at>now+1e-9 for o in observations):raise ValueError('Future receipt supplied')
    result=dict(status='warming_up',xy=None)
    if not observations:return result
    latest=observations[-1]
    if now-latest.stamp>.2+1e-9:return dict(status='stale',xy=None)
    h=[o for o in observations if o.stamp>=latest.stamp-.65-1e-9]
    if len(h)<5 or h[-1].stamp-h[0].stamp<.4-1e-9:return result
    t=np.array([o.stamp-latest.stamp for o in h])
    yaw=np.array([o.yaw for o in h]);dx,dy=offset
    xy=np.array([o.position_xy for o in h])-np.column_stack([dx*np.cos(yaw)-dy*np.sin(yaw),dx*np.sin(yaw)+dy*np.cos(yaw)])
    coefficients=np.linalg.lstsq(np.vander(t,degree+1,increasing=True),xy,rcond=None)[0]
    future=now-latest.stamp+np.asarray(times)
    return dict(status='ready',xy=(np.vander(future,degree+1,increasing=True)@coefficients).tolist())


def mean_forecast(packet):
    """MAP filtering mode, chosen without truth, propagated without driver noise.

    Point comparator only. It can violate bounds; sampled trajectories are the
    constrained branch product. Never average means of incompatible branches.
    """
    modes=[m for m in packet['models'] if m['state'] is not None]
    if not modes:return dict(status=packet['status'],xy=None)
    best=max(modes,key=lambda m:m['posterior_weight'])
    mode=next(m for m in MODES if m.name==best['name'])
    state=np.array(best['state']);states=[];previous=0.;bad=bool(violations(state,mode,Limits()))
    for target in packet['horizons_s']:
        state=step(state,target-previous,mode);states.append(state.copy());previous=target
        bad |= bool(violations(state,mode,Limits()))
    return dict(status=packet['status'],mode=mode.name,xy=np.array(states)[:,:2].tolist(),
                mean_path_constraint_violation=bool(bad))


def online_forecasts(observations,issue_times,particles=12):
    predictor=VehiclePredictor(OFFSET);history=[];index=0
    obs=list(observations);clock=np.asarray(issue_times,dtype=float)
    if clock.ndim!=1 or not np.all(np.isfinite(clock)) or np.any(np.diff(clock)<=0):raise ValueError('Invalid issue clock')
    for emission,now in enumerate(clock):
        update_ms=[]
        while index<len(obs) and obs[index].received_at<=now+1e-9:
            start=perf_counter();predictor.update(obs[index]);update_ms.append((perf_counter()-start)*1000)
            history.append(obs[index]);index+=1
        start=perf_counter();packet=predictor.forecast(float(now),particles_per_mode=particles,seed=1000+emission)
        point=mean_forecast(packet);imm_ms=(perf_counter()-start)*1000
        baselines={};baseline_ms={}
        for degree,name in ((1,'CV'),(2,'CA')):
            start=perf_counter();baselines[name]=polynomial_forecast(history,now,HORIZONS,degree,OFFSET)
            baseline_ms[name]=(perf_counter()-start)*1000
        yield dict(now=float(now),packet=packet,point=point,baselines=baselines,
                   runtime=dict(update_ms=update_ms,IMM_forecast_ms=imm_ms,**{k+'_forecast_ms':v for k,v in baseline_ms.items()}))


def point_errors(predicted,truth):
    error=np.linalg.norm(np.asarray(predicted)-np.asarray(truth),axis=1)
    return dict(ade_m=float(error.mean()),fde_m=float(error[-1]),errors_m=error.tolist())


def score_packet(packet,truth_xy,truth_velocity,truth_yaw):
    """Uncalibrated union-of-mode sample-box diagnostics, inclusive boundaries.

    Trajectory coverage requires ONE mode's envelope over the full horizon.
    Empty/failed modes do not disappear from the denominator of issue records.
    Box interiors need not be physically reachable or coherent sampled paths.
    """
    n=len(truth_xy);xy_masks=[];joint_masks=[];area=np.zeros(n)
    for model in packet['models']:
        e=model.get('sample_envelope')
        if e is None:continue
        lo=np.asarray(e['position_min']);hi=np.asarray(e['position_max'])
        xy=np.all((truth_xy>=lo)&(truth_xy<=hi),axis=1)
        vel=np.all((truth_velocity>=e['velocity_min'])&(truth_velocity<=e['velocity_max']),axis=1)
        angle=(np.asarray(truth_yaw)-e['yaw_center']+np.pi)%(2*np.pi)-np.pi
        yaw=np.abs(angle)<=np.asarray(e['yaw_radius'])
        xy_masks.append(xy);joint_masks.append(xy&vel&yaw)
        area+=np.prod(hi-lo,axis=1)
    xm=np.array(xy_masks,dtype=bool).reshape(-1,n);jm=np.array(joint_masks,dtype=bool).reshape(-1,n)
    return dict(point_xy_coverage=float(np.any(xm,axis=0).mean()),
                trajectory_xy_coverage=bool(np.any(np.all(xm,axis=1))),
                point_joint_coverage=float(np.any(jm,axis=0).mean()),
                trajectory_joint_coverage=bool(np.any(np.all(jm,axis=1))),
                mean_sum_box_area_m2=float(area.mean()))

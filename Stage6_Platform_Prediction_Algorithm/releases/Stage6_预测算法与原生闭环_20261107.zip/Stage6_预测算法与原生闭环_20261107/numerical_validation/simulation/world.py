"""Private truth generator: commanded bicycle, independent DOP853 integration.

No predictor dynamics or future forecasts are used to construct truth.
Wheelbase and commands belong to the simulator and are never observations.
"""
from dataclasses import dataclass
import numpy as np
from scipy.integrate import solve_ivp
from stage6.observation import Observation

OFFSET=(.18,-.07)
BOUNDS=dict(speed=3.,acceleration=1.,curvature=1.,jerk=2.,curvature_rate=1.,lateral_acceleration=2.5)


@dataclass(frozen=True)
class World:
    speed: float
    steer: float
    profile: str
    wheelbase: float=.65

    def __post_init__(self):
        if self.profile not in ('constant','varying','reverse'):
            raise ValueError('Unknown command profile')
        if not np.all(np.isfinite([self.speed,self.steer,self.wheelbase])) or self.wheelbase<=0 or abs(self.steer)>=np.pi/2:
            raise ValueError('Invalid bicycle parameters')

    def controls(self,t):
        t=np.asarray(t)
        if self.profile=='constant':
            v=np.full_like(t,self.speed,dtype=float);a=np.zeros_like(t);j=np.zeros_like(t)
            delta=np.full_like(t,self.steer,dtype=float);rate=np.zeros_like(t)
        else:
            if self.profile=='varying':
                v=self.speed+.2*np.sin(.7*t);a=.14*np.cos(.7*t);j=-.098*np.sin(.7*t)
            else:
                v=self.speed*np.cos(.45*t);a=-.45*self.speed*np.sin(.45*t);j=-.45**2*self.speed*np.cos(.45*t)
            delta=self.steer*np.sin(.6*t);rate=.6*self.steer*np.cos(.6*t)
        return v,a,j,delta,rate

    def truth(self,times):
        t=np.asarray(times,dtype=float)
        if t.ndim!=1 or len(t)==0 or not np.all(np.isfinite(t)) or t[0]<0 or np.any(np.diff(t)<=0):
            raise ValueError('Truth times must be finite nonnegative and increasing')
        def rhs(time,pose):
            v,_,_,delta,_=self.controls(time)
            return [v*np.cos(pose[2]),v*np.sin(pose[2]),v*np.tan(delta)/self.wheelbase]
        if t[-1]==0:pose=np.zeros((1,3))
        else:
            sol=solve_ivp(rhs,(0.,float(t[-1])),[0.,0.,0.],method='DOP853',t_eval=t,
                          rtol=1e-10,atol=1e-12,max_step=.05)
            if not sol.success:raise RuntimeError(sol.message)
            pose=sol.y.T
        v,a,j,d,rate=self.controls(t);k=np.tan(d)/self.wheelbase
        return dict(t=t,xy=pose[:,:2],yaw=pose[:,2],speed=v,acceleration=a,jerk=j,curvature=k,
                    curvature_rate=rate/(self.wheelbase*np.cos(d)**2),lateral_acceleration=v**2*np.abs(k),
                    velocity=v[:,None]*np.column_stack([np.cos(pose[:,2]),np.sin(pose[:,2])]))


def audit(truth):
    maxima={k:float(np.max(np.abs(truth[k]))) for k in BOUNDS}
    return dict(maxima=maxima,bounds=BOUNDS,violations=[k for k in BOUNDS if maxima[k]>BOUNDS[k]+1e-9],
                scope='Dense 0.02 s samples, not a continuous-time certificate or hardware identification.')


def generate(world,seed,duration=12.,offset=OFFSET,outage=None):
    if not np.isfinite(duration) or duration<=0:raise ValueError('Invalid duration')
    dense=world.truth(np.linspace(0,duration,round(duration/.02)+1))
    t=np.arange(int(np.floor(duration/.1))+1)*.1
    truth=world.truth(t)
    noise_rng,drop_rng,delay_rng=[np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(3)]
    noise=noise_rng.normal(size=(len(t),3))*[.02,.02,.01]
    keep=drop_rng.random(len(t))>=.05
    delay=.04+.03*delay_rng.random(len(t))
    if outage is not None:keep &= ~((t>=outage[0])&(t<=outage[1]))
    yaw=truth['yaw'];dx,dy=offset
    measured=truth['xy']+np.column_stack([dx*np.cos(yaw)-dy*np.sin(yaw),dx*np.sin(yaw)+dy*np.cos(yaw)])
    measured+=noise[:,:2]
    covariance=np.diag([.02**2,.02**2,.01**2])
    observations=[Observation(float(t[i]),float(t[i]+delay[i]),tuple(measured[i]),float(yaw[i]+noise[i,2]),covariance)
                  for i in np.flatnonzero(keep)]
    return dict(truth=dense,observations=observations,audit=audit(dense))

"""Offline scoring only; never feeds labels to the online runner."""
import numpy as np


def lookup(truth,times):
    ts=np.asarray(times)
    if ts.min()<truth['t'][0]-1e-9 or ts.max()>truth['t'][-1]+1e-9:
        raise ValueError('Labels are not available for entire requested horizon')
    def interp(a):
        return np.column_stack([np.interp(ts,truth['t'],a[:,i]) for i in range(a.shape[1])])
    return interp(truth['xy']),interp(truth['velocity']),np.interp(ts,truth['t'],truth['yaw'])


def aggregate(rows):
    common=[r for r in rows if all(r['metrics'][k] is not None for k in ('IMM','CV','CA'))]
    def avg(items,key):return float(np.mean([x[key] for x in items])) if items else None
    methods={}
    for k in ('IMM','CV','CA'):
        available=[r['metrics'][k] for r in rows if r['metrics'][k] is not None]
        c=[r['metrics'][k] for r in common]
        methods[k]=dict(available_issues=len(available),available_ade_m=avg(available,'ade_m'),
                        available_fde_m=avg(available,'fde_m'),common_ade_m=avg(c,'ade_m'),common_fde_m=avg(c,'fde_m'))
    coverage={k:avg([r['coverage'] for r in rows],k) for k in
              ('point_xy_coverage','trajectory_xy_coverage','point_joint_coverage','trajectory_joint_coverage','mean_sum_box_area_m2')}
    return dict(scheduled_issues=len(rows),common_issues=len(common),methods=methods,sample_box_diagnostics=coverage)

"""Independent experiments for frozen stage-6 predictor."""

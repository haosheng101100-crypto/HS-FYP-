import unittest
import numpy as np
from extensions import delayed,monitor,calibration


def packet():
    return dict(status='ready',horizons_s=[.1,.2],models=[])


def label(t,arrival=None):
    return dict(stamp=t,received_at=t if arrival is None else arrival,position_xy=[t,0.],velocity_xy=[1.,0.],yaw=0.)


class DelayedTests(unittest.TestCase):
    def test_waits_for_actual_label_receipt(self):
        q=delayed.DelayedQueue(grace_s=.3)
        p=packet();q.issue('a',0.,p,[[.1,0.],[.2,0.]])
        p['horizons_s'][0]=99. # Submitted forecast must be a frozen copy.
        self.assertEqual(q.advance(.1,[label(.1)]),[])
        with self.assertRaises(ValueError):q.advance(.2,[label(.2,.25)])
        self.assertEqual(q.advance(.2),[])
        r=q.advance(.25,[label(.2,.25)])
        self.assertEqual(len(r),1);self.assertEqual(r[0]['completed_at'],.25)
        self.assertEqual(r[0]['metrics']['fde_m'],0.)
        self.assertEqual(q.advance(.3),[])

    def test_missing_label_is_not_interpolated_or_silently_dropped(self):
        q=delayed.DelayedQueue(grace_s=.3);q.issue('a',0.,packet(),None)
        self.assertEqual(q.advance(.49,[label(.1)]),[])
        r=q.advance(.5)
        self.assertEqual(r[0]['status'],'missing_labels')
        self.assertEqual(r[0]['missing_targets'],[.2])
        self.assertIsNone(r[0]['metrics'])

    def test_late_label_cannot_repair_expired_deadline(self):
        q=delayed.DelayedQueue(grace_s=.3);q.issue('a',0.,packet(),[[0,0]]*2)
        r=q.advance(.6,[label(.1),label(.2,.6)])
        self.assertEqual(r[0]['status'],'missing_labels')
        with self.assertRaises(ValueError):q.advance(.4)

    def test_forecast_must_be_issued_at_current_clock(self):
        q=delayed.DelayedQueue();q.advance(1.)
        with self.assertRaises(ValueError):q.issue('past',.5,packet(),None)
        with self.assertRaises(ValueError):q.issue('future',2.,packet(),None)


class MonitorTests(unittest.TestCase):
    def test_latch_and_recovery_require_actual_observations(self):
        m=monitor.TrustMonitor()
        for _ in range(3):m.observe_innovation([20.,25.])
        self.assertEqual(m.inspect(packet())['state'],'unreliable_innovation')
        for _ in range(10):m.inspect(packet())
        self.assertEqual(m.inspect(packet())['state'],'unreliable_innovation')
        for _ in range(5):m.observe_innovation([1.,2.])
        self.assertEqual(m.inspect(packet())['state'],'ready_uncalibrated')

    def test_future_errors_cannot_be_accepted(self):
        m=monitor.TrustMonitor()
        with self.assertRaises(ValueError):m.observe_error(dict(completed_at=2.,metrics=dict(fde_m=1.)),now=1.)
        for i in range(3):m.observe_error(dict(completed_at=i,metrics=dict(fde_m=1.)),now=float(i))
        self.assertEqual(m.inspect(packet())['state'],'unreliable_error')
        self.assertEqual(m.inspect(dict(status='stale'))['state'],'stale')


class CalibrationTests(unittest.TestCase):
    def test_run_quantile_small_sample_and_no_test_split(self):
        c=calibration.fit_run_scores([dict(run_id=str(i),split='calibration',score=float(i)) for i in range(12)],.9)
        self.assertEqual(c['padding_units'],11.)
        self.assertEqual(c['order_statistic'],12)
        with self.assertRaises(ValueError):calibration.fit_run_scores([dict(run_id='test',split='test',score=1.)],.9)
        with self.assertRaises(ValueError):calibration.fit_run_scores([dict(run_id=str(i),split='calibration',score=1.) for i in range(12)],.95)

    def test_branch_score_cannot_switch_models_across_time(self):
        def model(lo):
            return dict(sample_envelope=dict(position_min=lo,position_max=(np.array(lo)+2.).tolist(),velocity_min=[[-1,-1]]*2,velocity_max=[[1,1]]*2,yaw_center=[0,0],yaw_radius=[1,1]))
        p=dict(models=[model([[-1,-1],[4,4]]),model([[4,4],[-1,-1]])])
        s=calibration.trajectory_score(p,np.zeros((2,2)),np.zeros((2,2)),np.zeros(2))
        self.assertEqual(s,40.) # 4 m outside / fixed 0.1 m scale.
        expanded=calibration.expand_packet(p,40.)
        self.assertEqual(expanded['models'][0]['sample_envelope']['position_min'][1],[0.,0.])
        self.assertEqual(p['models'][0]['sample_envelope']['position_min'][1],[4,4])

    def test_empty_prediction_has_no_finite_calibration_score(self):
        self.assertIsNone(calibration.trajectory_score(dict(models=[]),np.zeros((2,2)),np.zeros((2,2)),np.zeros(2)))


if __name__=='__main__':unittest.main()

import unittest
import numpy as np
from simulation import world


class WorldTests(unittest.TestCase):
    # Catches wrong bicycle yaw rate, integration or reference origin.
    def test_analytic_circle(self):
        w=world.World(speed=1.,steer=np.arctan(.65*.5),profile='constant')
        s=w.truth(np.array([0.,1.,2.]))
        np.testing.assert_allclose(s['xy'][-1],[2*np.sin(1),2*(1-np.cos(1))],atol=1e-8)
        self.assertAlmostEqual(s['yaw'][-1],1.,places=8)
        np.testing.assert_allclose(s['velocity'][-1],[np.cos(1),np.sin(1)],atol=1e-8)

    def test_straight_reverse_has_signed_velocity(self):
        w=world.World(1.,0.,'reverse')
        s=w.truth(np.array([0.,4.,8.]))
        self.assertLess(s['speed'][-1],0.)
        self.assertAlmostEqual(s['xy'][-1,0],np.sin(3.6)/.45,places=7)
        self.assertAlmostEqual(s['xy'][-1,1],0.,places=9)

    def test_observations_reproducible_and_no_truth_fields(self):
        a=world.generate(world.World(1.,.1,'varying'),12)
        b=world.generate(world.World(1.,.1,'varying'),12)
        self.assertEqual([o.position_xy for o in a['observations']],[o.position_xy for o in b['observations']])
        self.assertTrue(all(o.stamp<=o.received_at for o in a['observations']))
        self.assertTrue(all(x.received_at<y.received_at for x,y in zip(a['observations'],a['observations'][1:])))
        self.assertEqual(set(vars(a['observations'][0])),{'stamp','received_at','position_xy','yaw','covariance'})
        self.assertGreater(np.linalg.norm(np.array(a['observations'][0].position_xy)-[.18,-.07]),1e-6)

    def test_generated_grid_within_declared_bounds(self):
        for v in (.5,1.5):
            for d in (0.,.18,.35):
                for p in ('constant','varying'):
                    self.assertEqual(world.audit(world.World(v,d,p).truth(np.linspace(0,12,601)))['violations'],[])

    def test_outage_removes_measurements(self):
        d=world.generate(world.World(1.,.1,'reverse'),13,outage=(4.,5.5))
        self.assertFalse(any(4.<=o.stamp<=5.5 for o in d['observations']))

    def test_invalid_time_and_profile_rejected(self):
        with self.assertRaises(ValueError):world.World(1.,0.,'typo')
        with self.assertRaises(ValueError):world.World(1.,0.,'constant').truth(np.array([1.,0.]))


if __name__=='__main__':unittest.main()

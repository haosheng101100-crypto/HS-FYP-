import tempfile
import unittest
import json,csv
from pathlib import Path
import numpy as np
from extensions import journal,single_model,boundary
from stage6.observation import Observation


class JournalTests(unittest.TestCase):
    def test_success_and_failure_both_persist(self):
        with tempfile.TemporaryDirectory() as folder:
            j=journal.RunJournal(Path(folder))
            with j.run('ok',dict(seed=17),12.,'results/ok'):pass
            with self.assertRaises(RuntimeError):
                with j.run('failed',dict(seed=18),12.,'results/fail'):raise RuntimeError('numerical failure')
            events=[json.loads(x) for x in (Path(folder)/'events.jsonl').read_text().splitlines()]
            self.assertEqual([x['event'] for x in events],['started','finished','started','finished'])
            with (Path(folder)/'仿真时间记录.csv').open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
            self.assertEqual([r['status'] for r in rows],['completed','failed'])
            self.assertTrue(rows[0]['started_at'].endswith('+08:00'))
            self.assertGreaterEqual(float(rows[0]['wall_elapsed_s']),0.)
            self.assertIn('numerical failure',rows[1]['error'])
            self.assertIn('failed',(Path(folder)/'仿真时间记录.md').read_text())

    def test_existing_events_are_not_overwritten(self):
        with tempfile.TemporaryDirectory() as folder:
            for name in ('first','second'):
                with journal.RunJournal(Path(folder)).run(name,{},1.,name):pass
            self.assertEqual(len((Path(folder)/'events.jsonl').read_text().splitlines()),4)

    def test_partial_last_write_is_preserved_and_recovered(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            with journal.RunJournal(root).run('first',{},1.,'first'):pass
            with (root/'events.jsonl').open('a') as f:f.write('{"event":"sta')
            with journal.RunJournal(root).run('second',{},1.,'second'):pass
            self.assertEqual(len((root/'events.jsonl').read_text().splitlines()),4)
            self.assertEqual(len(list(root.glob('recovered-fragment-*.txt'))),1)


class BoundaryTests(unittest.TestCase):
    def test_six_limits_are_approached_and_not_exceeded(self):
        from simulation.world import audit,BOUNDS
        maxima={k:0. for k in BOUNDS}
        for spec in boundary.CASES:
            truth=boundary.BoundaryWorld(**spec['world']).truth(np.linspace(0,12,601))
            a=audit(truth)
            self.assertEqual(a['violations'],[],spec['id'])
            for k in maxima:maxima[k]=max(maxima[k],a['maxima'][k])
        for k in maxima:self.assertGreaterEqual(maxima[k]/BOUNDS[k],.98,k)


class SingleModeTests(unittest.TestCase):
    def test_single_mode_circle_and_forecast_metadata(self):
        p=single_model.SingleCT((0.,0.))
        for t in np.arange(21)*.1:
            xy=(2*np.sin(.5*t),2*(1-np.cos(.5*t)))
            p.update(Observation(t,t+.04,xy,.5*t,np.diag([.0004,.0004,.0001])))
        r=p.forecast(2.04,particles_per_mode=2)
        self.assertEqual(len(r['models']),1)
        self.assertEqual(r['models'][0]['name'],'CT')
        self.assertEqual(r['models'][0]['posterior_weight'],1.)
        self.assertEqual([m['name'] for m in r['configuration']['modes']],['CT'])
        self.assertAlmostEqual(r['models'][0]['state'][3],1.,delta=.08)
        self.assertAlmostEqual(r['models'][0]['state'][5],.5,delta=.08)
        self.assertEqual(p.forecast(3.)['status'],'stale')


if __name__=='__main__':unittest.main()

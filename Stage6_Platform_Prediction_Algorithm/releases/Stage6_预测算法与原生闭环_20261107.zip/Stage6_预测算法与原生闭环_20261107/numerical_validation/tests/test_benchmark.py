import copy
import unittest
import numpy as np
from stage6.observation import Observation
from simulation import benchmark as b


def obs(t,xy,delay=0.,yaw=0.):
    return Observation(t,t+delay,tuple(xy),yaw,np.diag([.0004,.0004,.0001]))


class BenchmarkTests(unittest.TestCase):
    # Catches time-origin errors and forecasting at stamp rather than now.
    def test_ca_exact_with_delayed_receipt(self):
        history=[obs(t,(t*t,0.),.04) for t in np.arange(8)*.1]
        r=b.polynomial_forecast(history,.8,np.array([.1,1.]),2,(0.,0.))
        self.assertEqual(r['status'],'ready')
        np.testing.assert_allclose(r['xy'],[[.81,0.],[3.24,0.]],atol=1e-12)

    def test_offset_removed_before_cartesian_fit(self):
        h=[obs(t,(.07,t+.18),yaw=np.pi/2) for t in np.arange(8)*.1]
        r=b.polynomial_forecast(h,.7,np.array([1.]),1,(.18,-.07))
        np.testing.assert_allclose(r['xy'],[[0.,1.7]],atol=1e-12)

    def test_future_receipt_rejected_and_stale_not_scored(self):
        h=[obs(t,(t,0.),.04) for t in np.arange(8)*.1]
        with self.assertRaises(ValueError):b.polynomial_forecast(h,.7,np.array([1.]),1,(0,0))
        self.assertEqual(b.polynomial_forecast(h,1.,np.array([1.]),1,(0,0))['status'],'stale')

    def test_hand_derived_errors(self):
        r=b.point_errors(np.array([[3.,4.],[0.,2.]]),np.zeros((2,2)))
        self.assertEqual(r['ade_m'],3.5)
        self.assertEqual(r['fde_m'],2.)

    def test_same_branch_required_for_trajectory_coverage(self):
        # At t1 truth is in branch A, at t2 in B; no full path is covered.
        def model(lo,hi):
            return dict(trajectories=[{}],sample_envelope=dict(position_min=lo,position_max=hi,
                velocity_min=[[-1,-1]]*2,velocity_max=[[1,1]]*2,yaw_center=[0,0],yaw_radius=[1,1]))
        p=dict(models=[model([[-1,-1],[4,4]],[[1,1],[6,6]]),
                       model([[4,4],[-1,-1]],[[6,6],[1,1]])])
        r=b.score_packet(p,np.zeros((2,2)),np.zeros((2,2)),np.zeros(2))
        self.assertEqual(r['point_xy_coverage'],1.)
        self.assertFalse(r['trajectory_xy_coverage'])
        self.assertFalse(r['trajectory_joint_coverage'])

    def test_empty_modes_remain_coverage_failures(self):
        r=b.score_packet(dict(models=[]),np.zeros((2,2)),np.zeros((2,2)),np.zeros(2))
        self.assertEqual(r['point_xy_coverage'],0.)
        self.assertFalse(r['trajectory_joint_coverage'])

    def test_causal_replay_suffix_does_not_change_prefix(self):
        h=[obs(t,(t,0.),.04) for t in np.arange(12)*.1]
        times=[0.,.5,1.]
        a=list(b.online_forecasts(h,times,particles=2))
        changed=h[:7]+[obs(o.stamp,(99.,99.),.04) for o in h[7:]]
        c=list(b.online_forecasts(changed,times[:2],particles=2))
        for x,y in zip(a,c):
            x=copy.deepcopy(x);y=copy.deepcopy(y)
            x.pop('runtime');y.pop('runtime')
            self.assertEqual(x,y)

    def test_independent_clock_detects_outage(self):
        h=[obs(t,(t,0.)) for t in np.arange(7)*.1]
        rows=list(b.online_forecasts(h,[.6,1.],particles=2))
        self.assertIn(rows[0]['packet']['status'],('ready','degraded'))
        self.assertEqual(rows[1]['packet']['status'],'stale')
        self.assertEqual(rows[1]['baselines']['CV']['status'],'stale')


if __name__=='__main__':unittest.main()

import unittest
import numpy as np
from simulation import results


class ResultsTests(unittest.TestCase):
    def test_manifest_cannot_claim_unexecuted_settings(self):
        import json
        from pathlib import Path
        from run_experiment import validate_manifest
        manifest=json.loads(Path('simulation/manifest.json').read_text())
        validate_manifest(manifest)
        for key,value in [('duration_s',20.),('particles_per_mode',100),('offset_xy',[0.,0.]),('noise_std',[1.,1.,1.])]:
            altered=dict(manifest,**{key:value})
            with self.assertRaises(ValueError,msg=key):validate_manifest(altered)

    def test_truth_lookup_rejects_future_outside_available_labels(self):
        t=dict(t=np.array([0.,1.]),xy=np.array([[0.,0.],[2.,0.]]),
               velocity=np.array([[2.,0.],[2.,0.]]),yaw=np.zeros(2))
        xy,v,y=results.lookup(t,[.5])
        np.testing.assert_allclose(xy,[[1.,0.]])
        with self.assertRaises(ValueError):results.lookup(t,[1.1])

    def test_common_comparison_keeps_outage_in_availability(self):
        def row(imm,cv,ca):
            return dict(metrics={k:None if x is None else dict(ade_m=x,fde_m=x) for k,x in zip(('IMM','CV','CA'),(imm,cv,ca))},
                        coverage=dict(point_xy_coverage=0.,trajectory_xy_coverage=False,point_joint_coverage=0.,trajectory_joint_coverage=False,mean_sum_box_area_m2=0.))
        r=results.aggregate([row(1.,2.,3.),row(None,8.,9.)])
        self.assertEqual(r['scheduled_issues'],2)
        self.assertEqual(r['common_issues'],1)
        self.assertEqual(r['methods']['IMM']['available_issues'],1)
        self.assertEqual(r['methods']['CV']['common_ade_m'],2.)
        self.assertEqual(r['methods']['CV']['available_ade_m'],5.)


if __name__=='__main__':unittest.main()

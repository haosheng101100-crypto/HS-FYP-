import copy
import unittest
import numpy as np
from stage6.observation import Observation
from extensions import pipeline


class PipelineTests(unittest.TestCase):
    def test_labels_do_not_change_state_forecasts(self):
        obs=[Observation(t,t+.04,(t,0.),0.,np.diag([.0004,.0004,.0001])) for t in np.arange(11)*.1]
        labels=[dict(stamp=t,received_at=t+.05,position_xy=[t,0.],velocity_xy=[1.,0.],yaw=0.) for t in np.arange(1,11)*.1]
        changed=copy.deepcopy(labels)
        for l in changed:l['position_xy']=[100.,100.]
        a=list(pipeline.paired_online(obs,[0.,.5,1.],labels,imm_particles=1,ct_particles=4))
        b=list(pipeline.paired_online(obs,[0.,.5,1.],changed,imm_particles=1,ct_particles=4))
        for x,y in zip(a,b):
            self.assertEqual(x['packet'],y['packet'])
            self.assertEqual(x['CT_packet'],y['CT_packet'])
            self.assertFalse(any(e['completed_at']>x['now'] for e in x['matured']))
            self.assertTrue(all(e['received_at']<=x['now'] for e in x['innovation_events']))
        self.assertEqual(len(a[1]['innovation_events']),5)


if __name__=='__main__':unittest.main()

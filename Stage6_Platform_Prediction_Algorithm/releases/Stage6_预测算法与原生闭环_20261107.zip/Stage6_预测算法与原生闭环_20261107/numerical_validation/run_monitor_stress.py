"""Two predeclared sensor/evaluation failures, with durable execution times."""
import argparse,gzip,json,hashlib
from dataclasses import replace
from pathlib import Path
import numpy as np
from simulation.world import World,generate
from simulation.results import lookup
from extensions.pipeline import paired_online
from extensions.journal import RunJournal
from run_validation import write_json,save_data


def main(output):
    root=output/'monitor_stress';root.mkdir(exist_ok=False);journal=RunJournal(output/'时间记录')
    specs=[dict(id='outage_and_missing_label',seed=601,outage=[4.,5.5],drop_label_at=5.2),
           dict(id='camera_pose_bias',seed=602,bias_window=[4.,5.5],bias_xy=[.8,-.6])]
    protocol=dict(cases=specs,world=dict(speed=1.,steer=.25,profile='varying'),
                  label_scope='Independent simulator truth for delayed evaluation only; not a real-world onboard truth sensor.',
                  code_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__).parent/'extensions').glob('*.py')})
    write_json(output/'monitor_stress_protocol.json',protocol);summaries=[]
    for spec in specs:
        folder=root/spec['id'];folder.mkdir()
        with journal.run('monitor_'+spec['id'],dict(spec=spec,protocol_sha256=hashlib.sha256((output/'monitor_stress_protocol.json').read_bytes()).hexdigest()),12.,folder):
            data=generate(World(**protocol['world']),spec['seed'],outage=spec.get('outage'))
            if 'bias_window' in spec:
                lo,hi=spec['bias_window'];dx,dy=spec['bias_xy']
                data['observations']=[replace(o,position_xy=(o.position_xy[0]+dx,o.position_xy[1]+dy)) if lo<=o.stamp<=hi else o for o in data['observations']]
            save_data(folder,data);labels=[]
            for t in np.arange(121)*.1:
                if abs(t-spec.get('drop_label_at',-1))<1e-9:continue
                xy,v,yaw=lookup(data['truth'],[t]);labels.append(dict(stamp=float(t),received_at=float(t+.05),position_xy=xy[0].tolist(),velocity_xy=v[0].tolist(),yaw=float(yaw[0])))
            rows=[];matured=[];innovation=[]
            with gzip.open(folder/'forecasts.jsonl.gz','wt',encoding='utf-8') as f:
                for r in paired_online(data['observations'],np.arange(26)*.5,labels):
                    f.write(json.dumps(r,separators=(',',':'),allow_nan=False)+'\n');matured.extend(r['matured']);innovation.extend(r['innovation_events'])
                    if r['packet'] is not None:rows.append(dict(now=r['now'],predictor_status=r['packet']['status'],monitor=r['monitor']))
            summary=dict(run_id=spec['id'],issue_states=rows,delayed_missing=[dict(key=e['key'],issued_at=e['issued_at'],completed_at=e['completed_at'],missing_targets=e['missing_targets']) for e in matured if e['status']=='missing_labels'],
                         innovation_alarms=[e for e in innovation if e['latched']['innovation']],
                         first_innovation_alarm_received_at=next((e['received_at'] for e in innovation if e['latched']['innovation']),None))
            write_json(folder/'summary.json',summary);write_json(folder/'delayed_scores.json',matured);summaries.append(summary)
        print(spec['id'],'missing',len(summary['delayed_missing']),'innovation alarm',summary['first_innovation_alarm_received_at'],flush=True)
    write_json(output/'monitor_stress_summary.json',summaries)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);main(p.parse_args().output)

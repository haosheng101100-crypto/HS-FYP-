"""Owned visible Gazebo + real ArduCopter SITL + Stage6 closed-loop trial."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,signal,subprocess,sys,time,uuid,traceback
from extensions.journal import RunJournal
from integration.native_window import owned_gazebo_window,window_geometry
HERE=Path(__file__).resolve().parent
BASE=Path('/runtime_base');SOURCE=BASE/'reference';FROZEN=BASE/'baseline'

def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def prepare(run):
    for name in ('scripts','tools','models','worlds','config','first_stage','control'):
        shutil.copytree(SOURCE/name,run/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    manifest=json.loads((FROZEN/'package_manifest.json').read_text())
    for name,digest in manifest['source_sha256'].items():assert hashlib.sha256((FROZEN/name).read_bytes()).hexdigest()==digest,name
    for p in FROZEN.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            dst=run/p.relative_to(FROZEN);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    for name in ('vendor','venv','gz_prefix'):(run/name).symlink_to(BASE/name,target_is_directory=True)
    (run/'runtime').mkdir();(run/'results').mkdir();(run/'runtime/gz_config').symlink_to(BASE/'runtime/gz_config',target_is_directory=True)
    # Explicitly deploy all isolated implementation modules, including worker imports.
    for name in ('landing','stage6','extensions','integration','native_assets'):
        shutil.copytree(HERE/name,run/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for name in ('interactive_base.py','operator_backend.py','operator_clock.py','operator_legacy.py'):
        shutil.copy2(HERE/'operator'/name,run/'tools'/name)
    shutil.copy2(HERE/'operator/tools/receding_planner_worker.py',run/'tools/receding_planner_worker.py')
    for auditor in (HERE/'tools').glob('audit_*.py'):shutil.copy2(auditor,run/'tools'/auditor.name)
    recorder_path=run/'tools/record_model_states.py'
    recorder_code=recorder_path.read_text()
    recorder_code=recorder_code.replace('while running:',"(output/'data_subscriptions_ready.json').write_text(json.dumps(dict(ready=True,topics=['/model/uav/pose','/model/landing_vehicle/pose','native deck contact'],wall_unix_s=time.time())))\nwhile running:")
    recorder_code=recorder_code.replace('with lock:stream.flush()',"with lock:\n        stream.flush()\n        health=output/'model_state_health.tmp'\n        health.write_text(json.dumps(dict(counts=counts,wall_unix_s=time.time(),subscriptions_alive=True)))\n        health.replace(output/'model_state_health.json')")
    recorder_path.write_text(recorder_code)
    shutil.copy2(HERE/'config/experiments/stage6_four_wheel.json',run/'config/experiments/receding_live_v1.json')
    shutil.copy2(HERE/'native_assets/models/landing_vehicle/model.sdf',run/'models/landing_vehicle/model.sdf')
    from operator import itemgetter  # standard library only
    world=run/'worlds/uav_vehicle_stage1.sdf'
    text=world.read_text();text=text.replace('<pose>5 0 0.002 0 0 0</pose>','<pose>3 0 0.002 0 0 0</pose>')
    # Embed the inspected physical model, avoiding image-specific include callbacks.
    import xml.etree.ElementTree as ET
    tree=ET.fromstring(text);models=ET.parse(run/'models/landing_vehicle/model.sdf').getroot();model=models.find('model')
    sensor=model.find('./link[@name="chassis"]/sensor[@name="deck_contact"]')
    assert sensor is not None and sensor.get('type')=='contact' and sensor.findtext('contact/collision')=='landing_deck','Real deck contact sensor required'
    systems={node.get('name') for node in tree.findall('./world/plugin')}
    assert {'gz::sim::systems::Sensors','gz::sim::systems::Contact'}<=systems,'Native sensor/contact systems required'
    target=None
    for inc in tree.findall('.//include'):
        if inc.findtext('uri')=='model://landing_vehicle':target=inc;break
    assert target is not None,'Expected physical vehicle include'
    pose=target.find('pose')
    if pose is not None:
        old=model.find('pose')
        if old is not None:model.remove(old)
        model.append(pose)
    worldnode=tree.find('world');worldnode.remove(target);worldnode.append(model)
    live=json.loads((run/'config/experiments/receding_live_v1.json').read_text())
    real_time_factor=worldnode.find('physics/real_time_factor')
    assert real_time_factor is not None
    real_time_factor.text=str(live.get('native_real_time_factor',1.))
    for link in model.findall('link'):
        used={e.get('name') for e in link if e.tag!='visual' and e.get('name')}
        for visual in link.findall('visual'):
            name=visual.get('name')
            while name in used:name='visual_'+name
            visual.set('name',name);used.add(name)
    world.write_text(ET.tostring(tree,encoding='unicode'))
    from integration.world_builder import build_world
    (run/'worlds/validation_car_world.sdf').write_text(build_world(run/'models/landing_vehicle/model.sdf'))
    cfg=(HERE/'native_assets/foreground_gui.config').read_text()
    (run/'foreground_gui.config').write_text(cfg)
    raw=subprocess.check_output(['bash','-c','source ./scripts/env.sh;env -0'],cwd=run)
    env=dict(x.decode().split('=',1) for x in raw.split(b'\0') if b'=' in x)
    env.update(GZ_PARTITION='stage8_'+uuid.uuid4().hex,DISPLAY=os.environ['DISPLAY'],XAUTHORITY=os.environ['XAUTHORITY'],XDG_RUNTIME_DIR=os.environ['XDG_RUNTIME_DIR'],HOME=os.environ['HOME'],
        LP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',LIBGL_ALWAYS_SOFTWARE='1',QT_SCALE_FACTOR='1',QT_AUTO_SCREEN_SCALE_FACTOR='0',QT_ENABLE_HIGHDPI_SCALING='0',QT_FONT_DPI='96',QT_SCREEN_SCALE_FACTORS='1',GDK_SCALE='1',GDK_DPI_SCALE='1',HS_OPERATOR_SESSION=str(run/'operator_session'),HS_AUTONOMOUS_TRIAL='1')
    session=run/'operator_session';session.mkdir();(session/'requests').mkdir();(session/'processed').mkdir()
    return env


def main(out,scenarios,frozen_source=False):
    global HERE
    if os.environ.get('DISPLAY')!=':0':raise RuntimeError('Actual current desktop DISPLAY=:0 required')
    for key,stem in (('XDG_RUNTIME_DIR','stage8-runtime'),('HOME','stage8-home')):
        p=Path('/tmp')/(stem+'-'+uuid.uuid4().hex);p.mkdir(mode=0o700);os.environ[key]=str(p)
    selection=HERE/'verification/native_case_selection.json'
    if selection.exists():
        scenarios=json.loads(selection.read_text())['scenarios']
        if not scenarios or not all(c in ('constant','varying','turning','prediction_dropout') for c in scenarios):raise ValueError('Unknown declared validation case')
    if not frozen_source:
        out.mkdir(parents=True,exist_ok=False)
        shutil.copytree(HERE,out/'source_snapshot',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        os.execv(sys.executable,[sys.executable,'-u',str(out/'source_snapshot/foreground_closed_loop.py'),'--output',str(out),'--scenarios',*scenarios,'--frozen-source'])
    if HERE.resolve()!=(out/'source_snapshot').resolve():raise RuntimeError('Frozen entrypoint required')
    journal=RunJournal(out/'时间记录')
    save(out/'source_sha256.json',{str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
    for scenario in scenarios:
        run=out/scenario;run.mkdir();processes=[];files=[];backend=None;rec=None
        artifact=Path(os.environ['HS_HOST_PROJECT'])/run.relative_to('/project')
        with journal.run('native_uav_'+scenario,dict(scenario=scenario,display=':0',operation='closed_loop_simulation',source=str(out/'source_sha256.json'),duration_note='Observed first-to-last saved native physics timestamp, not planned duration'),None,artifact) as execution_id:
            try:
                env=prepare(run);env['HS_TRIAL_SCENARIO']=scenario
                save(run/'environment.json',dict(display=env['DISPLAY'],partition=env['GZ_PARTITION'],scenario=scenario,scope='Native UAV/FCU with Stage6 pose-only prediction'))
                def start(name,args):
                    f=(run/'results'/f'{name}.log').open('x');files.append(f)
                    p=subprocess.Popen(args,cwd=run,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);processes.append((name,p));save(run/'results/managed_processes.json',[dict(name=n,pid=p.pid) for n,p in processes]);return p
                pre=start('preflight',['./venv/bin/python','-c','from pathlib import Path;from landing.reference_loader import load_verified_reference;load_verified_reference(Path.cwd());print("Frozen contact geometry verified")'])
                if pre.wait(timeout=30):raise RuntimeError('Frozen reference preflight failed')
                check=subprocess.run(['gz','sdf','-k',str(run/'worlds/validation_car_world.sdf')],env=env,cwd=run,capture_output=True,text=True)
                (run/'results/sdf_check.txt').write_text(check.stdout+check.stderr)
                if check.returncode:raise RuntimeError('Physical SDF validation failed')
                server=start('gazebo_server',['gz','sim','-s','-v','2','./worlds/uav_vehicle_stage1.sdf'])
                gui=start('gazebo_gui',['gz','sim','-g','-v','2','--gui-config',str(run/'foreground_gui.config')])
                deadline=time.monotonic()+75;window=None
                while time.monotonic()<deadline:
                    if server.poll() is not None or gui.poll() is not None:raise RuntimeError('Native simulator exited')
                    window=owned_gazebo_window(gui.pid,run/'results/window_candidates.json')
                    if window:break
                    time.sleep(.2)
                if not window:raise RuntimeError('No visible owned native GUI; no flight permitted')
                time.sleep(.5)
                width,height=window_geometry(window['window_id'])
                window.update(pixel_width=width,pixel_height=height)
                save(run/'results/gui_evidence.json',dict(**window,display=':0',wall_unix_s=time.time()))
                rec=start('window_recording',['ffmpeg','-nostdin','-hide_banner','-loglevel','warning','-n','-f','x11grab','-video_size',f'{width}x{height}','-draw_mouse','0','-framerate','10','-window_id',str(window['window_id']),'-i',env['DISPLAY'],'-an','-c:v','libx264','-preset','ultrafast','-crf','23','-threads','1','-pix_fmt','yuv420p','-movflags','+frag_keyframe+empty_moov+default_base_moof',str(run/'foreground_raw.mp4')])
                time.sleep(.5)
                if rec.poll() is not None:raise RuntimeError('Actual window recorder not ready')
                states=start('model_states',['python3','./tools/record_model_states.py','./results'])
                deadline=time.monotonic()+20
                while not (run/'results/data_subscriptions_ready.json').exists():
                    if states.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Native data subscriptions not ready before unpause')
                    time.sleep(.05)
                save(run/'results/before_unpause_readiness.json',dict(gui=window,recorder_pid=rec.pid,data_recorder_pid=states.pid,wall_unix_s=time.time()))
                # Owned native-world pause/advancing acknowledgement, same partition.
                unpause_code=(HERE/'native_unpause.py').read_text().replace('stage6_prediction','uav_vehicle_stage1')
                (run/'tools/stage8_unpause.py').write_text(unpause_code)
                ack=subprocess.run(['./venv/bin/python','./tools/stage8_unpause.py',str(run/'results')],cwd=run,env=env,capture_output=True,text=True,timeout=40)
                (run/'results/unpause.log').write_text(ack.stdout+ack.stderr)
                if ack.returncode:raise RuntimeError('Actual paused-to-advancing transition not confirmed')
                fcu=start('arducopter',['bash','./scripts/run_fcu.sh'])
                wait=start('wait_scene',['./venv/bin/python','./tools/wait_scene.py','--world','uav_vehicle_stage1'])
                if wait.wait(timeout=200):raise RuntimeError('Native scene readiness failed')
                topic='/world/uav_vehicle_stage1/model/landing_vehicle/link/chassis/sensor/deck_contact/contact'
                topics=subprocess.run(['gz','topic','-l'],env=env,cwd=run,capture_output=True,text=True,timeout=15)
                (run/'results/native_topics.txt').write_text(topics.stdout+topics.stderr)
                q=subprocess.run(['gz','topic','-i','-t',topic],env=env,cwd=run,capture_output=True,text=True,timeout=15)
                save(run/'results/contact_publisher_evidence.json',dict(topic=topic,stdout=q.stdout,stderr=q.stderr,returncode=q.returncode,wall_unix_s=time.time()))
                publisher=q.stdout.split('Subscribers')[0]
                if q.returncode or 'gz.msgs.Contacts' not in publisher or 'tcp://' not in publisher:raise RuntimeError('Actual native Contacts publisher not confirmed; no flight permitted')
                env['HS_DECK_CONTACT_TOPIC']=topic
                worker=start('receding_planner',['./venv/bin/python','-u','./tools/receding_planner_worker.py'])
                sampler=start('stage6_sampler',['./venv/bin/python','-u','./integration/sampler_worker.py'])
                deadline=time.monotonic()+120
                while not all((run/p).exists() for p in ('runtime/receding_planner/health.json','runtime/stage6_sampler/health.json')):
                    if worker.poll() is not None or sampler.poll() is not None:raise RuntimeError('Planner/sampler prewarm failed')
                    if time.monotonic()>deadline:raise RuntimeError('Prewarm timed out')
                    time.sleep(.2)
                backend=start('operator_backend',['./venv/bin/python','-u','./tools/operator_backend.py'])
                while backend.poll() is None:
                    if gui.poll() is not None or rec.poll() is not None or sampler.poll() is not None or worker.poll() is not None:
                        req=run/'operator_session/requests'/f'{time.time_ns()}_close.json';save(req,dict(action='close'))
                    time.sleep(.2)
                status=json.loads((run/'operator_session/status.json').read_text())
                if status.get('armed'):raise RuntimeError('Backend returned while armed; preserve native scene')
                # Stop recording cleanly, decode all frames before claiming evidence.
                rec.send_signal(signal.SIGINT);rec.wait(timeout=20)
                decoded=subprocess.run(['ffmpeg','-v','error','-i',str(run/'foreground_raw.mp4'),'-f','null','-'],cwd=run,env=env,capture_output=True,text=True,timeout=90)
                (run/'results/recording_decode.txt').write_text(decoded.stdout+decoded.stderr)
                if decoded.returncode:raise RuntimeError('Raw native recording decode failed')
                subprocess.run(['ffmpeg','-v','error','-y','-sseof','-2','-i',str(run/'foreground_raw.mp4'),'-frames:v','1',str(run/'final_frame.png')],cwd=run,env=env,check=True,timeout=30)
                save(run/'results/recording_verified.json',dict(decoded=True,bytes=(run/'foreground_raw.mp4').stat().st_size))
                result=json.loads((run/'results/execution_status.json').read_text())
                q=subprocess.run(['gz','topic','-i','-t',topic],env=env,cwd=run,capture_output=True,text=True,timeout=15)
                save(run/'results/contact_publisher_postflight.json',dict(topic=topic,stdout=q.stdout,stderr=q.stderr,returncode=q.returncode,wall_unix_s=time.time()))
                if q.returncode or 'gz.msgs.Contacts' not in q.stdout.split('Subscribers')[0] or 'tcp://' not in q.stdout.split('Subscribers')[0]:raise RuntimeError('Contact publisher lost before postflight audit')
                link=subprocess.run(['./venv/bin/python','./tools/audit_stage6_link.py',str(run)],cwd=run,env=env,capture_output=True,text=True,timeout=180)
                (run/'results/audit_stage6_link.py.log').write_text(link.stdout+link.stderr)
                if link.returncode or not json.loads((run/'results/stage6_link_audit.json').read_text())['passed']:raise RuntimeError('Stage6 causal prediction link audit failed')
                expected=json.loads((run/'config/experiments/receding_live_v1.json').read_text()).get('validation_expectations',{}).get(scenario,'landing')
                if result.get('completed'):
                    for tool in ('audit_receding_commands.py','audit_native_landing.py','audit_receding_physics.py'):
                        audit=subprocess.run(['./venv/bin/python','./tools/'+tool,str(run)],cwd=run,env=env,capture_output=True,text=True,timeout=120)
                        (run/'results'/(tool+'.log')).write_text(audit.stdout+audit.stderr)
                        if audit.returncode:raise RuntimeError('Independent auditor failed: '+tool)
                    for name in ('independent_command_audit.json','native_landing_audit.json','independent_contact_audit.json'):
                        if not json.loads((run/'results'/name).read_text())['passed']:raise RuntimeError('Independent native audit rejected '+name)
                save(run/'results/final_native_result.json',dict(completed=bool(result.get('completed')),backend_exit_code=backend.returncode,armed=bool(result.get('armed_at_save')),last_status=status))
                if expected=='safe_exit':
                    if result.get('completed') or result.get('armed_at_save') or not (run/'results/prediction_dropout_injection.json').exists():raise RuntimeError('Declared dropout exit contract failed')
                    for tool in ('audit_receding_commands.py','audit_native_landing.py','audit_stage6_exit.py'):
                        audit=subprocess.run(['./venv/bin/python','./tools/'+tool,str(run)],cwd=run,env=env,capture_output=True,text=True,timeout=120)
                        (run/'results'/(tool+'.log')).write_text(audit.stdout+audit.stderr)
                        if audit.returncode:raise RuntimeError('Exit auditor failed '+tool)
                    for name in ('independent_command_audit.json','native_landing_audit.json','stage6_exit_audit.json'):
                        if not json.loads((run/'results'/name).read_text())['passed']:raise RuntimeError('Declared safe exit rejected '+name)
                elif backend.returncode or not result.get('completed') or result.get('armed_at_save'):raise RuntimeError('Native closed-loop landing did not pass; inspect retained local logs')
            except Exception:
                (run/'results/attempt_error.txt').write_text(traceback.format_exc());raise
            finally:
                # Arming intent is durably recorded before the only arming call.
                # Missing/corrupt/stale UI status never authorizes teardown.
                from integration.native_exit import may_stop_scene
                while backend is not None and not may_stop_scene(run/'results',backend.poll() is None,time.time()):
                    if backend.poll() is not None:
                        from integration.native_ack import refresh_disarmed_ack
                        try:
                            if refresh_disarmed_ack(run/'results'):continue
                        except Exception:
                            (run/'results/native_ack_observer_error.txt').write_text(traceback.format_exc())
                    if backend.poll() is None:
                        save(run/'operator_session/requests'/'native_cleanup_close.json',dict(action='close'))
                    save(run/'results/requires_recovery.json',dict(native_scene_preserved=True,reason='No fresh native disarmed acknowledgement after arming intent',detected_wall_unix_s=time.time()))
                    time.sleep(.5)
                for name,p in reversed(processes):
                    if p.poll() is None:
                        os.killpg(p.pid,signal.SIGTERM)
                        try:p.wait(timeout=8)
                        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
                for f in files:f.close()
                save(run/'results/owned_processes_closed.json',dict(closed=True))
                from tools.index_native_times import observed_clock
                duration=observed_clock(run/'results/model_states.jsonl')
                save(run/'results/observed_physics_clock.json',duration)
                if duration is not None:journal.observe_duration(execution_id,duration['observed_span_s'])
    save(out/'native_complete.json',dict(scenarios=scenarios,processes_closed=True,scope='Actual visible native UAV/FCU integration; audit result files before landing claims'))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--scenarios',nargs='+',default=['constant']);p.add_argument('--frozen-source',action='store_true');a=p.parse_args();main(a.output,a.scenarios,a.frozen_source)

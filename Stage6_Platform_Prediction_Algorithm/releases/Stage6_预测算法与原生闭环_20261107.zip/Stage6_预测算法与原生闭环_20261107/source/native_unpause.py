"""Explicit unpause in the SAME native transport environment as this world."""
import json,os,sys,time
from pathlib import Path
from gz.transport13 import Node
from gz.msgs10.world_stats_pb2 import WorldStatistics
from gz.msgs10.world_control_pb2 import WorldControl
from gz.msgs10.boolean_pb2 import Boolean

folder=Path(sys.argv[1]);node=Node();stats=[]
def receive(msg):stats.append((msg.paused,msg.sim_time.sec+msg.sim_time.nsec*1e-9))
if not node.subscribe(WorldStatistics,'/world/stage6_prediction/stats',receive):raise RuntimeError('Cannot observe owned world statistics')
deadline=time.monotonic()+15
while not stats:
    if time.monotonic()>deadline:raise RuntimeError('No owned-world paused statistics')
    time.sleep(.05)
if not stats[-1][0]:raise RuntimeError('World ran before owned GUI/recorder readiness')
before=stats[-1];started=time.time()
ok,response=node.request('/world/stage6_prediction/control',WorldControl(pause=False),WorldControl,Boolean,5000)
deadline=time.monotonic()+10
while stats[-1][0] or stats[-1][1]<=before[1]:
    if time.monotonic()>deadline:raise RuntimeError('No actual advancing unpaused physics confirmation')
    time.sleep(.05)
(folder/'unpause_transport_ack.json').write_text(json.dumps(dict(partition=os.environ['GZ_PARTITION'],request_reply_ok=bool(ok and response.data),confirmation='actual owned-world statistics show unpaused advancing physics',before_paused=before[0],before_sim_s=before[1],after_paused=stats[-1][0],after_sim_s=stats[-1][1],wall_unix_s=started),indent=2)+'\n')
node.unsubscribe('/world/stage6_prediction/stats')
# The native transport worker can abort during Python interpreter teardown.
# All evidence is closed/flushed above; this short-lived helper owns no physics.
os._exit(0)

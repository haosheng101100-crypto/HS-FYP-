#!/usr/bin/env bash
set -euo pipefail
project=/home/sheng-hao/Documents/Codex/2026-11-05/new-chat
base=/home/sheng-hao/Documents/Codex/2026-10-28/new-chat/work/reacquisition_20261102/deployment
: "${HS_STAGE6_UID:?}" "${HS_STAGE6_GID:?}" "${DISPLAY:?}" "${XAUTHORITY:?}"
while true; do
stamp=$(date +%Y%m%d_%H%M%S)
result_rel="outputs/Stage8_前台降落闭环_${stamp}_$$"
printf '%s\n' "$project/$result_rel" > "$project/outputs/前台仿真启动记录/当前闭环目录.txt"
set +e
docker run --rm --init --name "hs-stage8-$stamp-$$" --network host --ipc host --user "$HS_STAGE6_UID:$HS_STAGE6_GID" \
-v "$project:/project" -v "$base:/runtime_base:ro" -v /tmp/.X11-unix:/tmp/.X11-unix:ro -v "$XAUTHORITY:/tmp/host.Xauthority:ro" \
-e DISPLAY=:0 -e XAUTHORITY=/tmp/host.Xauthority -e HS_HOST_PROJECT="$project" -e OPENBLAS_NUM_THREADS=1 \
hs-fyp-demo:20261102-verified /opt/hs-venv/bin/python -u /project/work/stage8_closed_loop/foreground_closed_loop.py --output "/project/$result_rel" --scenarios "${HS_TRIAL_CASE:-constant}"
status=$?
set -e
printf '%s\n' "$status" > "$project/outputs/前台仿真启动记录/最近闭环退出码.txt"
echo "Native attempt exited $status; retaining logs. Waiting for explicit repaired retry file."
while [[ ! -f "$project/outputs/前台仿真启动记录/closed_loop_retry.request" ]]; do sleep 2; done
rm "$project/outputs/前台仿真启动记录/closed_loop_retry.request"
done

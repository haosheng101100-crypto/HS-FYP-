#!/usr/bin/env bash
set -euo pipefail
export HS_STAGE6_UID="$(id -u)" HS_STAGE6_GID="$(id -g)"
export DISPLAY=:0
test -f "${XAUTHORITY:?需要当前桌面的图形授权}"
echo '继续第六阶段前台 Gazebo 无人机仿真。请仅在此终端完成系统认证，不要把密码发到聊天。'
echo '本终端会保留本次任务的认证会话，用于修复和核验重试。'
exec sudo --preserve-env=DISPLAY,XAUTHORITY,HS_STAGE6_UID,HS_STAGE6_GID bash /home/sheng-hao/Documents/Codex/2026-11-05/new-chat/work/stage8_closed_loop/start_foreground_closed_loop.sh

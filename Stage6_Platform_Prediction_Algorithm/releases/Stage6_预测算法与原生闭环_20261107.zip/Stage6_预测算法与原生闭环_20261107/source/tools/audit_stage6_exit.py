"""Independent raw-pose clearance audit for declared prediction receipt dropout."""
from pathlib import Path
import bisect,hashlib,json,sys,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from landing.contact_geometry import Pose,Deck,RigidMotion,AirframeGeometry,evaluate_airframe,norm
from landing.execution import parse_deck_contacts

def stamp(p):
    s=p.get('header',{}).get('stamp',{});return float(s.get('sec',0))+float(s.get('nsec',0))*1e-9

def interval_covered(times,lo,hi):
    times=sorted(times)
    before=bisect.bisect_right(times,lo)-1;after=bisect.bisect_left(times,hi)
    return before>=0 and after<len(times) and lo-times[before]<=.06 and times[after]-hi<=.06 and all(0<b-a<=.06 for a,b in zip(times[before:after],times[before+1:after+1]))

def main(run):
    r=run/'results';cfg=json.loads((run/'config/experiments/execution_v1.json').read_text());live=json.loads((run/'config/experiments/receding_live_v1.json').read_text())
    injection=json.loads((r/'prediction_dropout_injection.json').read_text());status=json.loads((r/'execution_status.json').read_text());attempts=json.loads((r/'receding_attempts.json').read_text())
    rows=[json.loads(line) for line in (r/'receding_control.jsonl').open()];recovery=next(v for v in rows if v['stage']=='RECOVERING');returned=rows[-1];home=rows[0]['decision']['reference']['position_world_m']
    geometry=AirframeGeometry.load(run/cfg['airframe_profile']);mapping={cfg['leg_collision_prefix']+leg.name:leg.name for leg in geometry.legs}
    poses={'uav_pose':{},'car_pose':{}};contact=[];raw=r/'model_states.jsonl';h=hashlib.sha256()
    with raw.open('rb') as f:
        for line in f:
            h.update(line);v=json.loads(line);msg=v['message'];kind=v['kind']
            if kind in poses:
                name='uav' if kind=='uav_pose' else 'landing_vehicle'
                for p in msg.get('pose',[]):
                    if p['name']==name:poses[kind][stamp(p)]=Pose(tuple(p.get('position',{}).get(k,0.) for k in 'xyz'),tuple(p.get('orientation',{}).get(k,0.) for k in 'xyzw'))
            elif kind=='deck_contact':
                frame=parse_deck_contacts(msg,cfg['deck_collision'],mapping,cfg['uav_model_prefix'])
                if frame.active:contact.append(frame.sim_t_s)
    car=sorted(poses['car_pose'].items());cts=[t for t,p in car];clearances=[]
    def publisher_healthy(name):
        d=json.loads((r/name).read_text());pub=d['stdout'].split('Subscribers')[0]
        return d['returncode']==0 and 'gz.msgs.Contacts' in pub and 'tcp://' in pub
    health=json.loads((r/'model_state_health.json').read_text())
    for t,p in sorted(poses['uav_pose'].items()):
        if not injection['sim_t_s']<=t<=returned['sim_t_s']:continue
        i=bisect.bisect_right(cts,t)-1
        if i<0 or not 0<=t-cts[i]<=.06:raise ValueError('Missing synchronized raw vehicle pose')
        cp=car[i][1];deck=Deck(RigidMotion.stationary(Pose(cp.transform((0,0,.8)),cp.orientation_xyzw)),tuple(live['deck_half_extents']))
        clearances.append(min(f.clearance_m for f in evaluate_airframe(geometry,RigidMotion.stationary(p),deck)))
    checks=dict(explicit_sensor_fault_recorded=injection['scope'].startswith('Explicit validation-only'),
        fault_during_measured_descent=injection['measured_vertical_speed_m_s']<-.03 and 0<injection['measured_previous_leg_gap_m']<=1.1,
        stale_detected_within_original_age_gate=0<=recovery['sim_t_s']-injection['sim_t_s']<=.20,
        full_raw_uav_interval=interval_covered(poses['uav_pose'],injection['sim_t_s'],returned['sim_t_s']),full_raw_vehicle_interval=interval_covered(poses['car_pose'],injection['sim_t_s'],returned['sim_t_s']),
        event_contact_channel_verified=publisher_healthy('contact_publisher_evidence.json') and publisher_healthy('contact_publisher_postflight.json'),
        recorder_alive_at_audit=health['subscriptions_alive'] and 0<=time.time()-health['wall_unix_s']<=3. and health['counts'].get('uav_pose',0)>0 and health['counts'].get('car_pose',0)>0,
        no_physical_deck_contact=not contact,positive_clearance_during_return=bool(clearances) and min(clearances)>.05,
        returned_home_hover=returned['stage']=='HOVER' and norm(tuple(a-b for a,b in zip(returned['observation']['motion']['pose']['position_world_m'],home)))<.08 and norm(returned['observation']['motion']['velocity_at_origin_world_m_s'])<.08,
        stale_prediction_rejection_reported=bool(attempts) and attempts[-1]['success'] is False and 'STAGE6_UNAVAILABLE:stale_measurement' in attempts[-1]['reason'],
        landing_not_claimed=status['completed'] is False,
        normal_ground_land=status['armed_at_save'] is False and status['final_mode']=='LAND',
        no_other_execution_error=status['external_failures']==['Automatic trial returned home after failed attempt'],
        raw_final_pose_on_ground=abs(max(poses['uav_pose'].items())[1].position_world_m[2]-.195)<.03)
    checks={k:bool(v) for k,v in checks.items()};report=dict(passed=all(checks.values()),checks=checks,trigger=injection,abort_sim_s=recovery['sim_t_s'],minimum_raw_clearance_m=min(clearances),raw_source_sha256=h.hexdigest(),scope='Actual declared receipt-dropout trial; native ground LAND and return, not a deck landing. Raw clearance sampled, no invariant safe-exit proof.')
    (r/'stage6_exit_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main(Path(sys.argv[1]))

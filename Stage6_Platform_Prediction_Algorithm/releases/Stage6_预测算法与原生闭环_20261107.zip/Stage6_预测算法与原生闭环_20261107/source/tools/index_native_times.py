"""Index durable wall times and observed physics clocks without inventing ends."""
import gzip,json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


def observed_clock(path):
    first = last = None
    if not path.exists() and not path.with_suffix('.jsonl.gz').exists():
        return None
    stream=path.open(errors='replace') if path.exists() else gzip.open(path.with_suffix('.jsonl.gz'),'rt',errors='replace')
    with stream:
        for line in stream:
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get('kind') != 'uav_pose':
                continue
            for pose in row['message'].get('pose', []):
                if pose['name'] != 'uav':
                    continue
                stamp = pose.get('header', {}).get('stamp', {})
                t = float(stamp.get('sec', 0)) + float(stamp.get('nsec', 0)) * 1e-9
                first = t if first is None else min(first, t)
                last = t if last is None else max(last, t)
    return None if first is None else dict(first_sim_s=first, last_sim_s=last, observed_span_s=last-first)


def main(project):
    records = []
    for folder in sorted((project/'outputs').glob('Stage8_前台降落闭环_*')):
        events = folder/'时间记录/events.jsonl'
        if not events.exists():
            continue
        attempts = {}
        for line in events.read_text().splitlines():
            event = json.loads(line)
            attempts.setdefault(event['execution_id'], {}).update(event)
        for event in attempts.values():
            case = event['metadata']['scenario']
            run = folder/case
            clock = observed_clock(run/'results/model_states.jsonl')
            record = dict(directory=str(run), scenario=case, started_at=event['started_at'],
                          ended_at=event.get('ended_at'), wall_elapsed_s=event.get('wall_elapsed_s'),
                          status=event.get('status', 'running_or_interrupted'), observed_physics=clock,
                          source_sha256=str(folder/'source_sha256.json'))
            if (run/'中断核验.json').exists():
                record['status']='interrupted_end_unknown'
            records.append(record)
    generated = datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds')
    (project/'outputs/仿真时间总索引.json').write_text(json.dumps(dict(generated_at=generated, attempts=records),ensure_ascii=False,indent=2)+'\n')
    lines=['# 第八阶段实际仿真时间记录', '', '全部为北京时间。缺少结束事件的运行不补造结束时间或实际耗时。场景时长取已保存的原始物理时钟；不是计划时长。失败和中断均保留本机。', '', '| 场景 | 开始 | 结束 | 实际耗时/秒 | 已记录场景跨度/秒 | 状态 | 记录 |', '|---|---|---|---:|---:|---|---|']
    for r in records:
        duration=r['observed_physics']['observed_span_s'] if r['observed_physics'] else '未知'
        lines.append(f"| {r['scenario']} | {r['started_at']} | {r['ended_at'] or '未记录'} | {r['wall_elapsed_s'] if r['wall_elapsed_s'] is not None else '未知'} | {duration} | {r['status']} | [查看]({r['directory']}) |")
    (project/'outputs/仿真时间总索引.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':
    import sys
    main(Path(sys.argv[1]).resolve())

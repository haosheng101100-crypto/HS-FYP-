"""Replay logged causal observations and all sampled branches; no flight claims."""
from pathlib import Path
from dataclasses import asdict
import gzip,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from stage6.predictor import VehiclePredictor
from stage6.observation import Observation
from stage6.model import MODES
from integration.flight_prediction import union_tube,select_nominal_mode
from landing.stage6_nominal import propagate
from landing.receding_landing import PlatformState
from landing.planar_landing import inflate_forecast_tube
from audit_planar_policy import equal,audit_rows,audit_saved_plans


def main(run):
    r=run/'results';cfg=json.loads((run/'config/experiments/receding_live_v1.json').read_text())
    # The online nominal records the actual deployed offset explicitly.
    rows=[json.loads(line) for line in (r/'receding_control.jsonl').open()]
    first=next(row['platform']['vehicle_nominal'] for row in rows if row['platform'].get('vehicle_nominal'))
    predictor=VehiclePredictor(first['offset'],jerk_process_scale=cfg['stage6_sampling']['current_filter_jerk_process_scale'])
    observations=iter(json.loads(line) for line in (r/'stage6_observations.jsonl').open())
    pending=next(observations,None);last_stamp=-float('inf');failures=[];checked=0;snapshots={}
    calls=iter(json.loads(line) for line in (r/'stage6_link.jsonl').open())
    call_index=0;consumed=0;mode_index=None
    # Keep one stream cursor: forecasts are large, chronological, and immutable.
    stream=gzip.open(r/'stage6_samples.jsonl.gz','rt');packets={};packet_rows=iter(stream)
    last_sequence=0
    for row in rows:
        t=row['sim_t_s']
        report=row.get('stage6_prediction',{})
        target=report['call_sequence']
        if target<=call_index:raise ValueError('Control rows must reference increasing bridge calls')
        while call_index<target:
            call=next(calls);call_index+=1
            if call['call_sequence']!=call_index or call['time']>t+1e-9:raise ValueError('Missing, reordered or future bridge invocation')
            if call['samples']<consumed:raise ValueError('Observation count reversed')
            while consumed<call['samples']:
                o=Observation(**pending)
                if not (last_stamp<o.stamp<=o.received_at-.04+1e-8 and o.received_at<=call['time']+1e-9):raise ValueError('Noncausal or duplicate observation')
                predictor.update(o);last_stamp=o.stamp;pending=next(observations,None);consumed+=1
            eligible=predictor.latest is not None and predictor.sample_count>=5 and predictor.latest.stamp-predictor.first_stamp>=.4 and 0<=call['time']-predictor.latest.stamp<=.12+1e-9
            if eligible:mode_index=select_nominal_mode(predictor.weights,mode_index)
            if eligible!=call['nominal_selection_applied'] or mode_index!=call['nominal_mode_index']:raise ValueError('Nominal selection history mismatch')
        if not equal(call,report):raise ValueError('Control row does not match its bridge invocation')
        if not report.get('ready'):continue
        checked+=1
        model=row['platform']['vehicle_nominal'];f=predictor.filters[mode_index]
        age=t-predictor.latest.stamp
        if not (0<=age<=.12000001 and equal(age,report['observation_age_s'])):failures.append([t,'observation_age'])
        if f.mode.name!=model['mode'] or not np.allclose(predictor.weights,report['weights'],atol=1e-8,rtol=1e-8) or not np.allclose(propagate(f.mean,f.mode.name,age),model['state'],atol=1e-8,rtol=1e-8):failures.append([t,'filter_replay'])
        sequence=report['sequence']
        while last_sequence<sequence:
            value=json.loads(next(packet_rows));last_sequence=value['sequence'];packets[last_sequence]=value['packet']
        packet=packets[sequence]
        expected=packet['configuration']
        if expected['future_input_process_scale']!=1. or expected['current_filter_jerk_process_scale']!=predictor.jerk_process_scale or not equal(expected['modes'],[asdict(m) for m in MODES]):raise ValueError('Future process-noise configuration mismatch')
        if not (0<=t-packet['issued_at']<=.40000001 and equal(t-packet['issued_at'],report['source_age_s'])):failures.append([t,'sample_age'])
        if len(packet['models'])!=4 or any(len(m['trajectories'])!=12 or m['requested']!=12 for m in packet['models']):failures.append([t,'incomplete_branches'])
        tube=union_tube(packet,PlatformState(**row['platform']),t,first['offset'])
        motion=(row.get('planar_supervision') or {}).get('motion')
        tube=inflate_forecast_tube(tube,motion)
        if not equal(asdict(tube),row['forecast_uncertainty']):failures.append([t,'branch_union_replay'])
        snapshots[round(t,8)]=asdict(tube)
        packets={k:v for k,v in packets.items() if k>=sequence}
    stream.close()
    session=r/'receding_session.json'
    record=json.loads(session.read_text()) if session.exists() else json.loads((r/'receding_attempts.json').read_text())[-1]
    profile=json.loads((run/'config/airframes/iris_fixed_gimbal_sim.json').read_text())
    policy=audit_rows(rows,cfg,profile['nominal_com_in_body_m'],record['events']);policy.pop('snapshots')
    plans=audit_saved_plans(run,cfg,snapshots)
    report=dict(passed=checked>0 and not failures and policy['passed'] and plans['passed'],ready_rows_replayed=checked,failures=failures,policy=policy,nominal_plans=plans,scope='Causal pose-only filter and all four sampled branches replayed. Finite sampled reserve, no probability or continuous-time guarantee; physical audit remains separate.')
    (r/'stage6_link_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));return 0 if report['passed'] else 1


if __name__=='__main__':sys.exit(main(Path(sys.argv[1]).resolve()))

import json,tempfile,unittest
from pathlib import Path
from integration.native_exit import may_stop_scene

class NativeExitTests(unittest.TestCase):
    def test_unknown_running_or_post_arm_state_never_authorizes_teardown(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)
            self.assertFalse(may_stop_scene(p,True,100))
            self.assertTrue(may_stop_scene(p,False,100))
            (p/'arming_intent.json').write_text('{"active_monotonic_s":10}')
            self.assertFalse(may_stop_scene(p,False,100))
            (p/'native_disarmed_ack.json').write_text('{bad')
            self.assertFalse(may_stop_scene(p,False,100))

    def test_only_fresh_received_post_arm_disarmed_ack_allows_teardown(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'arming_intent.json').write_text('{"active_monotonic_s":10}')
            ack=dict(confirmed_disarmed=True,heartbeat_received_active_s=11,recorded_wall_unix_s=99,heartbeat_age_wall_s=.2,heartbeat_age_sim_s=.1)
            for field,value in [('confirmed_disarmed',False),('heartbeat_received_active_s',9),('recorded_wall_unix_s',70),('recorded_wall_unix_s',101),('heartbeat_age_sim_s',2)]:
                (p/'native_disarmed_ack.json').write_text(json.dumps({**ack,field:value}))
                self.assertFalse(may_stop_scene(p,False,100))
            (p/'native_disarmed_ack.json').write_text(json.dumps(ack))
            self.assertTrue(may_stop_scene(p,False,100))

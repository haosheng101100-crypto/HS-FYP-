import json,tempfile,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from integration.native_ack import refresh_disarmed_ack


def message(kind,system=1,**fields):
    return SimpleNamespace(**fields,get_type=lambda:kind,get_srcSystem=lambda:system,get_srcComponent=lambda:1,to_dict=lambda:dict(mavpackettype=kind,**fields))


class NativeAckTests(unittest.TestCase):
    def check(self,messages,expected):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder);(p/'arming_intent.json').write_text(json.dumps(dict(active_monotonic_s=time.monotonic()-1,wall_unix_s=time.time()-1)))
            items=iter(messages);closed=[]
            requests=[]
            connection=SimpleNamespace(recv_match=lambda **kwargs:next(items,None),close=lambda:closed.append(True),mav=SimpleNamespace(command_long_send=lambda *args:requests.append(args)))
            with patch('pymavlink.mavutil.mavlink_connection',return_value=connection):
                self.assertEqual(refresh_disarmed_ack(p,timeout=.02),expected)
            self.assertTrue(closed)
            self.assertEqual(requests[0][2],511)
            self.assertEqual((p/'native_disarmed_ack.json').exists(),expected)
            if expected:self.assertEqual(len(json.loads((p/'native_disarmed_ack.json').read_text())['heartbeats']),2)

    def test_two_native_disarmed_heartbeats_and_bounded_native_clock_are_required(self):
        clock=lambda t:message('SYSTEM_TIME',time_boot_ms=int(t*1000))
        disarmed=message('HEARTBEAT',base_mode=89)
        self.check([clock(1),disarmed,clock(1.5),disarmed,clock(2)],True)
        self.check([clock(1),message('HEARTBEAT',base_mode=217)],False)
        self.check([clock(1),disarmed,clock(1.5),disarmed,clock(4)],False)
        self.check([clock(1),message('HEARTBEAT',system=255,base_mode=89),clock(2)],False)

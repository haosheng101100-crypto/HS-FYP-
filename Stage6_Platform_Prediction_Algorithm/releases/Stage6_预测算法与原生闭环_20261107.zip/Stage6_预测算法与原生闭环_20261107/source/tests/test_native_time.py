import csv,tempfile,unittest
from pathlib import Path
from extensions.journal import RunJournal


class NativeTimeTests(unittest.TestCase):
    def test_unknown_physics_duration_is_not_zero_and_can_be_recorded(self):
        with tempfile.TemporaryDirectory() as folder:
            journal=RunJournal(folder)
            with journal.run('native',{},None,folder) as key:
                with (Path(folder)/'仿真时间记录.csv').open(encoding='utf-8-sig') as f:
                    self.assertEqual(next(csv.DictReader(f))['simulated_duration_s'],'')
                journal.observe_duration(key,53.2)
            with (Path(folder)/'仿真时间记录.csv').open(encoding='utf-8-sig') as f:
                row=next(csv.DictReader(f));self.assertEqual(row['simulated_duration_s'],'53.2');self.assertEqual(row['status'],'completed')

import unittest
from tools.audit_stage6_exit import interval_covered


class ExitEvidenceTests(unittest.TestCase):
    def test_missing_endpoints_and_interior_gaps_cannot_pass_clearance_audit(self):
        self.assertFalse(interval_covered([],1.,2.))
        self.assertFalse(interval_covered([1.5],1.,2.))
        self.assertFalse(interval_covered([1.,1.04,1.96,2.],1.,2.))
        self.assertFalse(interval_covered([1.2+i*.04 for i in range(21)],1.,2.))
        self.assertTrue(interval_covered([.98+i*.04 for i in range(27)],1.,2.))

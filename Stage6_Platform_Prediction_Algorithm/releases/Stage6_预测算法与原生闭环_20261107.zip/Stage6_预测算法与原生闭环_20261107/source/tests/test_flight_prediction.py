import unittest,tempfile,json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from integration.flight_prediction import FlightPrediction,snapshot,restore,union_tube,select_nominal_mode
from stage6.observation import Observation
from stage6.predictor import VehiclePredictor
from stage6.model import MODES
from landing.stage6_nominal import platform_from_vehicle

class BridgeTests(unittest.TestCase):
    def test_current_filter_tuning_keeps_future_input_noise_and_all_branches(self):
        p=VehiclePredictor((0,0),jerk_process_scale=.03)
        for t in np.arange(0,.6,.1):p.update(Observation(float(t),float(t+.04),(float(t)*.3,0.),0.,np.diag([4e-6]*3)))
        for f,m in zip(p.filters,MODES):
            self.assertAlmostEqual(f.mode.q_j,m.q_j*.03)
            self.assertEqual(f.mode.q_eta,m.q_eta)
        q=restore(snapshot(p,.6,1))
        for f,m in zip(q.filters,MODES):
            self.assertEqual(f.mode.q_j,m.q_j)
        np.testing.assert_allclose(q.filters[1].covariance,p.filters[1].covariance)

    def test_nominal_retains_branch_under_ambiguous_weights_then_switches(self):
        self.assertEqual(select_nominal_mode([.8,.1,.05,.05]),0)
        self.assertEqual(select_nominal_mode([.383,.397,.065,.155],0),0)
        self.assertEqual(select_nominal_mode([.2,.65,.05,.1],0),1)
        self.assertEqual(select_nominal_mode([.397,.383,.065,.155],1),1)

    def test_snapshot_is_independent_and_roundtrips_filter(self):
        p=VehiclePredictor((.6786706955992161,0))
        for t in np.arange(0,.6,.1):p.update(Observation(float(t),float(t+.04),(float(t),0.),0.,np.diag([4e-6]*3)))
        d=snapshot(p,.6,1);q=restore(d)
        np.testing.assert_allclose(q.filters[0].mean,p.filters[0].mean)
        q.filters[0].mean[0]+=99
        self.assertNotEqual(q.filters[0].mean[0],p.filters[0].mean[0])

    def packet(self):
        tr=dict(states=[[0,0,0,1,0,0,0,0],[.1,0,0,1,0,0,0,0]])
        return dict(status='ready',issued_at=1.,horizons_s=[.1,.2],models=[dict(requested=1,trajectories=[tr]) for _ in range(4)])

    def test_union_is_about_exact_nominal_and_retains_all_modes(self):
        p=platform_from_vehicle([0,0,0,1,0,0,0,0],'CV',1.,.8,(0,0),(.34,.4))
        d=self.packet();d['models'][3]['trajectories'][0]=dict(states=[[0,.3,0,1,0,0,0,0],[.1,.3,0,1,0,0,0,0]])
        tube=union_tube(d,p,1.,(0,0))
        self.assertGreaterEqual(tube.at(.1)['position_m'],.3)
        self.assertEqual(tube.sample_counts,(4,4,4))
        d['models'][3]['trajectories']=[]
        with self.assertRaises(ValueError):union_tube(d,p,1.,(0,0))

    def test_no_future_or_duplicate_pose_is_consumed_and_stale_is_unavailable(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp)/'results').mkdir();b=FlightPrediction(tmp,(0,0),(.34,.4))
            def row(t):return SimpleNamespace(sim_t_s=t,pose=SimpleNamespace(position_world_m=(t,0,0),orientation_xyzw=(0,0,0,1)))
            rows=[row(float(t)) for t in np.arange(0,.61,.1)]
            b.update(rows,.6,.8);count=b.predictor.sample_count
            self.assertAlmostEqual(b.last_stamp,.5)
            b.update(rows,.6,.8);self.assertEqual(count,b.predictor.sample_count)
            state,tube=b.update([],1.,.8)
            self.assertIsNone(state);self.assertFalse(b.ready);self.assertIsNotNone(tube);self.assertFalse(tube.ready)
            calls=[json.loads(line) for line in (Path(tmp)/'results/stage6_link.jsonl').read_text().splitlines()]
            self.assertEqual([r['call_sequence'] for r in calls],[1,2,3])
            self.assertEqual(calls[-1]['reason'],'stale_measurement')
            self.assertFalse(calls[-1]['nominal_selection_applied'])
            b.log.close();b.obs_log.close()

    def test_normal_30hz_stream_with_40ms_control_never_becomes_stale(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp)/'results').mkdir();b=FlightPrediction(tmp,(0,0),(.34,.4))
            rows=[SimpleNamespace(sim_t_s=float(t),pose=SimpleNamespace(position_world_m=(float(t)*.2,0,0),orientation_xyzw=(0,0,0,1))) for t in np.arange(0,3,.034)]
            for t in np.arange(.6,2.9,.04):
                b.update([r for r in rows if r.sim_t_s<=t],float(t),.8)
                self.assertLessEqual(t-b.last_stamp,.12+1e-9)
                self.assertNotEqual(b.report['reason'],'stale_measurement')
            b.log.close();b.obs_log.close()

if __name__=='__main__':unittest.main()

import json,unittest
from dataclasses import asdict
import numpy as np
from landing.receding_landing import PlatformState
from landing.stage6_nominal import platform_from_vehicle,heading_interval


class VehicleNominalTests(unittest.TestCase):
    def test_turn_is_preserved_through_json_and_long_horizon(self):
        s=[0.,0.,0.,1.,0.,.5,0.,0.]
        p=platform_from_vehicle(s,'CT',0.,.8,(0.,0.),(.34,.408))
        restored=PlatformState(**json.loads(json.dumps(asdict(p))))
        q=restored.predict(4.)
        np.testing.assert_allclose(q.position[:2],[2*np.sin(2),2*(1-np.cos(2))],atol=1e-6)
        self.assertAlmostEqual(q.yaw,2.,places=6)
        self.assertIsNotNone(q.vehicle_nominal)

    def test_rotating_offset_derivatives_match_analytic_circle(self):
        p=platform_from_vehicle([0,0,0,1,0,.5,0,0],'CT',0.,.8,(1.,0.),(.34,.408))
        np.testing.assert_allclose(p.velocity,[1.,.5,0.])
        np.testing.assert_allclose(p.acceleration,[-.25,.5,0.])
        np.testing.assert_allclose(p.jerk,[-.25,-.125,0.])

    def test_heading_interval_handles_wrap_and_interior_reversal(self):
        p=platform_from_vehicle([0,0,3.1,1,0,.2,0,-.5],'CTVAR',0.,.8,(0.,0.),(.34,.408))
        lo,hi=heading_interval(p,4.)
        yaw=np.unwrap([p.predict(t).yaw for t in np.linspace(0,4,401)])
        self.assertLessEqual(lo,float(yaw.min()))
        self.assertGreaterEqual(hi,float(yaw.max()))
        self.assertLess(hi-lo,3.)

    def test_nonlinear_capture_bounds_cover_interior(self):
        from landing.stage6_nominal import capture_bounds
        p=platform_from_vehicle([0,0,0,.5,-.08,.08,.2,-.1],'CTVAR',0.,.8,(.68,0),(.34,.408))
        b=capture_bounds(p,.2,.8)
        for t in np.linspace(.2,.8,301):
            q=p.predict(t)
            self.assertLessEqual(np.linalg.norm(q.acceleration[:2]),b['acceleration'])
            self.assertLessEqual(abs(q.yaw_rate),b['yaw_rate'])
            self.assertLessEqual(abs(q.yaw_acceleration),b['yaw_acceleration'])

    def test_nonlinear_capture_report_is_json_serializable(self):
        from landing.planar_landing import capture_window
        p=platform_from_vehicle([0,0,0,.3,0,0,0,0],'CV',0.,.8,(.68,0),(.34,.408))
        json.dumps(capture_window(p,.8))

    def test_legacy_polynomial_behavior_unchanged(self):
        p=PlatformState(0.,(0.,0.,.8),(1,0,0),(1,0,0))
        self.assertEqual(p.predict(2.).position,(4.,0.,.8))


if __name__=='__main__':unittest.main()

"""JSON-safe conditional Stage6 nominal; no future command or route input.

The quadrature is numerical nominal propagation, not a reachable-set proof.
Unwrapped heading is integrated analytically; translation uses Gauss quadrature.
"""
import math
import numpy as np
from stage6.model import MODES

_NODES,_WEIGHTS=np.polynomial.legendre.leggauss(64)
_MODES={m.name:m for m in MODES}


def _integral(rate,t,power=0):
    if rate==0:return t**(power+1)/(power+1)
    if power==0:return -np.expm1(-rate*t)/rate
    return (-np.expm1(-rate*t)-rate*t*np.exp(-rate*t))/rate**2


def propagate(state,mode,h):
    s=np.asarray(state,dtype=float)
    if s.shape!=(8,) or not np.isfinite(s).all() or not math.isfinite(h) or h<0:
        raise ValueError('Finite vehicle state and nonnegative horizon required')
    m=_MODES[mode]; x,y,psi,v,a,k,j,eta=s
    rj=1/m.tau_j;re=1/m.tau_eta
    b=j/(m.lambda_a-rj);aa=a-b
    d=eta/(m.lambda_k-re);c=k-d
    vt=[(0,0.,v)]
    for rate,coef in ((m.lambda_a,aa),(rj,b)):
        if rate==0:vt.append((1,0.,coef))
        else:vt.extend(((0,0.,coef/rate),(0,rate,-coef/rate)))
    kt=((m.lambda_k,c),(re,d))
    def values(t):
        vv=sum(coef*t**power*np.exp(-rate*t) for power,rate,coef in vt)
        kk=sum(coef*np.exp(-rate*t) for rate,coef in kt)
        pp=psi+sum(vc*kc*_integral(vr+kr,t,power) for power,vr,vc in vt for kr,kc in kt)
        return vv,kk,pp
    tt=(_NODES+1)*h/2;vv,_,pp=values(tt)
    dx=h/2*np.dot(_WEIGHTS,vv*np.cos(pp));dy=h/2*np.dot(_WEIGHTS,vv*np.sin(pp))
    vh,kh,ph=values(h)
    return np.array((x+dx,y+dy,ph,vh,aa*np.exp(-m.lambda_a*h)+b*np.exp(-rj*h),kh,j*np.exp(-rj*h),eta*np.exp(-re*h)))


def platform_from_vehicle(state,mode,stamp,height,offset,half_extents,*,source_id=None,trusted_until=None):
    from .receding_landing import PlatformState
    s=propagate(state,mode,0.);m=_MODES[mode]
    x,y,psi,v,a,k,j,eta=s
    off=np.asarray(offset,dtype=float)
    if off.shape!=(2,) or not np.isfinite(off).all():raise ValueError('Finite fixed XY deck offset required')
    e=np.array((math.cos(psi),math.sin(psi)));n=np.array((-e[1],e[0]))
    r=off[0]*e+off[1]*n;jr=np.array((-r[1],r[0]))
    da=j-m.lambda_a*a;dk=eta-m.lambda_k*k
    w=v*k;alpha=a*k+v*dk
    beta=da*k+2*a*dk+v*(-eta/m.tau_eta-m.lambda_k*dk)
    pos=np.array((x,y))+r
    vel=v*e+w*jr
    acc=a*e+v*w*n+alpha*jr-w*w*r
    jerk=(da-v*w*w)*e+(2*a*w+v*alpha)*n+(beta-w**3)*jr-3*w*alpha*r
    payload=dict(version=1,state=s.tolist(),mode=mode,offset=off.tolist(),height=float(height),source_id=source_id,trusted_until=trusted_until)
    return PlatformState(float(stamp),(*pos,float(height)),(*vel,0.),(*acc,0.),float(psi),float(w),tuple(half_extents),(*jerk,0.),float(alpha),vehicle_nominal=payload)


def predict_platform(platform,h):
    p=platform.vehicle_nominal
    return platform_from_vehicle(propagate(p['state'],p['mode'],h),p['mode'],platform.stamp+h,p['height'],p['offset'],platform.half_extents,source_id=p['source_id'],trusted_until=p['trusted_until'])


def heading_interval(platform,h):
    if not math.isfinite(h) or h<0:raise ValueError('Nonnegative interval required')
    p=platform.vehicle_nominal
    if p is None:
        angles=[platform.yaw,platform.predict(h).yaw];alpha=platform.yaw_acceleration
        if alpha and 0< -platform.yaw_rate/alpha<h:angles.append(platform.predict(-platform.yaw_rate/alpha).yaw)
        return min(angles),max(angles)
    s=np.array(p['state']);m=_MODES[p['mode']]
    n=max(1,math.ceil(h/.05));times=np.linspace(0,h,n+1)
    angles=[propagate(s,p['mode'],t)[2] for t in times]
    max_a=abs(s[4])+abs(s[6])*m.tau_j
    max_w=(abs(s[3])+h*max_a)*(abs(s[5])+abs(s[7])*m.tau_eta)
    pad=max_w*h/(2*n)
    return min(angles)-pad,max(angles)+pad


def capture_bounds(platform,lo,hi):
    """Continuous nominal acceleration/heading bounds via derivative padding."""
    p=platform.vehicle_nominal;m=_MODES[p['mode']]
    s=propagate(p['state'],p['mode'],lo);h=hi-lo
    A=abs(s[4])+abs(s[6])*m.tau_j;V=abs(s[3])+h*A
    K=abs(s[5])+abs(s[7])*m.tau_eta
    DA=abs(s[6])+m.lambda_a*A;DK=abs(s[7])+m.lambda_k*K
    W=V*K;AL=A*K+V*DK
    BE=DA*K+2*A*DK+V*(abs(s[7])/m.tau_eta+m.lambda_k*DK)
    R=float(np.linalg.norm(p['offset']))
    J=DA+V*W*W+2*A*W+V*AL+(BE+W**3)*R+3*W*AL*R
    n=max(1,math.ceil(h/.02));pad=h/(2*n)
    states=[platform.predict(float(t)) for t in np.linspace(lo,hi,n+1)]
    return dict(acceleration=float(max(math.hypot(*q.acceleration[:2]) for q in states)+J*pad),
                yaw_rate=float(max(abs(q.yaw_rate) for q in states)+AL*pad),
                yaw_acceleration=float(max(abs(q.yaw_acceleration) for q in states)+BE*pad))

"""Self-contained native world; CLI SDF checker has no simulator URI callback."""
from copy import deepcopy
import xml.etree.ElementTree as ET


def build_world(vehicle_model):
    root=ET.fromstring('''<sdf version="1.9"><world name="stage6_prediction">
    <physics name="native" type="ignore"><max_step_size>0.001</max_step_size><real_time_factor>1</real_time_factor></physics>
    <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"/>
    <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"/>
    <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"/>
    <scene><ambient>1 1 1</ambient><background>0.8 0.85 0.9</background></scene>
    <light type="directional" name="sun"><pose>0 0 10 0 0 0</pose><diffuse>0.8 0.8 0.8 1</diffuse><direction>-0.5 0.1 -0.9</direction></light>
    <model name="ground"><static>true</static><link name="ground"><collision name="floor"><geometry><plane><normal>0 0 1</normal><size>80 80</size></plane></geometry></collision>
    <visual name="floor"><geometry><plane><normal>0 0 1</normal><size>80 80</size></plane></geometry><material><ambient>0.65 0.7 0.65 1</ambient><diffuse>0.65 0.7 0.65 1</diffuse></material></visual></link></model>
    </world></sdf>''')
    car=ET.parse(vehicle_model).getroot().find('model')
    if car is None or car.get('name')!='landing_vehicle':raise ValueError('Expected native landing_vehicle model')
    car=deepcopy(car);pose=car.find('pose')
    if pose is None:pose=ET.SubElement(car,'pose')
    pose.text='3 0 0.002 0 0 0';root.find('world').append(car)
    for link in root.findall('.//link'):
        used={e.get('name') for e in link if e.tag!='visual' and e.get('name')}
        for visual in link.findall('visual'):
            name=visual.get('name')
            while name in used:name='visual_'+name
            visual.set('name',name);used.add(name)
    return ET.tostring(root,encoding='unicode')

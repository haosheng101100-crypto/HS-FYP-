"""Fail closed on unknown native arming state after an arming intent."""
import json
from pathlib import Path


def may_stop_scene(results,backend_running,now):
    if backend_running:return False
    results=Path(results);intent_path=results/'arming_intent.json'
    if not intent_path.exists():return True  # backend stopped before its only arm call
    try:
        intent=json.loads(intent_path.read_text());ack=json.loads((results/'native_disarmed_ack.json').read_text())
        return bool(ack.get('confirmed_disarmed') is True and ack['heartbeat_received_active_s']>=intent['active_monotonic_s'] and 0<=now-ack['recorded_wall_unix_s']<=20. and 0<=ack['heartbeat_age_wall_s']<=15. and 0<=ack['heartbeat_age_sim_s']<=1.5)
    except (OSError,KeyError,ValueError,TypeError):return False

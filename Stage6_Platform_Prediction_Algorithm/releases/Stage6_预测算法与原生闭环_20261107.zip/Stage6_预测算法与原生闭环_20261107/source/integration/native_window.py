"""Find only a Gazebo X11 window owned by our native GUI process group."""
import ctypes as C
import ctypes.util,os,json


def owned_gazebo_window(group_pid,diagnostic_path=None):
    x=C.CDLL(ctypes.util.find_library('X11'));P=C.c_void_p;U=C.c_ulong
    x.XOpenDisplay.argtypes=[C.c_char_p];x.XOpenDisplay.restype=P
    x.XDefaultRootWindow.argtypes=[P];x.XDefaultRootWindow.restype=U
    x.XInternAtom.argtypes=[P,C.c_char_p,C.c_int];x.XInternAtom.restype=U
    x.XQueryTree.argtypes=[P,U,C.POINTER(U),C.POINTER(U),C.POINTER(C.POINTER(U)),C.POINTER(C.c_uint)]
    x.XFetchName.argtypes=[P,U,C.POINTER(C.c_char_p)]
    x.XGetWindowProperty.argtypes=[P,U,U,C.c_long,C.c_long,C.c_int,U,C.POINTER(U),C.POINTER(C.c_int),C.POINTER(U),C.POINTER(U),C.POINTER(P)]
    x.XFree.argtypes=[P];x.XCloseDisplay.argtypes=[P]
    x.XMoveResizeWindow.argtypes=[P,U,C.c_int,C.c_int,C.c_uint,C.c_uint];x.XMapRaised.argtypes=[P,U];x.XSync.argtypes=[P,C.c_int]
    d=x.XOpenDisplay(None)
    if not d:raise RuntimeError('Cannot access visible X11 desktop')
    try:
        atom=x.XInternAtom(d,b'_NET_WM_PID',0);windows=[];diagnostics=[]
        def walk(parent_window,depth):
            if depth>5:return
            root=U();parent=U();children=C.POINTER(U)();count=C.c_uint()
            x.XQueryTree(d,parent_window,C.byref(root),C.byref(parent),C.byref(children),C.byref(count))
            ids=[int(children[i]) for i in range(count.value)]
            if children:x.XFree(children)
            for window in ids:windows.append(window);walk(window,depth+1)
        walk(x.XDefaultRootWindow(d),0)
        for window in windows:
            name=C.c_char_p();title=''
            if x.XFetchName(d,window,C.byref(name)) and name.value:
                title=name.value.decode(errors='replace');x.XFree(C.cast(name,P))
            if 'gazebo' not in title.lower():continue
            actual=U();fmt=C.c_int();n=U();left=U();data=P()
            result=x.XGetWindowProperty(d,window,atom,0,1,0,6,C.byref(actual),C.byref(fmt),C.byref(n),C.byref(left),C.byref(data))
            try:pid=int(C.cast(data,C.POINTER(U))[0]) if result==0 and n.value==1 and fmt.value==32 and data else None
            finally:
                if data:x.XFree(data)
            diagnostics.append(dict(window_id=window,title=title,pid=pid))
            if pid is None:continue
            try:owned=os.getpgid(pid)==group_pid
            except ProcessLookupError:owned=False
            if owned:
                x.XMoveResizeWindow(d,window,0,0,1240,720);x.XMapRaised(d,window);x.XSync(d,0)
                return dict(window_id=window,window_pid=pid,owned_process_group=group_pid,title=title)
        if diagnostic_path:diagnostic_path.write_text(json.dumps(dict(group_pid=group_pid,candidates=diagnostics),indent=2))
    finally:x.XCloseDisplay(d)
    return None


def window_geometry(window):
    x=C.CDLL(ctypes.util.find_library('X11'));P=C.c_void_p;U=C.c_ulong
    x.XOpenDisplay.restype=P;x.XGetGeometry.argtypes=[P,U,C.POINTER(U),C.POINTER(C.c_int),C.POINTER(C.c_int),C.POINTER(C.c_uint),C.POINTER(C.c_uint),C.POINTER(C.c_uint),C.POINTER(C.c_uint)];x.XCloseDisplay.argtypes=[P]
    d=x.XOpenDisplay(None)
    if not d:raise RuntimeError('Native display unavailable')
    try:
        root=U();xx=C.c_int();yy=C.c_int();w=C.c_uint();h=C.c_uint();border=C.c_uint();depth=C.c_uint()
        if not x.XGetGeometry(d,window,C.byref(root),C.byref(xx),C.byref(yy),C.byref(w),C.byref(h),C.byref(border),C.byref(depth)):raise RuntimeError('Owned window geometry unavailable')
        return w.value,h.value
    finally:x.XCloseDisplay(d)

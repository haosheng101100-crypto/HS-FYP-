"""World scenario audit from actual received poses, independent of commands."""
import numpy as np


def assess_motion(rows,scenario):
    if scenario not in ('straight','turning','varying'):raise ValueError('Unknown physical scenario')
    t=np.array([r['stamp'] for r in rows]);xy=np.array([r['xy'] for r in rows]);yaw=np.unwrap([r['yaw'] for r in rows])
    if len(t)<20 or np.any(np.diff(t)<=0):return dict(passed=False,reason='insufficient_actual_poses')
    elapsed=t-t[0];mask=(elapsed>=2.)&(elapsed<=20.)
    travel=float(np.linalg.norm(np.diff(xy[mask],axis=0),axis=1).sum())
    displacement=float(np.linalg.norm(xy[mask][-1]-xy[mask][0]));span=float(np.ptp(yaw[mask]))
    speed=np.linalg.norm(np.diff(xy,axis=0),axis=1)/np.diff(t)
    stabilized=speed[(elapsed[1:]>=7.)&(elapsed[1:]<=19.)]
    variation=float(np.percentile(stabilized,90)-np.percentile(stabilized,10)) if len(stabilized) else 0.
    moving=travel>3. and displacement>2. and np.percentile(speed,90)>.2
    mechanism=dict(straight=span<.15,turning=span>.4,varying=span>.05 and variation>.06)[scenario]
    return dict(passed=bool(moving and mechanism),travel_m=travel,displacement_m=displacement,yaw_span_rad=span,
                stabilized_speed_90_10_mps=variation,scope='Measured mechanism coverage, not ideal command tracking.')

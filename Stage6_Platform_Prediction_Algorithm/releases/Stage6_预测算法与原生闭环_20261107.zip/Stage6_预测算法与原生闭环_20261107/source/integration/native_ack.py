"""Postflight MAVLink witness; requests clock telemetry, never flight commands."""
import json,time
from pathlib import Path


def refresh_disarmed_ack(results,timeout=25.,endpoint='tcp:127.0.0.1:5762'):
    from pymavlink import mavutil
    results=Path(results);intent=json.loads((results/'arming_intent.json').read_text())
    connection=mavutil.mavlink_connection(endpoint,autoreconnect=False)
    deadline=time.monotonic()+timeout;clock=None;witnesses=[]
    try:
        connection.mav.command_long_send(1,1,mavutil.mavlink.MAV_CMD_SET_MESSAGE_INTERVAL,0,mavutil.mavlink.MAVLINK_MSG_ID_SYSTEM_TIME,100000,0,0,0,0,0)
        while time.monotonic()<deadline:
            message=connection.recv_match(blocking=True,timeout=.5)
            if message is None or message.get_srcSystem()!=1 or message.get_srcComponent()!=1:continue
            now=time.monotonic();wall=time.time();kind=message.get_type()
            if kind=='SYSTEM_TIME' and message.time_boot_ms>0:
                clock=float(message.time_boot_ms)*.001
                if len(witnesses)>=2:
                    last=witnesses[-1];age_sim=clock-last['preceding_fcu_clock_s']
                    if 0<=age_sim<=1.5 and now-last['received_monotonic_s']<=15.:
                        ack=dict(confirmed_disarmed=True,source='Two actually received native HEARTBEATs; independent postflight witness with requested clock telemetry',heartbeat_received_active_s=last['received_monotonic_s'],heartbeat_age_wall_s=now-last['received_monotonic_s'],heartbeat_age_sim_s=age_sim,recorded_wall_unix_s=wall,following_fcu_clock_s=clock,fcu_clock_source='native SYSTEM_TIME time_boot_ms; preceding timestamp gives conservative heartbeat age',telemetry_request='SET_MESSAGE_INTERVAL SYSTEM_TIME 100000us; no arm/disarm/mode command',heartbeats=witnesses[-2:])
                        target=results/'native_disarmed_ack.json';temporary=target.with_suffix('.tmp');temporary.write_text(json.dumps(ack,indent=2)+'\n');temporary.replace(target)
                        return True
            elif kind=='HEARTBEAT':
                if message.base_mode&mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED:return False
                if clock is not None and wall>=intent['wall_unix_s'] and now>=intent['active_monotonic_s']:
                    witnesses.append(dict(received_monotonic_s=now,received_wall_unix_s=wall,preceding_fcu_clock_s=clock,system_id=1,component_id=1,message=message.to_dict()))
        return False
    finally:connection.close()


if __name__=='__main__':
    import sys
    sys.exit(0 if refresh_disarmed_ack(Path(sys.argv[1])) else 1)

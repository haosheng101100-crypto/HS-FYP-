"""Four physical driven wheels; model geometry changes isolated from predictor."""
from copy import deepcopy
import xml.etree.ElementTree as ET


def build_four_wheels(source):
    model=deepcopy(ET.parse(source).getroot().find('model'))
    templates={side:deepcopy(model.find(f'link[@name="{side}_wheel"]')) for side in ('left','right')}
    joint_templates={side:deepcopy(model.find(f'joint[@name="{side}_wheel_joint"]')) for side in ('left','right')}
    for e in list(model):
        if e.tag in ('link','joint') and any(word in e.get('name','') for word in ('wheel','caster')):model.remove(e)
    drive=model.find('plugin[@name="gz::sim::systems::DiffDrive"]')
    for e in list(drive):
        if e.tag in ('left_joint','right_joint'):drive.remove(e)
    for side,y in (('left',.78),('right',-.78)):
        for axle,x in (('front',.65),('rear',-.65)):
            name=f'{axle}_{side}_wheel';wheel=deepcopy(templates[side]);wheel.set('name',name)
            wheel.find('pose').text=f'{x} {y} 0.25 0 0 0'
            hub=ET.SubElement(wheel,'visual',name=name+'_hub')
            ET.SubElement(hub,'pose').text='0 0 0 1.57079632679 0 0'
            cylinder=ET.SubElement(ET.SubElement(hub,'geometry'),'cylinder')
            ET.SubElement(cylinder,'radius').text='.12';ET.SubElement(cylinder,'length').text='.135'
            material=ET.SubElement(hub,'material');ET.SubElement(material,'ambient').text='.75 .78 .8 1';ET.SubElement(material,'diffuse').text='.75 .78 .8 1'
            for index,size in enumerate(('.36 .137 .028','.028 .137 .36')):
                spoke=ET.SubElement(wheel,'visual',name=name+'_spoke_'+str(index))
                ET.SubElement(ET.SubElement(ET.SubElement(spoke,'geometry'),'box'),'size').text=size
                m=ET.SubElement(spoke,'material');ET.SubElement(m,'ambient').text='.85 .87 .9 1';ET.SubElement(m,'diffuse').text='.85 .87 .9 1'
            model.append(wheel)
            joint=deepcopy(joint_templates[side]);joint.set('name',name+'_joint');joint.find('child').text=name;model.append(joint)
            ET.SubElement(drive,side+'_joint').text=name+'_joint'
    chassis=model.find('link[@name="chassis"]')
    for name,x,color in (('front_bumper',1.01,'.2 .7 .45 1'),('rear_bumper',-1.01,'.75 .18 .12 1')):
        visual=ET.SubElement(chassis,'visual',name=name);ET.SubElement(visual,'pose').text=f'{x} 0 -.04 0 0 0'
        ET.SubElement(ET.SubElement(ET.SubElement(visual,'geometry'),'box'),'size').text='.06 1.35 .1'
        m=ET.SubElement(visual,'material');ET.SubElement(m,'ambient').text=color;ET.SubElement(m,'diffuse').text=color
    model.remove(drive)
    drive=ET.SubElement(model,'plugin',filename='gz-sim-ackermann-steering-system',name='gz::sim::systems::AckermannSteering')
    for tag,value in [('left_joint','rear_left_wheel_joint'),('right_joint','rear_right_wheel_joint'),('left_steering_joint','front_left_steering_joint'),('right_steering_joint','front_right_steering_joint'),('wheel_separation','1.56'),('kingpin_width','1.56'),('wheel_base','1.3'),('wheel_radius','.25'),('steering_limit','.55'),('steer_p_gain','2'),('topic','/vehicle/cmd_vel'),('odom_topic','/vehicle/odometry'),('odom_publish_frequency','30'),('min_velocity','-1'),('max_velocity','1'),('min_acceleration','-.3'),('max_acceleration','.3')]:ET.SubElement(drive,tag).text=value
    for side,y in (('left',.78),('right',-.78)):
        knuckle=ET.SubElement(model,'link',name='front_'+side+'_knuckle');ET.SubElement(knuckle,'pose').text=f'.65 {y} .25 0 0 0'
        inertia=ET.SubElement(knuckle,'inertial');ET.SubElement(inertia,'mass').text='.05';tensor=ET.SubElement(inertia,'inertia')
        for name in ('ixx','iyy','izz'):ET.SubElement(tensor,name).text='.001'
        steering=ET.SubElement(model,'joint',name='front_'+side+'_steering_joint',type='revolute');ET.SubElement(steering,'parent').text='chassis';ET.SubElement(steering,'child').text='front_'+side+'_knuckle'
        axis=ET.SubElement(steering,'axis');ET.SubElement(axis,'xyz').text='0 0 1';limit=ET.SubElement(axis,'limit');ET.SubElement(limit,'lower').text='-.6';ET.SubElement(limit,'upper').text='.6';ET.SubElement(limit,'effort').text='1000';ET.SubElement(limit,'velocity').text='2'
        model.find(f'joint[@name="front_{side}_wheel_joint"]/parent').text='front_'+side+'_knuckle'
    return model

"""Capture an explicitly owned native client drawable, not the Wayland root."""
import ctypes as C,ctypes.util
from PIL import Image

class XImage(C.Structure):
    _fields_=[('width',C.c_int),('height',C.c_int),('xoffset',C.c_int),('format',C.c_int),('data',C.c_void_p),('byte_order',C.c_int),('bitmap_unit',C.c_int),('bitmap_bit_order',C.c_int),('bitmap_pad',C.c_int),('depth',C.c_int),('bytes_per_line',C.c_int),('bits_per_pixel',C.c_int),('red_mask',C.c_ulong),('green_mask',C.c_ulong),('blue_mask',C.c_ulong)]

def capture(window,path,width=1240,height=720):
    x=C.CDLL(ctypes.util.find_library('X11'));x.XOpenDisplay.restype=C.c_void_p
    x.XGetImage.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_ulong,C.c_int];x.XGetImage.restype=C.POINTER(XImage)
    x.XDestroyImage.argtypes=[C.POINTER(XImage)];x.XCloseDisplay.argtypes=[C.c_void_p]
    d=x.XOpenDisplay(None)
    if not d:raise RuntimeError('Native display unavailable')
    ptr=None
    try:
        ptr=x.XGetImage(d,window,0,0,width,height,0xffffffff,2)
        if not ptr:raise RuntimeError('Native client drawable unavailable')
        q=ptr.contents
        if q.bits_per_pixel!=32 or q.byte_order!=0:raise RuntimeError('Unsupported native pixel format')
        data=C.string_at(q.data,q.bytes_per_line*q.height)
        Image.frombytes('RGB',(q.width,q.height),data,'raw','BGRX',q.bytes_per_line,1).save(path)
    finally:
        if ptr:x.XDestroyImage(ptr)
        x.XCloseDisplay(d)

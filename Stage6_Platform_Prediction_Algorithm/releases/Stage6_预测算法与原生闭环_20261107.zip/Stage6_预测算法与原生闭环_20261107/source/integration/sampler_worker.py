"""Latest-only full branch sampler. No simulator or command imports."""
import os,sys,json,time,gzip,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from integration.flight_prediction import restore,atomic

def main():
    os.nice(10);folder=ROOT/'runtime/stage6_sampler';folder.mkdir(parents=True,exist_ok=True)
    atomic(folder/'health.json',dict(ready=True,pid=os.getpid(),scope='full branching sampler; no actuation'))
    last=None
    with gzip.open(ROOT/'results/stage6_samples.jsonl.gz','xt') as log:
        while not (folder/'stop.request').exists():
            try:data=json.loads((folder/'request.json').read_text())
            except (FileNotFoundError,json.JSONDecodeError):time.sleep(.005);continue
            if data['sequence']==last:time.sleep(.005);continue
            last=data['sequence'];started=time.perf_counter()
            try:
                packet=restore(data).forecast(data['now'],step_s=.05,particles_per_mode=12,seed=20261108+last)
                packet['configuration'].update(current_filter_jerk_process_scale=data.get('current_filter_jerk_process_scale',1.),future_input_process_scale=1.)
                value=dict(sequence=last,packet=packet,compute_ms=(time.perf_counter()-started)*1000)
                atomic(folder/'response.json',value);log.write(json.dumps(value)+'\n');log.flush()
            except Exception:atomic(folder/'error.json',dict(sequence=last,traceback=traceback.format_exc()));raise

if __name__=='__main__':main()

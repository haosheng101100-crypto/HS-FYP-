"""Controller-facing planar deck product. No mode averaging or box-map shortcut."""
from copy import deepcopy
from dataclasses import asdict
import math
import numpy as np
from stage6.deck import body_to_deck


def build_deck_packet(vehicle,geometry,monitor,*,now,world_frame):
    issued=float(vehicle['issued_at'])
    h=np.array(vehicle['horizons_s'],dtype=float)
    if not math.isfinite(now) or now<issued-1e-9:raise ValueError('Prediction unavailable before issuance')
    if not isinstance(world_frame,str) or not world_frame.strip():raise ValueError('Explicit world frame required')
    if h.ndim!=1 or not len(h) or not np.all(np.isfinite(h)) or h[0]<=0 or np.any(np.diff(h)<=0):raise ValueError('Invalid target grid')
    names=[m['name'] for m in vehicle['models']]
    if len(set(names))!=len(names):raise ValueError('Duplicate mode names')
    stale_after=vehicle.get('latest_observation_stamp')
    if stale_after is not None:stale_after=float(stale_after)+.2
    branches=[];complete=True
    for model in vehicle['models']:
        trajectories=[]
        for i,tr in enumerate(model['trajectories']):
            if np.shape(tr['states'])!=(len(h),8):raise ValueError('Trajectory/grid mismatch')
            trajectories.append(dict(trajectory_id=f"{model['name']}:{i}",initial_vehicle_state=deepcopy(tr['initial_state']),
                                     vehicle_states=deepcopy(tr['states']),deck=body_to_deck(tr['states'],geometry)))
        complete &= len(trajectories)==model['requested'] and bool(trajectories)
        envelope=None
        if trajectories:
            p=np.array([t['deck']['position_xy'] for t in trajectories]);v=np.array([t['deck']['velocity_xy'] for t in trajectories]);angles=np.array([t['deck']['yaw'] for t in trajectories]);center=angles[0]
            envelope=dict(position_min=p.min(axis=0).tolist(),position_max=p.max(axis=0).tolist(),
                          velocity_min=v.min(axis=0).tolist(),velocity_max=v.max(axis=0).tolist(),
                          yaw_center=center.tolist(),yaw_radius=np.abs((angles-center+np.pi)%(2*np.pi)-np.pi).max(axis=0).tolist())
        branches.append(dict(name=model['name'],filter_posterior_weight=model['posterior_weight'],requested=model['requested'],
                             rejected=model['rejected'],trajectories=trajectories,sample_envelope=envelope))
    reason=None
    if stale_after is None or now>stale_after+1e-9:reason='observation_stale_or_absent'
    elif vehicle['status'] not in ('ready','degraded'):reason=vehicle['status']
    elif monitor['state'] not in ('ready_uncalibrated','warning'):reason=monitor['state']
    if reason:availability='unavailable'
    elif not complete or not branches or vehicle['status']=='degraded' or monitor['state']=='warning':availability='degraded'
    else:availability='available'
    return dict(schema_version=1,product='planar_deck_prediction',issued_at=issued,checked_at=float(now),world_frame=world_frame,
                target_times_s=(issued+h).tolist(),horizons_s=h.tolist(),stale_after_s=stale_after,
                availability=availability,reason=reason,source_vehicle_status=vehicle['status'],monitor=deepcopy(monitor),
                deck_geometry=asdict(geometry),branches=branches,uncertainty_type='finite_uncalibrated_deck_samples',
                physical_reachable_set=None,landing_authorization=False,
                scope='Each complete sample mapped with offset rotation/material velocity/corners. Vehicle box calibration is not transferred to the deck. No roll/pitch/vertical prediction or deterministic reachability claim.')

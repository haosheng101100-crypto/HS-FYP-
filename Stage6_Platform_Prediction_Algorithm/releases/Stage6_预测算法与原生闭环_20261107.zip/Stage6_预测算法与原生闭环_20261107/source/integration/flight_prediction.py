"""Causal pose-only IMM bridge and bounded latest-only sampling mailbox.

The flight process filters each delayed pose once. Sampling runs separately.
Finite branch union is an engineering reserve, never calibrated probability.
"""
from dataclasses import asdict
from pathlib import Path
import json,math
import numpy as np
from stage6.predictor import VehiclePredictor
from stage6.observation import Observation
from stage6.model import MODES,wrap,violations,Limits
from stage6.filter import UKF
from stage6.deck import DeckGeometry,body_to_deck
from extensions.monitor import TrustMonitor
from landing.stage6_nominal import platform_from_vehicle,propagate
from landing.receding_landing import PlatformState
from landing.prediction_uncertainty import ForecastTube


def atomic(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,allow_nan=False));tmp.replace(path)


def snapshot(p,now,sequence):
    return dict(sequence=sequence,now=now,offset=p.offset,weights=p.weights.tolist(),
        current_filter_jerk_process_scale=p.jerk_process_scale,future_input_process_scale=1.,
        latest={**asdict(p.latest),'covariance':p.latest.covariance.tolist()},
        first_stamp=p.first_stamp,sample_count=p.sample_count,reset_count=p.reset_count,
        filters=[dict(mean=f.mean.tolist(),covariance=f.covariance.tolist(),mode=f.mode.name) for f in p.filters])


def restore(data):
    p=VehiclePredictor(data['offset']);p.weights=np.array(data['weights']);p.latest=Observation(**data['latest'])
    p.first_stamp=data['first_stamp'];p.sample_count=data['sample_count'];p.reset_count=data['reset_count']
    p.filters=[UKF(f['mean'],f['covariance'],next(m for m in MODES if m.name==f['mode']),p.offset) for f in data['filters']]
    return p


def union_tube(packet,platform,now,offset):
    if packet['status']!='ready' or len(packet['models'])!=4:raise ValueError('Incomplete sampled forecast')
    hs=np.array(packet['horizons_s'])+packet['issued_at']-now
    keep=np.flatnonzero(hs>1e-6)
    if not len(keep):raise ValueError('No future branch samples')
    geom=DeckGeometry(offset,platform.half_extents)
    points=[];vel=[];yaw=[]
    for model in packet['models']:
        if len(model['trajectories'])!=model['requested'] or not model['trajectories']:
            raise ValueError('Missing mode paths; no survivor reweighting')
        for tr in model['trajectories']:
            d=body_to_deck(np.array(tr['states'])[keep],geom)
            points.append(d['position_xy']);vel.append(d['velocity_xy']);yaw.append(d['yaw'])
    nominal=[platform.predict(float(hs[i])) for i in keep]
    pos=np.linalg.norm(np.array(points)-np.array([p.position[:2] for p in nominal]),axis=2).max(axis=0)
    speed=np.linalg.norm(np.array(vel)-np.array([p.velocity[:2] for p in nominal]),axis=2).max(axis=0)
    angle=np.abs(wrap(np.array(yaw)-np.array([p.yaw for p in nominal]))).max(axis=0)
    # Upper-bin monotonic union; sampled targets only, no deterministic-set claim.
    radii=[tuple(np.maximum.accumulate(np.r_[v[0],v]).tolist()) for v in (pos,speed,angle)]
    return ForecastTube(now,tuple(np.r_[0.,hs[keep]].tolist()),*radii,tuple([len(points)]*(len(keep)+1)),True)


def unavailable_tube(t):
    return ForecastTube(t,(0.,2.),(3.,3.),(3.,3.),(math.pi,math.pi),(0,0),False)


def select_nominal_mode(weights,current=None,ratio=1.5):
    """Retain one physical branch until a challenger has clear posterior odds.

    This only selects the tracking nominal. Every branch remains in the reserve.
    """
    best=int(np.argmax(weights))
    return best if current is None or weights[best]>ratio*weights[current] else current


class FlightPrediction:
    def __init__(self,root,offset,half_extents):
        self.path=Path(root)/'runtime/stage6_sampler';self.path.mkdir(parents=True,exist_ok=True)
        self.predictor=VehiclePredictor(offset,jerk_process_scale=.01);self.monitor=TrustMonitor();self.offset=offset;self.half=half_extents
        self.last_stamp=-math.inf;self.last_issue=-math.inf;self.sequence=0;self.ready=False;self.report={}
        self.last_packet=None;self.consumed_sequence=None
        self.nominal_mode_index=None
        self.call_sequence=0
        self.log=(Path(root)/'results/stage6_link.jsonl').open('x',buffering=1)
        self.obs_log=(Path(root)/'results/stage6_observations.jsonl').open('x',buffering=1)

    def update(self,samples,t,height):
        self.call_sequence+=1;self.nominal_selection_applied=False
        try:
            return self._update(samples,t,height)
        finally:
            self.report.update(call_sequence=self.call_sequence,nominal_selection_applied=self.nominal_selection_applied,nominal_mode_index=self.nominal_mode_index)
            self.log.write(json.dumps(self.report)+'\n')

    def _update(self,samples,t,height):
        # Consume unique native poses (up to40Hz) with40ms explicit delay.
        # Keep the original120ms age gate; do not let100ms decimation exhaust it.
        for row in samples:
            stamp=row.sim_t_s
            if stamp>t-.04+1e-9 or stamp-self.last_stamp<.025:continue
            q=row.pose.orientation_xyzw;x,y,z,w=q
            yaw=math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))
            rng=np.random.default_rng(20261109+round(stamp*1e6));noise=rng.normal(size=3)*.002
            o=Observation(stamp,t,tuple(np.array(row.pose.position_world_m[:2])+noise[:2]),yaw+noise[2],np.diag([.002**2]*3))
            self.obs_log.write(json.dumps({**asdict(o),'covariance':o.covariance.tolist()})+'\n')
            self.predictor.update(o);self.monitor.observe_innovation([f.last_nis for f in self.predictor.filters]);self.last_stamp=stamp
        p=self.predictor
        self.ready=False;self.report=dict(time=t,reason='warming_up',samples=p.sample_count)
        if p.latest is None or p.sample_count<5 or p.latest.stamp-p.first_stamp<.4:return None,unavailable_tube(t)
        age=t-p.latest.stamp
        if not 0<=age<=.12+1e-9:self.report['reason']='stale_measurement';return None,unavailable_tube(t)
        if t-self.last_issue>=.04-1e-9:
            self.sequence+=1;atomic(self.path/'request.json',snapshot(p,t,self.sequence));self.last_issue=t
        index=select_nominal_mode(p.weights,self.nominal_mode_index);self.nominal_mode_index=index
        self.nominal_selection_applied=True
        f=p.filters[index];state=propagate(f.mean,f.mode.name,age)
        if violations(state,f.mode,Limits()):self.report['reason']='nominal_constraint_violation';return None,unavailable_tube(t)
        nominal=platform_from_vehicle(state,f.mode.name,t,height,self.offset,self.half,source_id=self.sequence,trusted_until=t+2.)
        try:
            response=json.loads((self.path/'response.json').read_text());packet=response['packet']
            source_age=t-packet['issued_at']
            if source_age<0 or source_age>.4:raise ValueError('sampler_source_stale')
            if self.monitor.latched['innovation']:raise ValueError('unreliable_innovation')
            tube=union_tube(packet,nominal,t,self.offset)
            self.ready=True;self.report.update(reason='available',source_age_s=source_age,observation_age_s=age,mode=f.mode.name,weights=p.weights.tolist(),sequence=response['sequence'],sampler_ms=response['compute_ms'])
            self.report['reserve_0_6s']=tube.at(min(.6,tube.horizons[-1]))
        except (FileNotFoundError,KeyError,ValueError,json.JSONDecodeError) as exc:
            tube=unavailable_tube(t)
            self.report['reason']=str(exc)
        self.report['ready']=self.ready
        return nominal,tube

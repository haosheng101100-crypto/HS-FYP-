"""Small dependency-free RGB plot for the native GTK prediction panel."""


def prediction_rgb(data,width=450,height=430):
    rgb=bytearray(bytes((247,247,242))*width*height)
    def pixel(x,y,color):
        if 0<=x<width and 0<=y<height:
            i=(y*width+x)*3;rgb[i:i+3]=bytes(color)
    def line(a,b,color):
        x,y=a;xx,yy=b;steps=max(abs(xx-x),abs(yy-y),1)
        if steps>5000:return
        for i in range(steps+1):pixel(round(x+(xx-x)*i/steps),round(y+(yy-y)*i/steps),color)
    if data:
        cx,cy=data['actual_position'];scale=min(width,height)/4.
        def point(p):return round(width/2+(p[0]-cx)*scale),round(height/2-(p[1]-cy)*scale)
        for k in range(-2,3):
            line(point((cx+k,cy-2)),point((cx+k,cy+2)),(218,218,209))
            line(point((cx-2,cy+k)),point((cx+2,cy+k)),(218,218,209))
        for a,b in zip(data['actual_history'],data['actual_history'][1:]):line(point(a),point(b),(25,25,25))
        colors=[(102,173,157),(119,161,204),(207,159,119),(175,145,198)]
        for j,branch in enumerate(data['deck']['branches']):
            for t in branch['trajectories']:
                positions=t['deck']['position_xy']
                for a,b in zip(positions,positions[1:]):line(point(a),point(b),colors[j%4])
    for x in range(width//2-3,width//2+4):
        for y in range(height//2-3,height//2+4):pixel(x,y,(20,20,20))
    return bytes(rgb)

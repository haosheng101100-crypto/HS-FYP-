"""Freeze actual publication clock and remove elapsed targets before delivery."""
from copy import deepcopy
import math
import numpy as np


def future_view(packet,point_xy,published_at,minimum_lead_s=.05):
    source=float(packet['issued_at'])
    if not math.isfinite(published_at) or published_at<source-1e-9:raise ValueError('Invalid publication clock')
    target=source+np.array(packet['horizons_s']);keep=target>published_at+minimum_lead_s+1e-9
    out=deepcopy(packet);out.update(source_issued_at=source,issued_at=float(published_at),publication_delay_s=float(published_at-source),
                                  expired_or_too_close_targets=int((~keep).sum()),minimum_delivery_lead_s=minimum_lead_s,horizons_s=(target[keep]-published_at).tolist())
    point=None if point_xy is None else np.asarray(point_xy)[keep].tolist()
    for m in out['models']:
        e=m.get('sample_envelope')
        if e is not None:
            for k,v in e.items():e[k]=np.asarray(v)[keep].tolist()
        for tr in m['trajectories']:
            tr['states']=np.asarray(tr['states'])[keep].tolist()
            tr['velocity_xy']=np.asarray(tr['velocity_xy'])[keep].tolist()
    if 'latest_observation_stamp' in out:
        out['observation_age_s']=published_at-out['latest_observation_stamp']
        if out['observation_age_s']>.2+1e-9:out.update(status='stale',models=[]);point=None
    if not keep.any() and out['status']!='stale':out.update(status='expired',models=[]);point=None
    return out,point

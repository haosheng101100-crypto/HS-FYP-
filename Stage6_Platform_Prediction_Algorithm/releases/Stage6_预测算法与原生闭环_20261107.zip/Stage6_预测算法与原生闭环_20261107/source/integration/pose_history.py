"""Only observed native Gazebo poses, with explicitly delayed interpolation."""
import bisect,math
import numpy as np


class PoseHistory:
    def __init__(self,max_gap_s=.1):
        self.times=[];self.xy=[];self.yaw=[];self.max_gap=max_gap_s

    def append(self,stamp,xy,yaw):
        if np.shape(xy)!=(2,) or not np.all(np.isfinite([stamp,yaw,*xy])):raise ValueError('Invalid native pose')
        if self.times and stamp<=self.times[-1]:return False
        self.times.append(float(stamp));self.xy.append(list(xy));self.yaw.append(float(yaw));return True

    def at(self,stamp):
        if len(self.times)<2 or stamp<self.times[0]-1e-9 or stamp>self.times[-1]+1e-9:raise ValueError('Actual future pose not yet received')
        i=bisect.bisect_left(self.times,stamp);i=max(1,min(i,len(self.times)-1))
        left,right=self.times[i-1:i+1];dt=right-left
        if dt>self.max_gap+1e-9:raise ValueError('Native pose gap too large')
        a=np.array(self.xy[i-1]);b=np.array(self.xy[i]);ratio=np.clip((stamp-left)/dt,0,1)
        angle=self.yaw[i-1]+ratio*math.remainder(self.yaw[i]-self.yaw[i-1],2*math.pi)
        return dict(stamp=float(stamp),received_at=right,position_xy=(a+ratio*(b-a)).tolist(),velocity_xy=((b-a)/dt).tolist(),yaw=float(math.remainder(angle,2*math.pi)))

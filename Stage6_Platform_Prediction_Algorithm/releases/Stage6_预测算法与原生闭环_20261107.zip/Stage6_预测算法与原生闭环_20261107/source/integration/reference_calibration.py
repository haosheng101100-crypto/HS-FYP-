"""Identify a fixed kinematic neutral reference from a separate development run.

v_lateral = offset * yaw_rate for a body point ahead of the neutral reference.
Only already recorded poses enter this offline geometry/model identification.
This does not identify steering, route or future commands for online prediction.
"""
import numpy as np


def fit_reference(rows):
    t=np.array([r['stamp'] for r in rows],dtype=float);p=np.array([r['xy'] for r in rows],dtype=float);yaw=np.unwrap([r['yaw'] for r in rows])
    if len(t)<30 or np.any(np.diff(t)<=0) or not np.all(np.isfinite(p)) or not np.all(np.isfinite(yaw)):
        raise ValueError('Finite ordered development poses required')
    dt=np.diff(t);angle=(yaw[:-1]+yaw[1:])/2;velocity=np.diff(p,axis=0)/dt[:,None];omega=np.diff(yaw)/dt
    lateral=-np.sin(angle)*velocity[:,0]+np.cos(angle)*velocity[:,1]
    usable=(dt<=.1)&(np.abs(omega)>=.015)&(np.linalg.norm(velocity,axis=1)>=.15)
    if usable.sum()<30:raise ValueError('Insufficient turning excitation; reference not identifiable')
    x=float(omega[usable]@lateral[usable]/(omega[usable]@omega[usable]))
    residual=lateral[usable]-x*omega[usable]
    return dict(offset_xy=[x,0.],samples=int(usable.sum()),lateral_residual_rms_mps=float(np.sqrt(np.mean(residual**2))),
        scope='Fixed kinematic neutral point identified on a separate development run; conditional low-slip model, not a hardware guarantee.')
